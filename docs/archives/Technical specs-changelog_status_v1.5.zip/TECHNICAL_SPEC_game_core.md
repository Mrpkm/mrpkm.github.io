# TECHNICAL_SPEC — Game Core

> Translated from `game_core.md` (v0.18, base ruleset closed).
> Source-of-truth prose lives in `game_core.md`; this file is the
> computable contract derived from it. If they conflict, update this
> file and note the discrepancy.
>
> **Scope:** The match-level state container (`MatchState`,
> `BoardState`, `Tile`), HQ damage/occupation tracking, win-condition
> checker, turn-limit tiebreak, match initialization from
> `FinalizedRoster` + `MapDefinition` + `PlacementSpec`, and the
> match-level state machine that wraps the units-spec turn loop.
>
> **Out of scope:** Per-unit movement / facing / progression
> (→ `TECHNICAL_SPEC_units_entities.md`), combat resolution
> (→ `TECHNICAL_SPEC_combat.md`), pre-game economy
> (→ `TECHNICAL_SPEC_economy.md`), pre-game UI flow
> (→ `ui_and_feedback.md`).

---

## 0. Conventions

- **TypeScript-flavoured pseudocode.** Same conventions as the three
  sibling specs. Type aliases and interfaces are illustrative, not a
  language target — the engine may use any language with equivalent
  type safety.
- **Pure functions by default.** Every contract returns a *new*
  `MatchState` rather than mutating the input. The exception is
  `RNG`, which is impure by construction; it is injected via
  `MatchState.rng` for deterministic replay.
- **Result discrimination.** Fallible operations return
  `Result<T, E>` (same shape as the economy spec §2.1). Successful
  ops return `{ ok: true, value: T }`; failures return
  `{ ok: false, error: E }`.
- **`PlayerIndex` is `0 | 1`** throughout — matches the units and
  economy specs. The combat spec's `PlayerId = 'P1' | 'P2'` is
  semantically identical and should be aligned in a future combat-spec
  edit. See §9 cross-ref.
- **`GridPos` is `{ row, col }`** — matches the units spec. The
  combat spec's `TileCoord = { x, y }` with `tiles[y][x]` is the same
  concept under different field names. To translate: `row === y`,
  `col === x`. See §9 cross-ref.
- **Coordinate origin.** `(row=0, col=0)` is the top-left corner.
  Row index increases southward; col index increases eastward. This
  matches the standard array-of-rows layout used by the units spec.
- **HQ placement convention.** v0.16 decision #37 fixes default HQ
  placement at bottom-left (player 0) and top-right (player 1)
  corners. Maps are handcrafted (decision #69), so a `MapDefinition`
  may specify any HQ position; the bottom-left/top-right pair is the
  conventional default but not a hard invariant.

---

## 1. Type definitions

### 1.1 Primitives

```ts
type PlayerIndex = 0 | 1;
type UnitId      = string;
type TurnNumber  = number; // monotonic, starts at 1

interface GridPos {
  row: number;
  col: number;
}

/**
 * The two-element record of per-player data. Used heavily for HQs,
 * doctrines, and outcome tracking. Always indexed by 0 and 1.
 */
type PerPlayer<T> = { 0: T; 1: T };

/** Returns the opponent of a given PlayerIndex. */
function opponentOf(p: PlayerIndex): PlayerIndex {
  return (1 - p) as PlayerIndex;
}
```

### 1.2 Tile

```ts
/**
 * One square of the board. Tile owns terrain, occupancy, and trench
 * state. Trench is a TILE PROPERTY, not a unit property — see
 * combat spec §1.3 and invariant 4.4. Re-exported here unchanged.
 */
interface Tile {
  pos: GridPos;
  terrain: TerrainType;          // → units spec §1, TerrainType enum
  occupant: UnitId | null;       // null when empty
  trench: TrenchState;           // → combat spec §1.3
}

/**
 * Mirror of combat spec §1.3 TrenchState. Re-stated here so this spec
 * is self-contained for the BoardState definition; the canonical
 * semantics live in combat spec §2.5 (trench state machine).
 */
type TrenchState =
  | { tier: 'none' }
  | { tier: 'active'; occupantId: UnitId; turnsHeld: number }
  | { tier: 'standing' }
  | { tier: 'permanent' };
```

### 1.3 BoardState

```ts
/**
 * The grid + terrain + unit positions. This is the canonical shape
 * referenced (but not previously defined) by the units, combat, and
 * economy specs. All board mutations go through pure helper functions
 * (§2.2, §2.4, §2.7) — the interface is read-only at the type level.
 *
 * Note: HQ positions live HERE on the board, not on MatchState. The
 * runtime HQ state (HP, occupation timer) lives on MatchState.hqStates.
 */
interface BoardState {
  readonly width: number;        // number of columns
  readonly height: number;       // number of rows
  readonly tiles: ReadonlyArray<ReadonlyArray<Tile>>;  // tiles[row][col]
  readonly hqPositions: PerPlayer<GridPos>;            // fixed for the match
}

/** Read helpers — every consumer uses these instead of indexing tiles directly. */
interface BoardReadOps {
  getTile(board: BoardState, pos: GridPos): Tile;       // throws on out-of-bounds
  getTerrain(board: BoardState, pos: GridPos): TerrainType;
  getOccupant(board: BoardState, pos: GridPos): UnitId | null;
  getTrench(board: BoardState, pos: GridPos): TrenchState;
  isInBounds(board: BoardState, pos: GridPos): boolean;
  hqPositionOf(board: BoardState, owner: PlayerIndex): GridPos;
}

/** Write helpers — return a new BoardState. Mutation is forbidden. */
interface BoardWriteOps {
  setOccupant(board: BoardState, pos: GridPos, occupant: UnitId | null): BoardState;
  setTrench(board: BoardState, pos: GridPos, trench: TrenchState): BoardState;
  // Terrain is immutable post-initialization; no setTerrain.
  // hqPositions are immutable post-initialization; no setHqPosition.
}
```

> **Implementation note.** `BoardReadOps` and `BoardWriteOps` are
> grouped as separate interfaces purely for documentation. In the
> engine they may be exported as free functions (`getTile(board, pos)`),
> as members of a `Board` class, or as a frozen record of methods.
> The two-tier read/write split is the contract; the surface form is
> not.

### 1.4 HQState

```ts
/**
 * Live, per-HQ runtime state. One per player. The HQ's *position* is
 * static and lives on BoardState.hqPositions; this struct holds only
 * the values that change during the match.
 */
interface HQState {
  readonly owner: PlayerIndex;

  /** Current HQ HP. Starts at HQ_MAX_HP (= 20). Never increases. */
  currentHp: number;

  /**
   * Consecutive turns at which ≥ 1 enemy unit has been within
   * HQ_REACH of the HQ at end-of-turn time. Resets to 0 if the reach
   * is empty of enemies at end-of-turn. Capture fires at
   * HQ_OCCUPATION_TURNS_TO_CAPTURE (= 5).
   *
   * NOTE: This is a per-HQ timer, NOT a per-unit timer. See §6 Q1
   * for the alternative interpretation (per-unit) that was rejected.
   */
  enemyOccupationTurns: number;

  /** True once HP hits 0 OR enemyOccupationTurns hits the threshold. */
  captured: boolean;

  /** Which path triggered the capture. null while alive. */
  captureCause: 'damage' | 'occupation' | null;
}
```

### 1.5 WinConditionState and GameOutcome

```ts
/**
 * One of four outcomes. Set on MatchState.outcome the moment a
 * win condition fires OR the turn limit is reached.
 */
type GameOutcome =
  | { kind: 'in_progress' }
  | { kind: 'win'; winner: PlayerIndex; reason: WinReason }
  | { kind: 'draw'; reason: 'turn_limit_equal_hq_hp' };

type WinReason =
  | 'hq_damage'         // opponent's HQ HP reached 0
  | 'hq_occupation'     // opponent's HQ held under enemy reach for 5 turns
  | 'turn_limit_hq_hp'; // turn cap reached, this player has more HQ HP

/**
 * Aggregate of HQ + match clock for the win-condition checker.
 * Never stored — derived from MatchState fields by checkWinCondition().
 */
interface WinConditionView {
  readonly hq: PerPlayer<{ currentHp: number; captured: boolean; cause: 'damage' | 'occupation' | null }>;
  readonly turnNumber: TurnNumber;
  readonly turnLimit: number;
}
```

### 1.6 MatchState

```ts
/**
 * The canonical match container. All in-game systems read and return
 * MatchState; the units, combat, and economy specs all reference it.
 *
 * This spec OWNS this type. Where the units spec says GameState or the
 * combat spec says MatchState, both refer to this struct. Drift
 * between specs is a documentation gap to be reconciled — the in-engine
 * type is this one.
 */
interface MatchState {
  readonly board: BoardState;

  /** All living units. Dead units are removed (NOT marked dead-in-place). */
  readonly units: ReadonlyMap<UnitId, UnitState>; // → units spec §9

  /** Doctrine selected pre-game by each player. Frozen at match start. */
  readonly doctrines: PerPlayer<DoctrineType>;    // → units spec §1

  /** Live HQ state per player. */
  readonly hqStates: PerPlayer<HQState>;

  /** 1-indexed; increments after BOTH players have completed a turn. See §3. */
  readonly turnNumber: TurnNumber;

  /** Hard cap. Defaults to TURN_LIMIT (= 1000); may be overridden per match. */
  readonly turnLimit: number;

  /** Whose turn it is currently. */
  readonly activePlayer: PlayerIndex;

  /** Per-turn phase from the units spec. See units spec §10.1. */
  readonly turnPhase: TurnPhase;                  // → units spec §10.1

  /** Match-level phase. See §3. */
  readonly matchPhase: MatchPhase;

  /** Set once the match concludes; null while in_progress. */
  readonly outcome: GameOutcome;

  /**
   * Injected RNG for combat rolls and any other stochastic system.
   * Determinism: a fixed seed → identical match playback. Required
   * for replay tests and AI search.
   */
  readonly rng: () => number;                     // returns uniform [0, 1)

  /** Optional history of actions, for replay/serialization. Engine choice. */
  readonly actionHistory?: readonly PlayerAction[]; // → units spec §10.1
}
```

### 1.7 MapDefinition

```ts
/**
 * Static, designer-authored map content. Loaded once at match start;
 * does not change during play. Maps are handcrafted (decision #69) —
 * there is no procedural generation contract.
 */
interface MapDefinition {
  readonly id: string;             // e.g. "map_river_valley"
  readonly displayName: string;
  readonly width: number;
  readonly height: number;
  readonly terrain: ReadonlyArray<ReadonlyArray<TerrainType>>; // [row][col]

  /** Where each player's HQ sits. Default convention: P0 bottom-left, P1 top-right. */
  readonly hqPositions: PerPlayer<GridPos>;

  /**
   * Each player's "own half" — the set of legal placement tiles for
   * their pre-game unit setup (decision #68). In the standard split,
   * this is a horizontal or vertical bisection of the board, but the
   * map author may shape it freely (e.g. a diagonal split, an
   * asymmetric map). Tiles outside both halves are no-mans-land and
   * are placeable by neither.
   */
  readonly playerHalves: PerPlayer<ReadonlySet<string>>;
  // Set keys are coord strings: `${row},${col}`. The Set datatype
  // gives O(1) lookup during placement validation.
}
```

### 1.8 PlacementSpec

```ts
/**
 * Per-player placement of finalized roster units onto the board.
 * Produced by the pre-game placement UI (after economy's
 * FinalizedRoster is committed) and consumed by initializeMatch().
 *
 * Every UnitId in FinalizedRoster.units MUST appear exactly once.
 * Validation rules in §2.8.
 */
interface PlacementSpec {
  readonly playerIndex: PlayerIndex;
  readonly unitPositions: ReadonlyMap<UnitId, GridPos>;

  /**
   * Optional facing override. If absent, the unit takes the default
   * spawn facing (units spec §4.2 defaultSpawnFacing — "both sides
   * face each other", v0.18 decision #65).
   */
  readonly unitFacings: ReadonlyMap<UnitId, Facing>;
}
```

---

## 2. Function contracts

### 2.1 Match initialization

```ts
/**
 * Construct the initial MatchState from two FinalizedRosters, two
 * PlacementSpecs, and a MapDefinition. Pure function: no I/O, no
 * mutation of inputs.
 *
 * @returns Result<MatchState, InitializationError>
 *
 * The returned MatchState has:
 *   matchPhase   = MatchPhase.InProgress
 *   turnPhase    = TurnPhase.PlayerTurnStart
 *   activePlayer = 0
 *   turnNumber   = 1
 *   outcome      = { kind: 'in_progress' }
 *   hqStates     = both at HQ_MAX_HP, occupation = 0, captured = false
 *
 * Per-unit setup:
 *   - Each RosterEntry → one UnitState (units spec §9).
 *   - rank, type from RosterEntry.
 *   - pos from PlacementSpec.unitPositions.
 *   - facing from PlacementSpec.unitFacings, falling back to
 *     defaultSpawnFacing(owner, board).
 *   - currentHp = maxHp(type) (units spec §2).
 *   - stamina reset by resetStaminaForPlayer (units spec §10.3) —
 *     happens implicitly as part of PlayerTurnStart.
 *
 * Trench seeding:
 *   - For each RosterEntry where startsEntrenched === true, the unit's
 *     tile receives a TrenchState of { tier: 'active', occupantId: unit.id,
 *     turnsHeld: 3 }. This bypasses the normal 3-turn timer (combat
 *     spec §2.5, §5.6). Gated by combat invariant 4.7 (heavy classes
 *     can never trench) — already enforced by economy
 *     canSpawnEntrenched(); a redundant check here defensively rejects
 *     malformed input.
 *
 * Formation seeding:
 *   - For each pair in FinalizedRoster.formationPairs, the units-spec
 *     formation system (§5) registers the pair. Eligibility (light
 *     class only) is gated by economy canFormFormation(); redundant
 *     check rejects malformed input.
 */
function initializeMatch(
  rosters: PerPlayer<FinalizedRoster>,    // → economy spec §1.4
  placements: PerPlayer<PlacementSpec>,
  map: MapDefinition,
  rngSeed: number,
  options?: { turnLimit?: number },
): Result<MatchState, InitializationError>;

abstract class InitializationError extends Error { abstract readonly kind: string; }
class PlacementValidationError extends InitializationError {
  readonly kind = 'PlacementValidation' as const;
  constructor(public readonly violations: readonly string[]) {
    super(`Placement invalid: ${violations.join('; ')}`);
  }
}
class MapValidationError extends InitializationError {
  readonly kind = 'MapValidation' as const;
  constructor(public readonly reason: string) { super(reason); }
}
class RosterMismatchError extends InitializationError {
  readonly kind = 'RosterMismatch' as const;
  constructor(public readonly reason: string) { super(reason); }
  // Fires if PlacementSpec.unitPositions keys don't match
  // FinalizedRoster.units exactly (extras OR missing).
}
```

### 2.2 HQ reach helpers

```ts
/**
 * Returns every tile within HQ_REACH of the given HQ. Reach is a
 * Chebyshev (king-move) distance, including diagonals. The HQ tile
 * itself IS included in the reach set.
 *
 * @param hqPos The HQ's tile.
 * @param board Used only for in-bounds clamping at edges/corners.
 * @returns Up to (2 * HQ_REACH + 1)² tiles, fewer if the HQ is in a
 *   corner or near an edge.
 */
function getHqReachTiles(
  hqPos: GridPos,
  board: BoardState,
): readonly GridPos[];

/**
 * Returns every unit owned by `attacker` whose position is in the
 * given HQ's reach. "Attacker" here means "the player whose units are
 * threatening the HQ" — i.e. the OPPONENT of the HQ owner.
 */
function enemiesInHqReach(
  state: MatchState,
  hqOwner: PlayerIndex,
): readonly UnitState[];
```

### 2.3 HQ damage tick

```ts
/**
 * Passive-aura damage application. Fires at end of the just-acted
 * player's turn. For the OPPONENT'S HQ, every unit owned by the
 * just-acted player that sits within HQ_REACH at this instant
 * contributes HQ_DAMAGE_PER_ENEMY_PER_TURN damage to the HQ.
 *
 * Each unit counts AT MOST ONCE per tick, regardless of position
 * geometry (a unit cannot stack damage by being in multiple "reach
 * directions" simultaneously — there is only one reach per HQ).
 *
 * The just-acted player's OWN HQ is unaffected by this tick — there
 * is no friendly-fire or self-damage.
 *
 * Damage is clamped at HQ_MIN_HP (= 0). Damage past 0 is dropped
 * (the win condition fires the first time HP hits 0; further damage
 * is meaningless).
 *
 * @returns A new MatchState with the opponent HQ's currentHp reduced.
 *
 * IMPORTANT: HQ_DAMAGE_PER_ENEMY_PER_TURN is FLAGGED — see §6 Q3.
 * The numeric value is unspecified in game_core.md. This spec uses a
 * placeholder of 1 that produces clean math (4 enemies × 1 dmg ×
 * 5 turns = 20 = full damage path) but the value MUST be confirmed
 * before code freeze.
 */
function applyHqDamageTick(
  state: MatchState,
  justActedPlayer: PlayerIndex,
): MatchState;
```

### 2.4 HQ occupation tracking

```ts
/**
 * Per-HQ occupation timer update. Fires at end of the just-acted
 * player's turn, AFTER applyHqDamageTick.
 *
 * Logic for the OPPONENT'S HQ:
 *   - If enemiesInHqReach(state, opponent) is non-empty:
 *       hqStates[opponent].enemyOccupationTurns += 1
 *   - Otherwise:
 *       hqStates[opponent].enemyOccupationTurns = 0
 *
 * Note that "enemy" from the HQ's perspective = the just-acted player.
 *
 * This is a PER-HQ timer, not per-unit. As long as ≥ 1 of the
 * just-acted player's units occupies the reach at end-of-turn, the
 * counter ticks. If the reach is fully cleared, the counter resets
 * — even if a fresh unit arrives the very next turn. See §6 Q1 for
 * the rejected per-unit interpretation.
 *
 * @returns A new MatchState with the opponent HQ's
 *   enemyOccupationTurns updated.
 */
function applyHqOccupationTick(
  state: MatchState,
  justActedPlayer: PlayerIndex,
): MatchState;
```

### 2.5 Win-condition checker

```ts
/**
 * Pure function. Evaluates all win paths against the current state
 * and returns the GameOutcome. Does NOT mutate state.
 *
 * Order of precedence (matters when multiple fire on the same tick):
 *   1. HQ damage path: any HQ at currentHp ≤ 0 → opponent wins.
 *   2. HQ occupation path: any HQ at enemyOccupationTurns ≥
 *      HQ_OCCUPATION_TURNS_TO_CAPTURE → opponent wins.
 *   3. Turn limit path: turnNumber > turnLimit → tiebreak by HQ HP.
 *   4. Otherwise: { kind: 'in_progress' }.
 *
 * Both-sides-win edge case: if both HQs hit a capture threshold on
 * the same tick (extremely rare — would require simultaneous
 * resolution which the IGOUGO loop forbids), the side that fired
 * FIRST in this evaluation order wins. This is a defensive choice;
 * in practice, IGOUGO sequencing makes simultaneous capture
 * unreachable.
 */
function checkWinCondition(state: MatchState): GameOutcome;
```

### 2.6 Turn-limit tiebreak

```ts
/**
 * Resolves the outcome when turnNumber exceeds turnLimit without an
 * HQ capture. Decision #70: highest remaining HQ HP wins; equal
 * HP is a draw.
 *
 * @returns
 *   - { kind: 'win', winner: ..., reason: 'turn_limit_hq_hp' } if
 *     one side has strictly more HQ HP.
 *   - { kind: 'draw', reason: 'turn_limit_equal_hq_hp' } if tied.
 *
 * Called only by checkWinCondition() when path 3 is reached. Not
 * intended as a public entry point.
 */
function resolveTimeoutOutcome(state: MatchState): GameOutcome;
```

### 2.7 End-of-turn hook

```ts
/**
 * Match-level hook called by the units-spec applyEndTurn() AFTER its
 * own per-unit bookkeeping (Blitzkrieg still-penalty update, trench
 * advancement). Returns the new MatchState with HQ ticks applied
 * and outcome possibly set.
 *
 * Order of operations (atomic — runs as one transition):
 *   1. applyHqDamageTick(state, justActedPlayer)
 *      → opponent HQ HP may decrease.
 *   2. applyHqOccupationTick(state', justActedPlayer)
 *      → opponent HQ enemyOccupationTurns updated.
 *   3. checkWinCondition(state'')
 *      → outcome set (or remains in_progress).
 *   4. If outcome.kind === 'win' or 'draw':
 *        matchPhase ← MatchPhase.Ended
 *        turnPhase  ← TurnPhase.GameOver
 *        Skip turn handoff.
 *      Else:
 *        Increment turnNumber if and only if justActedPlayer === 1
 *        (turn count = full round of both players).
 *        Hand off to opponent (resetStaminaForPlayer in units spec).
 *
 * Re-entrancy: this function is the single point where outcome flips
 * from in_progress to win/draw. Once outcome ≠ in_progress, no
 * further actions are accepted (units spec applyAction throws on
 * GameOver phase).
 */
function processMatchEndOfTurn(
  state: MatchState,
  justActedPlayer: PlayerIndex,
): MatchState;
```

### 2.8 Placement validation

```ts
/**
 * Validates that a per-player PlacementSpec is consistent with its
 * FinalizedRoster and the MapDefinition's player half.
 *
 * Returns a list of human-readable violations. Empty list means
 * placement is legal.
 *
 * Checks performed:
 *   V1. Roster coverage: PlacementSpec.unitPositions has exactly the
 *       same UnitId set as FinalizedRoster.units.
 *   V2. Half containment: every position is in
 *       MapDefinition.playerHalves[playerIndex].
 *   V3. No overlap: no two units share a position (within this
 *       player's roster — cross-player overlap is checked by
 *       initializeMatch).
 *   V4. HQ exclusion: no unit is placed on either HQ tile.
 *   V5. Terrain legality: each unit type can stand on its assigned
 *       terrain (mountains forbidden for all units except artillery
 *       — see units spec §2.5).
 *   V6. Facings: every facing override is one of N/S/E/W (Facing
 *       enum from units spec §1).
 *   V7. Entrenchment-tile match: for any RosterEntry with
 *       startsEntrenched === true, the placement tile's terrain
 *       must allow trenching (combat invariant 4.6 — swamp blocks
 *       trenching).
 */
function validatePlacement(
  placement: PlacementSpec,
  roster: FinalizedRoster,    // → economy spec §1.4
  map: MapDefinition,
): readonly string[];

/**
 * Cross-player check: ensures the two PlacementSpecs don't overlap
 * each other (one player placed a unit on a tile the other player
 * also claimed — only possible if the map's playerHalves overlap,
 * which is itself a map-author bug, OR if both halves include a
 * shared no-man's-land tile that both filled).
 */
function validateCrossPlayerPlacement(
  p0: PlacementSpec,
  p1: PlacementSpec,
): readonly string[];
```

---

## 3. Match-level state machine

The match-level machine is one level above the per-turn machine
defined in the units spec §10. It tracks the match's overall lifecycle:
not started → playing → ended.

### 3.1 States

```ts
enum MatchPhase {
  /**
   * Pre-match. Both players are completing pre-game setup (economy
   * spec §3 PreGameSetupState + placement). MatchState does not
   * exist yet during Setup; this enum value is included for
   * symmetry but is never observable on a live MatchState.
   */
  Setup = 'setup',

  /**
   * Live match. The units-spec turn loop runs; processMatchEndOfTurn
   * fires after each applyEndTurn. The active player alternates.
   */
  InProgress = 'in_progress',

  /**
   * Match concluded. outcome is set to a 'win' or 'draw' variant.
   * No further actions are legal (applyAction throws). The state
   * is preserved for postgame UI / replay / stats.
   */
  Ended = 'ended',
}
```

### 3.2 Transitions

```
                   ┌─────────────────────────────────────────────┐
                   │                                             │
                   │   (no MatchState yet — see economy spec)    │
                   │                                             │
                   │     PreGameSetupState (per player)          │
                   │           │                                 │
                   │           ▼ both players' finalizeSetup() + │
                   │             both PlacementSpecs validated    │
                   │           │                                 │
                   │           ▼                                 │
                   │     initializeMatch()                       │
                   │           │                                 │
                   └───────────┼─────────────────────────────────┘
                               ▼
                       ┌──────────────┐
                       │ InProgress   │ ◄────────────────┐
                       │              │                  │
                       └──────┬───────┘                  │
                              │                          │
              units-spec applyAction(...)                │
                              │                          │
                              ▼                          │
                       (per-turn loop runs;              │
                        processMatchEndOfTurn fires      │
                        on every applyEndTurn)           │
                              │                          │
                              │  outcome = in_progress?  │
                              │ ────────────────────── yes (loop continues)
                              │                          │
                              │ outcome = win | draw?    │
                              │                          │
                              ▼                          │
                       ┌──────────────┐                  │
                       │ Ended        │                  │
                       │              │                  │
                       │ (terminal —  │                  │
                       │  no further  │                  │
                       │  transitions)│                  │
                       └──────────────┘                  │
```

| From → To | Trigger | Guard | onEntry effects |
|---|---|---|---|
| (none) → InProgress | `initializeMatch()` returns ok | All inputs valid (V1–V7 + cross-player) | Construct MatchState; outcome = in_progress; activePlayer = 0; turnNumber = 1; HQs at full HP; stamina reset for P0 |
| InProgress → Ended | `processMatchEndOfTurn()` sets outcome ≠ in_progress | A win path or turn limit fired | `matchPhase = Ended`; `turnPhase = GameOver`; freeze MatchState (no further mutations) |
| InProgress → InProgress | `processMatchEndOfTurn()` keeps outcome = in_progress | No win path; turn limit not exceeded | Increment `turnNumber` iff `justActedPlayer === 1`; `activePlayer = opponent`; `turnPhase = PlayerTurnStart`; `resetStaminaForPlayer(opponent)` (units spec §10.3) |

### 3.3 Integration with the units-spec turn loop

The units spec `applyAction()` (§10.2) is the public action entry
point. It dispatches `move`, `attack`, `rotate`, `endTurn`, etc.
This game-core spec adds one integration point:

> When `action.kind === 'endTurn'`, the units-spec `applyEndTurn()`
> runs its own bookkeeping (still-penalty update, trench advancement)
> and then calls `processMatchEndOfTurn(state, activePlayer)`. The
> result is the new `MatchState`. If `outcome ≠ in_progress`, the
> caller observes `matchPhase === Ended` and ends the match.

There is no other integration. Mid-turn actions (move, attack, etc.)
do NOT trigger HQ ticks — passive aura damage is strictly
end-of-turn (per §2.3). This keeps tick semantics atomic and
predictable.

---

## 4. Constants & configuration

```ts
/**
 * Single authoritative constants block for game-core.
 * Engine code reads from here; no other module redefines these.
 */
const GAME_CORE_CONFIG = {

  // --- HQ ---
  HQ_MAX_HP: 20,                          // game_core.md §1.2 path 2
  HQ_MIN_HP: 0,
  HQ_REACH:  3,                           // game_core.md §1.2 (Chebyshev radius)
  HQ_OCCUPATION_TURNS_TO_CAPTURE: 5,      // game_core.md §1.2 path 1

  /**
   * Per-enemy-per-turn passive-aura damage.
   *
   * ⚠ FLAGGED — value not specified in game_core.md §1.2. See §6 Q3.
   * Using 1 as a placeholder produces clean math: 4 enemies × 1 dmg ×
   * 5 turns = 20, exactly aligning the damage and occupation paths.
   * MUST be confirmed before code freeze.
   */
  HQ_DAMAGE_PER_ENEMY_PER_TURN: 1,

  // --- Turn limit ---
  TURN_LIMIT: 1000,                       // game_core.md §1.8, decision #70

  // --- Match defaults ---
  STARTING_TURN_NUMBER: 1,
  STARTING_ACTIVE_PLAYER: 0 as PlayerIndex,

  // --- Damage clamp ---
  // The combat-spec damage floor (= 1, except bounce rule) applies to
  // unit-vs-unit attacks. HQ damage uses its own floor of 0 (HP
  // cannot go negative). The bounce rule does NOT apply to HQs.
  HQ_DAMAGE_FLOOR: 0,

} as const;

// Convenience exports — the values most consumers actually want.
const HQ_MAX_HP                       = GAME_CORE_CONFIG.HQ_MAX_HP;
const HQ_REACH                        = GAME_CORE_CONFIG.HQ_REACH;
const HQ_OCCUPATION_TURNS_TO_CAPTURE  = GAME_CORE_CONFIG.HQ_OCCUPATION_TURNS_TO_CAPTURE;
const HQ_DAMAGE_PER_ENEMY_PER_TURN    = GAME_CORE_CONFIG.HQ_DAMAGE_PER_ENEMY_PER_TURN;
const TURN_LIMIT                      = GAME_CORE_CONFIG.TURN_LIMIT;
```

---

## 5. Invariants

These are properties that must hold at every observable MatchState
(i.e. between function calls; inside a function the invariants may
be temporarily violated, but the returned value must restore them).

### 5.1 HQ HP bounds
For each `p ∈ {0, 1}`:
```
0 ≤ hqStates[p].currentHp ≤ HQ_MAX_HP
```

### 5.2 HQ HP monotonicity
HQ HP only decreases. There is no healing path. For any two
sequential `MatchState`s `s` and `s'`:
```
s'.hqStates[p].currentHp ≤ s.hqStates[p].currentHp
```

### 5.3 Captured implies threshold met
`hqStates[p].captured === true` if and only if:
```
currentHp === 0  OR  enemyOccupationTurns ≥ HQ_OCCUPATION_TURNS_TO_CAPTURE
```
And `captureCause` is non-null exactly when `captured === true`.

### 5.4 Captured is sticky
Once `captured === true`, it never returns to false. (No revival
path exists. Ties to invariant 5.2.)

### 5.5 Outcome consistency
`outcome.kind === 'in_progress'` if and only if:
```
hqStates[0].captured === false  AND
hqStates[1].captured === false  AND
turnNumber ≤ turnLimit
```
Equivalently: as soon as any termination predicate is true,
`outcome ≠ in_progress`.

### 5.6 MatchPhase / outcome alignment
```
matchPhase === Ended   ⟺  outcome.kind ∈ { 'win', 'draw' }
matchPhase === InProgress ⟺  outcome.kind === 'in_progress'
```
The Setup phase is never observable on a live `MatchState`.

### 5.7 ActivePlayer alternation
Across consecutive `InProgress` states resulting from `applyEndTurn`:
```
s'.activePlayer === opponentOf(s.activePlayer)
```
Mid-turn states (where `turnPhase === UnitAction`) keep the same
`activePlayer`.

### 5.8 Trench is tile-state, not unit-state
Re-stated from combat invariant 4.4 because BoardState owns the
tile-trench data: no `UnitState` field carries trench info. This
spec's `Tile.trench` is the single source of truth.

### 5.9 HQ position immutability
`board.hqPositions[p]` is set at `initializeMatch()` and never changes.

### 5.10 RNG isolation
The injected `rng` is read by combat resolution and any other
stochastic system. The end-of-turn HQ tick is **deterministic** —
it does not consult `rng`. Replay tests rely on this.

### 5.11 Turn-number monotonicity
`turnNumber` is non-decreasing across the match and increments by
exactly 1 when player 1 ends their turn (i.e. one increment per
full round of both players' turns).

### 5.12 Self-damage exclusion
A player's own units never contribute to their own HQ's tick (§2.3
"the just-acted player's OWN HQ is unaffected"). Friendly fire on
HQs is impossible.

---

## 6. Open questions / scope-deferred

These are items where `game_core.md` is silent or ambiguous and the
spec has had to make a working choice. Each is flagged for design
review before code freeze.

### Q1 — Per-HQ vs per-unit occupation timer
**Source:** `game_core.md §1.2` capture condition #1.
**Prose:** *"A unit stays inside the HQ's reach for 5 turns → HQ captured."*
**Ambiguity:** "A unit stays" reads as per-unit (unit X has been there
for N turns). But a per-unit reading creates state that is harder to
serialize and more brittle ("what if Unit A is there for 4 turns,
leaves, and Unit B arrives — does the timer reset, or carry?").
**Spec choice:** Per-HQ — the timer ticks if **≥ 1** opposing unit
sits in reach at end-of-turn, and resets if **0** do. Continuity of
*any* opposing unit holds the timer; identity does not matter.
**Confirm with designer:** Is this the intended reading? If per-unit,
the `HQState.enemyOccupationTurns: number` field becomes
`enemyOccupationTurns: Map<UnitId, number>` and the tick logic
changes accordingly.

### Q2 — Tick frequency
**Source:** `game_core.md §1.2` damage trigger.
**Prose:** *"When an enemy unit is within the HQ's 3-square reach,
the HQ takes damage."*
**Ambiguity:** Does the HQ tick at end of *every* player turn (so
both P0 and P1 trigger ticks against their respective opponents'
HQs), or only at end of the *attacker's* turn (one tick per HQ per
round)?
**Spec choice:** End of the just-acted player's turn, against the
just-acted player's opponent's HQ. Each HQ ticks at most once per
round (when its threatener has just finished a turn). This matches
"when an enemy is in reach" most cleanly: P0's units threaten P1's
HQ, so P1's HQ ticks when P0 ends their turn, and vice versa.
**Confirm with designer:** Is this correct, or is the intended model
"both HQs tick every end-of-turn"?

### Q3 — Per-tick damage amount [HIGH PRIORITY]
**Source:** `game_core.md §1.2` damage trigger.
**Prose:** *"The HQ takes damage."*
**Ambiguity:** The amount per tick per enemy unit is fully
unspecified. The 20-HP cap is set but the rate at which damage
accumulates is not.
**Spec choice:** `HQ_DAMAGE_PER_ENEMY_PER_TURN = 1` as a
placeholder, chosen because it makes the two win paths converge:
4 enemies camping in reach for 5 turns deal exactly 20 damage AND
trigger the 5-turn occupation, which is mathematically clean.
**Confirm with designer:** Is the rate flat-1, or unit-typed (e.g.
infantry 1, tank 2, artillery 3)? Is it a flat aggregate (e.g. "1
damage per tick if any enemy is in reach, ignoring count")? This
is the single most consequential decision among the open
questions — engine balance depends on it.

### Q4 — HQ as targetable unit
**Source:** `game_core.md §1.2` capture path 2 (damage).
**Prose:** *"the HQ is dealt 20 damage (cumulative, by any unit)."*
**Ambiguity:** Decision-locked to passive aura per this session, but
a future ruleset revision might layer active attacks on top of the
passive aura (e.g. an artillery unit explicitly targeting the HQ
deals more damage than the passive trickle). The current spec does
NOT permit `resolveAttack()` against an HQ as defender — the combat
spec's `AttackContext` requires `defenderId: UnitId`, and HQs are
not units.
**Spec choice:** HQs are **not** valid targets for `resolveAttack()`.
All HQ damage flows through `applyHqDamageTick`. If active HQ
attacks are added later, this spec will need a `HQDamageEvent`
union and combat will need an attacker→HQ codepath.
**Confirm with designer:** Is "passive aura only" the final design,
or is a hybrid intended?

### Q5 — Map.playerHalves shape
**Source:** `game_core.md §1.4` (handcrafted maps) + decision #68
(half-and-half free placement).
**Prose:** *"board halved, free placement within your half."*
**Ambiguity:** The "halving" geometry isn't fixed. For a square
board the obvious split is horizontal at `row = height / 2`, but
asymmetric maps can split diagonally, or even leave a no-man's-land
band in the middle.
**Spec choice:** `playerHalves` is a per-player set of tile coords
on `MapDefinition` — the map author defines the shape. The engine
treats halves as opaque sets and does not enforce a particular
geometry.
**Confirm with designer:** Is there a default geometry the engine
should apply when the map omits `playerHalves`? Or is the field
mandatory?

### Q6 — Real-time wall-clock tiebreak
**Source:** `game_core.md §1.8`.
**Prose:** *"Implementations may also impose a wall-clock match
timer; if either limit is reached, the same tiebreak applies."*
**Ambiguity:** This spec defines the 1000-turn cap concretely
(`turnLimit`) and applies the tiebreak when `turnNumber > turnLimit`.
The wall-clock timer is "optional per implementation" — should this
spec define a contract for it (e.g. `wallClockLimitMs?: number` on
MatchState), or is it left entirely to the runtime?
**Spec choice:** Out of scope for v1 of this spec. The
turn-number cap is the canonical mechanism; a wall-clock layer
sits above the spec and triggers `resolveTimeoutOutcome` directly
when it expires. No schema field for it.
**Confirm with designer:** Acceptable for now, or should the
schema include the optional timer field?

---

## 7. Cross-reference index

| Rule (game_core.md) | Source | Computable location in this spec |
|---|---|---|
| §1.1 Digital game | game_core.md §1.1 | (no contract — platform note) |
| §1.2 Win condition: HQ capture | game_core.md §1.2 | §1.4 `HQState`, §1.5 `GameOutcome`, §2.5 `checkWinCondition()` |
| §1.2 HQ placement (BL/TR corners) | game_core.md §1.2, decision #37 | §1.7 `MapDefinition.hqPositions` (default convention; per-map override allowed via decision #69) |
| §1.2 HQ reach = 3 | game_core.md §1.2 | §4 `GAME_CORE_CONFIG.HQ_REACH`; §2.2 `getHqReachTiles()` |
| §1.2 Damage trigger (passive aura) | game_core.md §1.2 (resolved this session) | §2.3 `applyHqDamageTick()`; per-tick damage amount FLAGGED §6 Q3 |
| §1.2 Capture path 1: 5-turn occupation | game_core.md §1.2 | §2.4 `applyHqOccupationTick()`; §1.4 `HQState.enemyOccupationTurns` |
| §1.2 Capture path 2: 20 damage | game_core.md §1.2 | §1.4 `HQState.currentHp`; §4 `HQ_MAX_HP`; §5.1 invariant |
| §1.2 Tiebreak at turn limit | game_core.md §1.2, §1.8 | §2.6 `resolveTimeoutOutcome()` |
| §1.3 Dice = 1d6 | game_core.md §1.3 | → `TECHNICAL_SPEC_combat.md §1.5` (resolveAttack RNG) |
| §1.3 Damage floor (≥ 1, except bounce) | game_core.md §1.3 | → `TECHNICAL_SPEC_combat.md §4.1` (unit-vs-unit only); §4 `HQ_DAMAGE_FLOOR = 0` for HQs |
| §1.4 Square grid + 8 directions | game_core.md §1.4 | §1.3 `BoardState`; → `TECHNICAL_SPEC_units_entities.md §1` (Direction enum) |
| §1.4 Maps are handcrafted | game_core.md §1.4, decision #69 | §1.7 `MapDefinition` |
| §1.4 Four terrain types | game_core.md §1.4 | → `TECHNICAL_SPEC_units_entities.md §1` (TerrainType enum) |
| §1.5 Unit facing (4 facings) | game_core.md §1.5 | → `TECHNICAL_SPEC_units_entities.md §4` |
| §1.5 Default spawn facing (face each other) | game_core.md §1.5, decision #65 | → `TECHNICAL_SPEC_units_entities.md §4.2 defaultSpawnFacing()`; §1.8 `PlacementSpec.unitFacings` overrides |
| §1.5 Free rotation, no penalty | game_core.md §1.5, decision #66 | → `TECHNICAL_SPEC_units_entities.md §10.2` |
| §1.6 IGOUGO turn structure | game_core.md §1.6 | §3 `MatchPhase`; → `TECHNICAL_SPEC_units_entities.md §10` |
| §1.6 2 actions per unit | game_core.md §1.6, decision #39 | → `TECHNICAL_SPEC_units_entities.md §10.3 UnitStaminaState` |
| §1.7 Design philosophy | game_core.md §1.7 | (no contract — design note) |
| §1.8 1000-turn cap | game_core.md §1.8, decision #70 | §4 `TURN_LIMIT`; §2.5 `checkWinCondition()` path 3 |
| §1.8 No mid-game reinforcements | game_core.md §1.8, decision #71 | → `TECHNICAL_SPEC_economy.md §3.6` (post-finalize, no economy state) |
| §1.8 Optional wall-clock timer | game_core.md §1.8 | OUT OF SCOPE — see §6 Q6 |
| FinalizedRoster ingestion | economy.md §E.5 | §2.1 `initializeMatch()`; consumes `FinalizedRoster.units` (→ unit list), `formationPairs` (→ formation registration), `pointsForfeit` (audit-only, not read) |
| Pre-game placement | game_core.md §1.4, decision #68 | §1.8 `PlacementSpec`; §2.8 `validatePlacement()` |
| Trench seeding from spawn-entrenched | combat.md §5.6, economy §E.4 | §2.1 `initializeMatch()` (sets `TrenchState` to `active` with `turnsHeld = 3`) |
| MatchState shape (canonical) | (this spec) | §1.6 `MatchState` — referenced as `GameState` in units spec §10 and `MatchState` in combat spec §1.4. This spec is authoritative. |

### Cross-spec drift to reconcile

These are documentation-only mismatches that should be aligned in a
future pass. The runtime types are defined here; sibling specs use
slightly different names/shapes.

| Concept | This spec | units spec | combat spec | economy spec |
|---|---|---|---|---|
| Match container | `MatchState` | `GameState` | `MatchState` | (n/a — ends at FinalizedRoster) |
| Player identifier | `PlayerIndex = 0 \| 1` | `PlayerIndex = 0 \| 1` | `PlayerId = 'P1' \| 'P2'` | `PlayerIndex = 0 \| 1` |
| Tile coordinate | `GridPos = { row, col }` | `GridPos = { row, col }` | `TileCoord = { x, y }`, `tiles[y][x]` | (n/a) |
| Board container | `BoardState` | `BoardState` (referenced, not shaped) | `Board` | (n/a) |
| Motorised infantry id | (delegates to units) | `motorised_inf` | `motorized_infantry` | `motorised_inf` |

Recommended resolution: pick `MatchState`, `PlayerIndex`, `GridPos`,
`BoardState`, `motorised_inf` as the canonical names (the majority
already match). Update combat spec in a follow-up pass.

---

*End of TECHNICAL_SPEC_game_core.md*

*With this spec produced, all four sibling specs
(units, combat, economy, game_core) exist. The combat resolver,
pre-game economy module, and per-unit turn loop are now fully
implementable from spec. Recommended next: `COMBAT_TEST_CASES.md`
(now unblocked — combat spec §4 invariants + game_core §5
invariants are property-test seeds), and the cross-spec drift
reconciliation pass identified in §7.*
