# Strategy Game — Current Status

> **Read this first** at the start of every new chat. This file is
> the single source of truth for *where the design is right now*.
>
> **Update this file at the end of every session.** Overwrite freely —
> history lives in `CHANGELOG.md`, this file is just the current
> snapshot.

---

## At a glance

| Field | Value |
|---|---|
| Current version | **v1.5** |
| Last updated | **2026-05-08** |
| Ruleset version | **v0.18** (frozen — base ruleset closed) |
| Overall completion | **~100%** (ruleset closed; **all 4 specs done**; **`COMBAT_TEST_CASES.md` v1.0 done**; only UI/UX wireframes outstanding) |
| Files in document set | 7 rule files + **4 spec files** + **1 test-cases file** |
| Open rule questions | **0 base-ruleset items**; ~3 UI-layout items in `ui_and_feedback.md`; **6 spec-translation items** in `TECHNICAL_SPEC_combat.md §5` + **1 new clarification item** (Q-07) surfaced in `COMBAT_TEST_CASES.md §5` from CT-009 (defender-side positional gate symmetry under artillery attacker); **3 minor implementation choices** flagged in `TECHNICAL_SPEC_economy.md` (refund policy, motorised spelling, stale §E.4 "20-point" prose); **6 spec-translation items** in `TECHNICAL_SPEC_game_core.md §6` (HQ tick semantics — Q3 per-tick damage amount is HIGH PRIORITY) |
| Produced this version | `COMBAT_TEST_CASES.md` v1.0 — scenario-style test suite covering the combat module end-to-end. **10 property tests** (`P-01..P-10`) keyed to combat spec §4 invariants; **56 scenario tests** (`CT-001..CT-056`) covering geometry, reach, tactic-applicability gating, encirclement (standard + tank reach-hug), the full trench state machine, range falloff, modifier resolution (with Blitzkrieg still-penalty variants and the cavalry mountain-penalty regression pin), the main resolver (with worked-formula example + bounce-rule pin at −3 + 5-variant P-10 conjunction check), counter-attack (with bonus-die scaling pin), IGOUGO flow, and 7 edge-case regressions; **7 open-question scenarios** (`Q-01..Q-07`) promote-ready once design closes each question. Spec-section coverage matrix in Appendix A; test-runner notes in Appendix B. **No design decisions resolved this session** — the file is derivative. **One new clarification question surfaced** (Q-07: defender-side positional penalties under artillery attacker — paired-gating vs current asymmetric-gating). |

---

## Implementation spec progress

| Spec file | Status | Covers |
|---|---|---|
| `TECHNICAL_SPEC_units_entities.md` | ✅ **Done (v1.0)** | Unit roster, terrain, movement, facing, formation, trench, XP/progression, doctrines, IGOUGO state machine |
| `TECHNICAL_SPEC_combat.md` | ✅ **Done (v1.0)** | `resolveAttack()`, positional bonuses, encirclement (incl. tank reach-hug), counter-attack, bounce rule, artillery exemption, range falloff, damage floor, IGOUGO combat states, invariants. **6 deferred questions** in §5 — unblock either via design call or sibling-module spec. |
| `TECHNICAL_SPEC_economy.md` | ✅ **Done (v1.0)** | Pre-game point-buy: war-point budgets, unit/XP/spawn-bonus purchases, doctrine caps, validation, finalize-to-roster handoff, pre-game setup state machine. **3 minor implementation choices flagged** (refund policy, `motorised_inf` spelling, stale §E.4 "20-point" prose). No in-game economy hooks — confirmed `economy.md §E.5`. |
| `TECHNICAL_SPEC_game_core.md` | ✅ **Done (v1.0)** | `MatchState`/`BoardState`/`Tile`/`HQState`/`MapDefinition`/`PlacementSpec` schemas; `initializeMatch()`; HQ damage tick (passive aura) + occupation tracking; win-condition checker; turn-limit tiebreak; match-level state machine; cross-spec drift index. **6 deferred questions** in §6 (HQ tick semantics — Q3 per-tick damage amount is HIGH PRIORITY before code freeze). |
| `COMBAT_TEST_CASES.md` | ✅ **Done (v1.0)** | Scenario-style test suite: 10 property invariants (`P-01..P-10`), 56 scenario tests (`CT-001..CT-056`) across geometry/reach/encirclement/trench/range-falloff/modifiers/resolver/counter-attack/IGOUGO/regressions, 7 open-question scenarios (`Q-01..Q-07`). Spec-section coverage matrix verifies every numbered combat-spec section is exercised. **1 new clarification question surfaced** (Q-07 — artillery defender-side gate symmetry; flagged from CT-009). |

---

## Ruleset completion by system

| System | % | Status |
|---|---|---|
| Infantry (full unit) | 100 | ✅ Done |
| Cavalry (full unit) | 100 | ✅ Done |
| Tanks (full stats + tactics) | 100 | ✅ Done |
| Motorized Infantry (full stats + tactics) | 100 | ✅ Done |
| Artillery (full stats + tactics) | 100 | ✅ Done |
| Core mechanics (dice, grid, IGOUGO) | 100 | ✅ Done |
| Movement style (jump-based) | 100 | ✅ Done |
| Terrain types | 95 | ✅ Done |
| Combat tactics (full applicability) | 100 | ✅ Done |
| Counter-attack | 95 | ✅ Done |
| Minimum damage floor | 100 | ✅ Done |
| Trench rules (full escalation) | 100 | ✅ Done |
| Doctrine framework | 100 | ✅ Done |
| Blitzkrieg doctrine | 95 | ✅ Done |
| Superior Firepower doctrine | 95 | ✅ Done |
| Plain doctrine | 100 | ✅ Done |
| Economy (war points) | 100 | ✅ Done |
| HQ / win condition | 100 | ✅ Done (HQ damage mechanism resolved v1.4 — passive per-turn aura) |
| Formation rules | 100 | ✅ Done |
| Heavy-unit progression + stamina | 100 | ✅ Done |
| Facing system | 100 | ✅ Done |
| Starting placement | 95 | ✅ Done |
| Match flow | 100 | ✅ Done |
| UI / feedback | 15 | 🔴 Skeletal |

---

## Recommended next focus

**Spec-translation track + test-enumeration track are both COMPLETE.**
All four sibling specs are done; `COMBAT_TEST_CASES.md` v1.0 is done.
The engine is implementable end-to-end from the spec set alone, and
the combat module has a runnable regression suite ready (modulo the
flagged open questions, none of which is a hard blocker for early
implementation work).

**Three parallel tracks — pick the one that fits the session:**

**Track A — Open-question resolution (design / cross-module review)**
1. **Resolve the 6 combat-spec open questions**
   (`TECHNICAL_SPEC_combat.md §5`) plus the new **Q-07 clarification**
   from `COMBAT_TEST_CASES.md §5`. Q2 (forest/mountain +1 vs +1.5) is
   a real cross-module discrepancy between `combat.md §5.3` and
   `units_and_entities.md §2.5.3` and should be reconciled before
   either spec ships to engine. Each open-question scenario in the
   test cases file is **promote-ready** — once a question closes,
   the chosen branch's expected output becomes canonical and the
   scenario folds into §2/§3/§4.
2. **Resolve the 6 game-core-spec open questions**
   (`TECHNICAL_SPEC_game_core.md §6`). **Q3 (per-tick HQ damage
   amount) is HIGH PRIORITY** — engine balance depends on it; the
   spec uses a placeholder of 1 that produces clean math but is
   not yet a designer-confirmed value.
3. **Resolve the 3 economy-spec implementation choices**
   (`TECHNICAL_SPEC_economy.md` v1.3 changelog).
4. **Cross-spec drift reconciliation pass.** The game-core spec §7
   surfaces the documented mismatches (`GameState`/`MatchState`,
   `PlayerIndex`/`PlayerId`, `GridPos`/`TileCoord`,
   `motorised_inf`/`motorized_infantry`). Pick canonical names
   (the game-core picks already match the majority) and update
   sibling specs.

**Track B — Start Phase 1 design work**
- Pre-game menu wireframes (highest UX risk; surfaces 6 jobs on 1 screen).
- In-game HUD wireframes (8+ state items to surface per unit).

**Track C — Phase 2 quick wins (coding)**
- TypeScript + Vite + Vitest scaffold. **`COMBAT_TEST_CASES.md` v1.0
  is the canonical test-input source** — every `CT-NNN` and `P-NN`
  translates directly to a Vitest test or fast-check property; the
  RNG-seeding convention in §0 and the per-scenario expected
  `DamageResult` shapes are designed for direct transcription.
- Transcribe `BASE_UNIT_STATS` and `TERRAIN_MODIFIERS` tables as data files.
- Transcribe `DOCTRINE_PACKS` as data. **Note:** the economy spec's
  `ECONOMY_CONFIG` covers the pre-game cap/cost subset of this data
  (budgets, unit costs, XP costs, purchase caps, XP-upgrade caps).
  When unifying, prefer ONE source of truth — pulling from
  `TECHNICAL_SPEC_units_entities.md`'s `DOCTRINE_PACKS` and projecting
  the economy view, OR vice versa. Do not duplicate.
- Transcribe `GAME_CORE_CONFIG` constants (`HQ_MAX_HP=20`,
  `HQ_REACH=3`, `HQ_OCCUPATION_TURNS_TO_CAPTURE=5`, `TURN_LIMIT=1000`)
  as data.
- Build a render-board-from-JSON harness (visual feedback, no game logic).
- **Combat resolver is implementable** from `TECHNICAL_SPEC_combat.md` +
  `TECHNICAL_SPEC_game_core.md` (BoardState/MatchState now defined),
  with `COMBAT_TEST_CASES.md` providing the ready-made regression net.
- **Pre-game economy module is implementable** from
  `TECHNICAL_SPEC_economy.md` alone.
- **Match initialization + win-condition checker is implementable**
  from `TECHNICAL_SPEC_game_core.md` alone (modulo Q3 placeholder).

---

## Source-of-truth rules

- **Version numbers** live in this file's "At a glance" table. Bump
  the version when a meaningful decision or deliverable is produced.
- **Decision history** lives in `CHANGELOG.md` — never delete from it.
- **Live open questions** live in `open_questions.md`.
- **If a rule changes**, the rule file gets updated, the changelog
  gets a new entry, *and* this file's completion table gets re-scored.
- **If a spec is added or updated**, this file's spec-progress table
  gets updated accordingly.

---

## Known gotchas for future sessions

*(All v0.14–v0.18 gotchas still apply — see prior STATUS.md.)*

**v1.0 additions (from units/entities spec):**

- **`UnitState` does NOT own the trench.** The spec explicitly models
  trench as a tile property (`TrenchState` on `BoardState`). Any code
  that stores trench status on `UnitState` is a bug. This was flagged
  as Risk #5 in `IMPLEMENTATION_PLAN.md`. **Reaffirmed** by combat spec
  §1.3, invariant §4.4, and game-core spec §1.2 / invariant 5.8.
- **`getEffectiveStats()` does NOT include Blitzkrieg still-penalty.**
  The still-penalty (−1 def per still turn) is applied at combat
  resolution time, NOT folded into the unit's effective stats.
  Confusing these two will produce incorrect defense values.
- **Tank L1 bonus square costs 1 attack stamina THIS turn, plus
  no-move NEXT turn.** The two penalties are on different turns.
  The no-move is stored in `NextTurnPenalty.noMove`, cleared at the
  start of the next turn during `resetStaminaForPlayer()`.
- **Tank L2 bonus attack: no-attack penalty is NEXT turn only.**
  Movement is unaffected on either turn.
- **`legalActions()` always includes rotation and endTurn.** Rotation
  is legal even after a unit has spent both its actions. The AI must
  not assume a unit with actionsRemaining=0 has no legal actions.
- **`BoardState` schema is now defined** in
  `TECHNICAL_SPEC_game_core.md §1.3`. The units spec's references
  (`board.getTerrain()`, `board.getUnit()`, `board.getTrench()`,
  `board.formations`) map to `BoardReadOps` in the game-core spec.
  Note that the canonical implementation may expose these as free
  functions or as methods — the contract is the read/write split,
  not the surface form.

**v1.2 additions (from combat spec):**

- **`AttackContext` is the combat-side context object** (combat spec
  §1.5). The earlier `CombatContext` mentioned in the units spec
  (`grantsXp()`, `formationCombinedDefense()`) is a related but
  distinct shape — when implementing, verify whether they unify or
  whether `CombatContext` extends `AttackContext` with XP-relevant
  fields. Do not assume they are identical.
- **`turnsSinceLastMove` is one counter feeding two mechanics.**
  It drives both the trench timer (3-turn trigger, §2.5) *and* the
  Blitzkrieg cumulative still-penalty (§5.3). The mechanics are
  independent in effect but share the trigger — do not split into
  two counters.
- **Counter-attacks are non-recursive.** Combat spec §4.9 / invariant:
  a counter-attack is a single defender-side roll, not a full attack.
  It does **not** trigger a counter-counter-attack. Implementations
  must explicitly prevent recursion.
- **Bounce-rule preconditions are conjunctive (5 conditions).**
  Combat spec §4.10. All five must hold simultaneously. A Blitzkrieg
  Captain-rank tank, or a Blitzkrieg Corporal tank with 2 attack
  stamina, etc. — none qualify. The bounce rule is the *only* path
  to negative damage in `DamageResult`.
- **Diagonals never count for positional bonuses.** Combat spec §4.3.
  Encirclement, double-attack, rear, and side bonuses are all
  zero unless the attacker is orthogonally adjacent (or tank-reach
  orthogonal). The single exception is tank reach itself, which
  also counts orthogonally only. Diagonal-positioned attackers in
  encirclement geometry get **no** encirclement bonus (§4.8).
- **Artillery exemption is a hard set of disallowed bonus sources.**
  Combat spec §4.2 enumerates the forbidden modifier sources for
  artillery attackers (frontal/side/rear/double_attack/encirclement/
  mountain_attack_penalty/forest_attack_bonus). Doctrine effects and
  base strength are still in. Treat this as a filter on the bonus
  list, not a separate code path.
- **Permanent trench is irreversible (§4.5).** Once `tier === 'permanent'`,
  bonuses are locked at +1/+1 forever, regardless of who re-occupies.
  Unit death does not destroy a permanent trench.
- **Stamina state is preserved between turns.** Combat spec §3.4 step 1:
  stamina counters are NOT reset at end-of-turn; reset happens at
  the next `turn_start` for that player. Counter-attacks executed
  on the opponent's turn read the defender's current stamina, which
  carried over from their last turn — this is intentional for the
  bonus-die trigger.
- **6 spec-translation questions are deferred** in `TECHNICAL_SPEC_combat.md §5`.
  The most consequential is **Q2** — `combat.md §5.3` uses forest defense
  `+1`, while `units_and_entities.md §2.5.3` uses `+1.5`. The combat
  spec defaults to +1 pending reconciliation. Engine implementers
  must be aware that one of the two rule docs is currently authoritative
  for the combat module, and this could shift before code freeze.

**v1.3 additions (from economy spec):**

- **Economy is PRE-GAME ONLY.** `economy.md §E.5` is explicit: there is
  no in-game economy. No income, no upkeep, no mid-game purchases. The
  IGOUGO turn loop runs with zero economy callbacks. Any code path
  that tries to deduct/award war points during a match is a bug.
  `economy.md §E.5` confirmed in v0.18 (no mid-game reinforcements,
  leftover points forfeit).
- **`FinalizedRoster` is the one-way handoff to in-game.** After
  `finalizeSetup()` succeeds, the economy module's role ends for the
  match. `FinalizedRoster.units` feeds `UnitState` construction;
  `FinalizedRoster.formationPairs` feeds the formation system in units
  spec §5; `RosterEntry.startsEntrenched === true` pre-populates a
  `TrenchState` per combat spec §5.6 (bypassing the normal 3-turn
  trench timer). `pointsForfeit` is audit-only — no in-game function
  reads it. **Reaffirmed** by game-core spec §2.1
  (`initializeMatch()` consumer contract).
- **`refundUnitPurchase()` cascades.** Refunding a unit also auto-refunds
  any `XpPurchase` and `SpawnBonusPurchase` that targeted it (their
  target ceases to exist). `refundXpUpgrade()` and `refundSpawnBonus()`
  do NOT cascade. If the design intent is "no refunds, ever," all three
  refund contracts can be removed — this was an inferred-from-context
  decision (v0.16 "single shared pre-game menu" implies revisability),
  not an explicit `economy.md` rule.
- **`maxUpgradedUnits: null` ≠ `maxUpgradedUnits: 0`.** Plain doctrine
  has `null` (no per-category count limit; budget is the only constraint).
  Blitzkrieg cavalry/artillery and SF heavy have `0` (no upgrades allowed
  at all — the v0.16 "—" rows resolved). These two cases must be branched
  on separately; treating `null` as `Infinity` works arithmetically but
  obscures the rule.
- **Spawn-entrench eligibility is gated by combat invariant 4.7.** Heavy
  units (Tank, Motorised Infantry) cannot trench, full stop. Artillery
  is also excluded per the units spec §10.4 trench-advancement filter.
  Only Infantry and Cavalry can spawn entrenched. `canSpawnEntrenched()`
  enforces this.
- **`ECONOMY_CONFIG` and `DOCTRINE_PACKS` overlap.** The economy spec's
  cap/cost tables (`UNIT_PURCHASE_CAPS`, `XP_UPGRADE_CAPS`, `WAR_POINT_BUDGETS`)
  cover the same data as parts of `DOCTRINE_PACKS` in the units spec.
  When implementing, pick ONE as the source-of-truth — duplicate constants
  drift over time. **The game-core spec adds `GAME_CORE_CONFIG` as a
  third constants block** (HQ HP/reach/occupation, turn limit). Keep
  these scoped per-module — they don't overlap, but the multiplicity
  of config blocks is a maintenance fact to remember.
- **Naming inconsistency: `motorised_inf` (units spec) vs `motorized_infantry`
  (combat spec).** The economy spec uses `motorised_inf` because the units
  spec is the canonical authority for `UnitId` / `UnitType`. The combat
  spec needs a future edit to align — flagged in the v1.3 changelog.
  **Game-core spec defers to the units-spec naming** and surfaces this
  in §7 drift table.
- **`economy.md §E.4` contains stale "20-point" prose.** The phrase
  "Both bonuses are paid out of the same 20-point budget" predates the
  v0.16 per-doctrine budgets (30/35/25). The economy spec ignores the
  literal "20" and uses the per-doctrine pool. The source phrase should
  be cleaned up directly in `economy.md`.
- **A v1.2 CHANGELOG entry is missing.** STATUS.md previously listed
  v1.2 as the combat spec, but no v1.2 section exists in CHANGELOG.md
  (it jumps from v1.1 to v1.3). The combat spec itself exists and is
  referenced — this is bookkeeping, not content. **Still outstanding
  as of v1.4** — backfill if desired in a future session.

**v1.4 additions (from game-core spec):**

- **HQ damage is passive aura, end-of-turn only.** Resolved this
  session. The HQ takes damage at the end of the just-acted player's
  turn for every one of their units within `HQ_REACH` of the
  opponent's HQ. There is no active-attack codepath: HQs are NOT
  valid targets for `resolveAttack()`. All HQ damage flows through
  `applyHqDamageTick()` (game-core §2.3). Code that tries to feed
  an HQ as a `defenderId` in `AttackContext` is a bug.
- **Per-tick damage amount is FLAGGED.** `game_core.md §1.2` does
  not specify how much damage one enemy in reach deals per tick.
  The spec uses `HQ_DAMAGE_PER_ENEMY_PER_TURN = 1` as a placeholder
  (chosen for clean math: 4 enemies × 1 dmg × 5 turns = 20 = full
  damage path). This is **HIGH PRIORITY** to confirm before code
  freeze — it is a balance lever, not a tuning detail. See game-core
  spec §6 Q3.
- **Occupation timer is per-HQ, not per-unit.** The 5-turn capture
  timer ticks if **any** opposing unit is in reach at end-of-turn,
  and resets if **none** are. Unit identity does not matter; rotation
  of which units occupy is irrelevant. `HQState.enemyOccupationTurns`
  is a single integer per HQ. The per-unit interpretation
  (`Map<UnitId, number>`) was rejected as harder to serialize and
  more brittle. See game-core §6 Q1.
- **HQ ticks happen on the just-acted player's turn end, not both
  ends.** P0 ending their turn ticks P1's HQ; P1 ending their turn
  ticks P0's HQ. Each HQ ticks at most once per round (= one cycle
  of both players acting). This avoids double-counting and matches
  "when an enemy is in reach" most cleanly. See game-core §6 Q2.
- **`MatchState` is the canonical match container.** The units
  spec's `GameState` and combat spec's `MatchState` both refer to
  what game-core spec §1.6 defines. Use `MatchState`. The game-core
  spec §7 drift table is the master reference for which name wins.
- **`PlayerIndex = 0 | 1`** is canonical (units, economy, game-core
  agree). The combat spec's `PlayerId = 'P1' | 'P2'` is a drift
  to be aligned in a future combat-spec edit.
- **`GridPos = { row, col }`** is canonical (units, game-core
  agree). The combat spec's `TileCoord = { x, y }` with `tiles[y][x]`
  is the same concept under different field names: `row === y`,
  `col === x`. Implementers translating between specs must keep
  this mapping in mind.
- **`MatchState.rng` is read by combat ONLY, not by HQ ticks.**
  HQ damage and occupation ticks are deterministic — they consult
  no RNG. Replay tests rely on this property (game-core invariant
  5.10).
- **HQs are friendly-fire-immune.** A player's own units never
  contribute to their own HQ's tick; the just-acted player's
  damage tick fires only against the opponent's HQ. Game-core
  invariant 5.12.
- **`MapDefinition.playerHalves` is map-author-defined, no default
  geometry.** The "halve the board" prose in `game_core.md §1.4` is
  satisfied by a `Set<GridPos>` per player; the engine treats it as
  opaque. Maps that omit `playerHalves` are invalid input to
  `initializeMatch()` (`MapValidationError`). See game-core §6 Q5.
- **`MapDefinition.hqPositions` is map-author-defined.** The
  bottom-left/top-right convention (decision #37) is a default
  most maps will follow, but it is NOT a hard invariant — handcrafted
  maps may place HQs anywhere. Code that hardcodes the corner
  positions is incorrect; read from `board.hqPositions[player]`.
- **Spawn-entrenched seeding bypasses the trench timer.** When
  `RosterEntry.startsEntrenched === true`, the unit's tile receives
  `TrenchState = { tier: 'active', occupantId: ..., turnsHeld: 3 }`
  at `initializeMatch()` time. The unit is immediately in the
  3-turn-trigger state — it gets the trench bonus on turn 1, not
  turn 4. See combat spec §5.6 and game-core §2.1.
- **`turnNumber` increments at end of P1's turn, not P0's.** One
  turn-number step = one full round of both players. Game-core
  invariant 5.11. The `turnLimit = 1000` is in these "round" units;
  the actual per-player action count is up to 2000.

**v1.5 additions (from combat test-cases enumeration):**

- **`COMBAT_TEST_CASES.md` is the canonical regression net for the
  combat module.** Every `CT-NNN` is a self-contained scenario
  (setup + action + expected `DamageResult`/`CounterAttackResult`/
  `TrenchState`) with explicit RNG seeding; every `P-NN` is a
  property-test seed with sampling instructions. When implementing
  the combat resolver, transcribe these scenarios directly — do not
  invent new edge cases ad hoc, because the test file is what the
  spec § cross-reference index is keyed against.
- **Each open-question scenario (`Q-01..Q-07`) is promote-ready.**
  When design closes a question, pick the resolution branch in §5
  of the test cases doc, and that branch's expected output becomes
  the canonical scenario expected. Do NOT delete the alternative
  branches — they remain as the "rejected resolutions" record.
- **Q-07 is new (surfaced from CT-009).** Combat spec §4.2 only
  enumerates **attacker-side** disallowed bonus sources for artillery.
  Whether the **defender-side** rear/side penalty also vanishes when
  the attacker is artillery is unspecified. CT-009 takes the
  asymmetric reading (defender still takes the penalty); a symmetric
  reading is also defensible. Code reviewers should flag this when
  the resolver is implemented — both readings are coherent against
  the current spec wording.
- **Pinned regressions to watch (high-priority tags in Appendix B):**
  CT-033 (cavalry mountain attack penalty — pre-v0.15 had cavalry
  exempt), CT-039 (bounce floor at −3, not 1), CT-050 (3/2/3 arc,
  not 1/2/2/2/1), CT-051 (encirclement non-stacking when both
  detectors fire), CT-054 (permanent trench gives 0 to heavy units,
  not +1). These are the rules whose intuitive reading drifts back
  to the wrong value most easily.
- **Half-step precision is a tested invariant.** CT-052 pins the
  no-premature-rounding rule from spec §0. Any `Math.floor` or
  `Math.round` call inside the modifier-resolution path is a bug
  the test will catch.
- **Test cases reference combat-spec section numbers, not rule-doc
  section numbers.** When `combat.md` is edited, the spec must be
  updated first (it's the authority for the test cases); the test
  cases follow downstream. Do not patch the test cases against
  `combat.md` directly — the spec is the indirection layer.
