# Strategy Game — Changelog

> **Purpose.** Append-only log of decisions made across chat sessions.
> One entry per session. Each entry lists what was *resolved*, what was
> *added*, and what *new questions* surfaced.
>
> **How to use.** At the end of every session, append a new section at the
> top under the version heading. Never edit old entries — if a previous
> decision is overturned, log the reversal as a new entry.
>
> **Companion file.** See `STATUS.md` for the current snapshot (latest
> version, completion %, open questions). This file is the *history*;
> `STATUS.md` is the *now*.

---

## v1.5 — 2026-05-08

> Combat test-case enumeration session. Translated `TECHNICAL_SPEC_combat.md`
> v1.0 (function contracts §2, IGOUGO transitions §3, invariants §4,
> open questions §5) into a runnable scenario suite. **No new
> game-design decisions resolved this session** — the file is
> derivative, not generative. **One new clarification question (Q-07)**
> surfaced from CT-009 about whether the positional gate is asymmetric
> (attacker-side only, current spec) or symmetric (paired). With this
> file produced, the spec-translation track + test-enumeration track
> are both complete; only UI/UX wireframes remain outside engine
> implementation.

### Added

- **`COMBAT_TEST_CASES.md`** — scenario-style test suite covering the
  combat module end-to-end. Mirrors the spec's structure: §1 property
  invariants, §2 scenario tests against function contracts, §3 IGOUGO
  flow tests, §4 edge cases & regressions, §5 open-question scenarios.
  Total: **10 property tests** (`P-01..P-10`), **56 scenario tests**
  (`CT-001..CT-056`), **7 open-question scenarios** (`Q-01..Q-07`).
  Each scenario specifies setup, action, expected `DamageResult` /
  `CounterAttackResult` / `TrenchState`, and the spec sections it
  verifies. Includes:
  - **Property invariants** (§1) keyed to combat spec §4 — damage
    floor, artillery exemption, diagonals-never-count,
    trench-is-tile-state, permanent-irreversible, swamp-blocks-trench,
    heavy-never-trench, encirclement-orthogonality,
    counter-non-recursive, bounce-conjunctive (P-10 specifies sampling
    all 2⁵ = 32 boolean configs of the bounce preconditions).
  - **Geometry & attack-direction scenarios** (CT-001..CT-008) —
    frontal/side/rear coverage, tank reach-as-adjacency, ortho/diag
    boundary cases (tank ortho 4 legal vs 5 illegal; non-tank
    Chebyshev symmetry).
  - **Tactic-applicability gating scenarios** (CT-009, CT-010) —
    artillery attacker rear (no rear bonus), artillery defender on
    forest (terrain bonus still applies). CT-009 is the genesis of
    the new Q-07.
  - **Encirclement detection scenarios** (CT-011..CT-015) — standard
    4-ortho, 3-of-4 negative, tank reach-hug ≥ 2, single-tank
    negative, diagonal-only tanks negative.
  - **Trench state-machine scenarios** (CT-016..CT-026) — every
    transition in combat spec §2.5 has at least one pinned scenario,
    plus regression coverage for swamp-while-timer-runs and
    standing-trench re-occupation timer reset.
  - **Range-falloff scenarios** (CT-027..CT-030) — both band
    boundaries (8/9, 12/13) and the Superior-Firepower-only gate.
  - **Modifier-resolution scenarios** (CT-031..CT-036) — double-attack
    via tank reach (CT-032), mountain-attack-penalty for cavalry
    (CT-033 — pinned regression for the v0.15 exemption removal),
    Blitzkrieg still-penalty cumulative per idle turn with tank-only
    and zero-idle-turns variants (CT-035a/b/c).
  - **Main-resolver scenarios** (CT-037..CT-040) — a full-formula
    worked example with encirclement + double-attack + forest defense
    yielding `damage = 5 + 4 + 4 − 3 − (−1) = 11`; damage-floor pin
    at 1 (CT-038); bounce-rule pin at −3 (CT-039); a 5-variant suite
    (CT-040 + variants) verifying P-10's conjunctive preconditions
    by flipping each of the 5 conditions independently.
  - **Counter-attack scenarios** (CT-041..CT-044) — no-stamina-no-counter
    (CT-041), no-bonus-die when attacker still has stamina (CT-042),
    full bonus-die scaling 1→+0.5 / 6→+3.0 with half-step precision
    preserved (CT-043 + 043b), and a pinned no-positional-bonus-on-counter
    scenario keyed to spec Q3 (CT-044).
  - **IGOUGO flow scenarios** (CT-045..CT-049) — `turn_start` stamina
    refresh + `turnsSinceLastMove` ticks, `hasMovedThisTurn` reset,
    counter-attack stamina decrement, attacker-dies-mid-counter
    no-recursion, single-counter-two-effects mechanism for
    `turnsSinceLastMove`.
  - **Edge cases & regressions** (CT-050..CT-056) — 3/2/3 arc
    confirmation across all 8 surrounding tiles (CT-050, pinned
    against the rejected 1/2/2/2/1 split), encirclement non-stacking
    when both detectors fire (CT-051), half-step precision
    preservation through the resolver (CT-052), trench-leave direction
    irrelevance (CT-053), permanent-trench-with-heavy giving 0 not
    +1 (CT-054 — pinned because the `+1/+1 permanent` framing invites
    the wrong intuition), missing-ortho-with-extra-diagonal not
    encircling (CT-055), attacker-dies-from-counter no-rollback (CT-056).
  - **Open-question scenarios** (§5, Q-01..Q-07) — each combat-spec
    §5 question (Q1–Q6) is rendered as a scenario with setup +
    per-resolution-branch expected outputs, plus the new Q-07. The
    scenarios are promote-ready: when design closes a question, the
    chosen branch's expected becomes canonical and the scenario moves
    into §2/§3/§4.
  - **Spec-section coverage matrix** (Appendix A) mapping every
    numbered combat-spec section to the tests that verify it.
  - **Test-runner notes** (Appendix B) — RNG determinism, scenario
    state isolation, cross-module stub strategy for [external]
    dependencies, and 5 high-priority regression tags (CT-033, CT-039,
    CT-050, CT-051, CT-054).

### New questions surfaced

- **Q7 — Defender-side positional penalties under artillery attacker.**
  *(New, surfaced by CT-009.)* Combat spec §4.2 only constrains the
  **attacker** side of the positional gate
  (`appliesPositionalTactics(attacker)`). CT-009 takes the position
  that a defender hit from the rear by artillery still receives a
  `'rear_received': −1` penalty, because spec §2.7 lists
  rear-received among defender modifiers without an artillery
  exception, and §4.2 only enumerates attacker-side disallowed
  sources. But it's plausible the rear/side direction itself should
  not produce a defender-side penalty when the attacker is artillery
  — i.e. paired-gating / symmetric treatment ("artillery is
  structureless relative to facing"). This is a clarification
  question, not a substantive rule change; the spec wording is
  consistent with both resolutions. Resolution affects CT-009 and
  any future symmetry-related tests. Flag for designer
  confirmation. Cross-reference: `COMBAT_TEST_CASES.md` §5 Q-07,
  `TECHNICAL_SPEC_combat.md` §4.2.

---

## v1.4 — 2026-05-07

> Game-core spec session. Translated `game_core.md` into computable
> contracts. **One new game-design decision was resolved this session**
> (HQ damage mechanism = passive per-turn aura) — `game_core.md §1.2`
> was silent on *how* an HQ takes damage when an enemy is in reach,
> and the spec needed a concrete model. With this spec produced, all
> four sibling specs (units, combat, economy, game-core) exist and the
> spec-translation track is closed. Six implementation questions were
> flagged for future review (see "New questions surfaced"); Q3 (per-tick
> damage amount) is HIGH PRIORITY.

### Added

- **`TECHNICAL_SPEC_game_core.md`** — computable TypeScript-style
  translation of `game_core.md`. Covers:
  - **Conventions** (§0): coordinate origin, `PlayerIndex = 0 | 1`,
    `GridPos = { row, col }`, HQ-placement convention. Documents
    cross-spec drift with combat (`PlayerId`, `TileCoord`).
  - **Primitives** (§1.1): `PlayerIndex`, `UnitId`, `TurnNumber`,
    `GridPos`, `PerPlayer<T>`, `opponentOf()`.
  - **`Tile`** (§1.2) — re-exports the `TrenchState` from combat
    spec §1.3 unchanged; reaffirms trench is tile-state.
  - **`BoardState`** (§1.3) — the canonical shape referenced (but
    never previously defined) by units, combat, and economy specs.
    Owns `tiles[row][col]` and `hqPositions`. Read/write helper
    interfaces (`BoardReadOps`, `BoardWriteOps`) split for
    immutability discipline.
  - **`HQState`** (§1.4) — per-HQ live state: `currentHp`,
    `enemyOccupationTurns` (per-HQ counter, NOT per-unit),
    `captured`, `captureCause`.
  - **`GameOutcome`** (§1.5) — discriminated union:
    `in_progress | win | draw`. `WinReason` covers all three paths
    (`hq_damage`, `hq_occupation`, `turn_limit_hq_hp`).
  - **`MatchState`** (§1.6) — the canonical match container.
    Authoritative over the units spec's `GameState` and combat
    spec's `MatchState`. Holds board, units, doctrines, hqStates,
    turnNumber, turnLimit, activePlayer, turnPhase, matchPhase,
    outcome, rng.
  - **`MapDefinition`** (§1.7) — designer-authored map content:
    width, height, terrain[][], hqPositions, playerHalves
    (per-player set of legal placement tiles).
  - **`PlacementSpec`** (§1.8) — per-player placement of finalized
    roster onto board; per-unit position + optional facing override.
  - **`initializeMatch()`** (§2.1) — constructs MatchState from
    two `FinalizedRoster`s + two `PlacementSpec`s + `MapDefinition`
    + RNG seed. Materialises spawn-entrenched trenches (sets
    `TrenchState = { tier: 'active', turnsHeld: 3 }` to bypass the
    3-turn timer). Materialises formation pairs. Three typed errors:
    `PlacementValidationError`, `MapValidationError`,
    `RosterMismatchError`.
  - **`getHqReachTiles()` / `enemiesInHqReach()`** (§2.2) — Chebyshev
    HQ reach (king-move, includes diagonals; HQ tile included).
  - **`applyHqDamageTick()`** (§2.3) — passive aura at end of just-
    acted player's turn. Each enemy unit in opponent's HQ reach
    contributes `HQ_DAMAGE_PER_ENEMY_PER_TURN` damage (each unit
    counts at most once). Player's own HQ is unaffected (no
    friendly fire on HQs). HP clamped at 0.
  - **`applyHqOccupationTick()`** (§2.4) — per-HQ counter:
    `enemyOccupationTurns++` if ≥ 1 enemy in reach, else reset to 0.
  - **`checkWinCondition()`** (§2.5) — pure function evaluating all
    four paths in precedence order: damage → occupation → turn-limit
    tiebreak → in-progress.
  - **`resolveTimeoutOutcome()`** (§2.6) — 1000-turn tiebreak per
    decision #70: highest remaining HQ HP wins; equal = draw.
  - **`processMatchEndOfTurn()`** (§2.7) — match-level hook called
    by units-spec `applyEndTurn()` AFTER its bookkeeping. Atomic
    sequence: HQ damage tick → HQ occupation tick → win check →
    phase transition (turn handoff or match end).
  - **`validatePlacement()` + `validateCrossPlayerPlacement()`**
    (§2.8) — 7 placement-validity checks: roster coverage, half
    containment, no overlap, HQ exclusion, terrain legality,
    facing legality, entrenchment-tile match (swamp blocks
    trenching per combat invariant 4.6).
  - **Match-level state machine** (§3) — `MatchPhase` enum
    (`Setup | InProgress | Ended`); transition table; integration
    diagram with units-spec turn loop. `Setup` is never observable
    on a live MatchState (pre-match handled by economy spec).
  - **`GAME_CORE_CONFIG`** (§4) — single authoritative constants
    block: `HQ_MAX_HP = 20`, `HQ_REACH = 3`,
    `HQ_OCCUPATION_TURNS_TO_CAPTURE = 5`,
    `HQ_DAMAGE_PER_ENEMY_PER_TURN = 1` (FLAGGED placeholder),
    `TURN_LIMIT = 1000`, `HQ_DAMAGE_FLOOR = 0`.
  - **12 invariants** (§5): HP bounds, HP monotonicity,
    captured-implies-threshold, captured-is-sticky, outcome
    consistency, MatchPhase/outcome alignment, activePlayer
    alternation, trench-is-tile-state (re-stated from combat
    invariant 4.4), HQ-position immutability, RNG isolation
    (HQ ticks are deterministic, do not consult RNG),
    turn-number monotonicity, self-damage exclusion.
  - **Cross-reference index + cross-spec drift table** (§7) — every
    `game_core.md` rule mapped to its computable location, plus a
    drift subtable surfacing the documented mismatches across all
    four specs (`MatchState`/`GameState`,
    `PlayerIndex`/`PlayerId`, `GridPos`/`TileCoord`,
    `motorised_inf`/`motorized_infantry`).

### Resolved

- **HQ damage mechanism → passive per-turn aura.** `game_core.md §1.2`
  prose says only *"When an enemy unit is within the HQ's 3-square
  reach, the HQ takes damage"* — the *mechanism* (active attack vs.
  passive aura) was unspecified. Resolved this session: HQs are
  damaged passively at the end of each player's turn for every one
  of their units within 3 squares of the opponent's HQ. HQs are NOT
  valid targets for `resolveAttack()`. Cross-reference: game-core
  spec §2.3, §6 Q4.

### New questions surfaced

These six items were flagged in `TECHNICAL_SPEC_game_core.md §6`
for design review before code freeze. Each has a working spec
choice noted; engine balance and behaviour depend on confirmation.

- **Q1 — Per-HQ vs per-unit occupation timer.** `game_core.md §1.2`
  prose ("a unit stays inside the HQ's reach for 5 turns") reads as
  per-unit, but per-HQ ("≥ 1 enemy in reach at end-of-turn") is the
  cleaner digital model. Spec uses per-HQ; flag for designer
  confirmation.
- **Q2 — Tick frequency.** Does the HQ tick at end of every player
  turn (so both HQs tick once per round), or only at end of the
  attacker's turn? Spec uses "end of just-acted player's turn,
  against opponent's HQ" (one tick per HQ per round). Flag for
  designer confirmation.
- **Q3 — Per-tick damage amount.** ⚠ **HIGH PRIORITY.**
  `game_core.md §1.2` is silent on the damage rate. Spec uses
  `HQ_DAMAGE_PER_ENEMY_PER_TURN = 1` as a placeholder, chosen
  because it makes the two win paths converge mathematically
  (4 enemies × 1 dmg × 5 turns = 20 = full damage path). Engine
  balance depends on this; MUST be confirmed before code freeze.
  Open question: is the rate flat-1, unit-typed (e.g. infantry 1,
  tank 2, artillery 3), or a flat aggregate (1 dmg/tick if any
  enemy is present, ignoring count)?
- **Q4 — HQ as targetable unit.** Locked to passive aura per this
  session, but a future ruleset revision might layer active attacks
  on top of the passive aura. Spec currently rejects HQ as a
  `defenderId` in `AttackContext`. Flag for designer confirmation
  that "passive aura only" is the final design.
- **Q5 — `MapDefinition.playerHalves` shape.** The "halve the
  board" prose in `game_core.md §1.4` is satisfied by an opaque
  per-player set of tile coords; map authors define the geometry.
  Spec treats `playerHalves` as mandatory on `MapDefinition` —
  no default geometry. Flag for designer confirmation.
- **Q6 — Wall-clock timer.** `game_core.md §1.8` notes that
  implementations *may* layer a real-time match timer above the
  1000-turn cap. Spec leaves this entirely to the runtime — no
  schema field. Flag for designer confirmation that this is
  acceptable for v1.

Additionally:

- **Cross-spec drift reconciliation pass needed.** The game-core
  spec §7 surfaces four documented mismatches across the four spec
  files (`GameState`/`MatchState`, `PlayerIndex`/`PlayerId`,
  `GridPos`/`TileCoord`, `motorised_inf`/`motorized_infantry`). The
  game-core spec picks the canonical names (which already match
  the majority of sibling specs); a future pass should align the
  combat spec to match. Bookkeeping, not content.
- **The v1.2 CHANGELOG gap is still outstanding.** STATUS.md
  v1.3 noted that the combat spec (referenced as "v1.2") has no
  corresponding CHANGELOG section between v1.1 and v1.3. Still
  unfilled as of v1.4 — backfill if desired in a future session.

---

## v1.3 — 2026-05-05

> Pre-game economy spec session. Translated `economy.md` into computable
> contracts. No game-design decisions were made — the file is a translation
> of v0.16/v0.18 decisions already logged in this changelog. Three
> implementation choices were flagged for future review (see "New questions
> surfaced").

### Added

- **`TECHNICAL_SPEC_economy.md`** — computable TypeScript-style translation
  of `economy.md`. Covers:
  - **Primitive enums:** `PurchaseCategory` (heavy / lightInfantry /
    lightCavalry / special), `SpawnBonusType`, `PreGameSetupPhase`,
    `Result<T, E>` discriminated union for fallible operations.
  - **Purchase records:** `UnitPurchase`, `XpPurchase`, `SpawnBonusPurchase`
    — each with stable `purchaseId` for refund/cascade tracking.
  - **Caps schemas:** `UnitPurchaseCap`, `DoctrineXpCap` (with
    `maxUpgradedUnits: number | null` to encode Plain's "no per-class count
    limit" rule from v0.16), `DoctrineEconomyProfile` aggregator.
  - **Setup state:** `PreGameSetupState` (mutable via §2 functions only) and
    `FinalizedRoster` / `RosterEntry` (frozen handoff to in-game system).
  - **11 typed error classes** — `EconomyError` base + `DoctrineNotSelectedError`,
    `SetupAlreadyFinalizedError`, `BudgetExceededError`, `UnitCapExceededError`,
    `XpCapExceededError`, `InvalidXpTargetError`, `UnknownUnitError`,
    `IneligibleSpawnBonusError`, `PurchaseNotFoundError`,
    `InvalidPhaseTransitionError`, `SetupValidationFailedError`.
  - **Pure helpers:** `categoryOf()`, `costForLevel()`, `cumulativeXpCost()`,
    `totalSpent()`, `remainingBudget()`, `effectiveRank()`,
    `countUpgradedUnitsInCategory()`, `canSpawnEntrenched()`,
    `canFormFormation()`.
  - **Construction:** `createPreGameSetup()`, `selectDoctrine()`,
    `resetSetup()`.
  - **Purchase contracts:** `purchaseUnit()`, `refundUnitPurchase()`
    (with cascade — refunding a unit also refunds its XP and spawn-bonus
    purchases), `purchaseXpUpgrade()`, `refundXpUpgrade()`,
    `purchaseSpawnEntrenched()`, `purchaseSpawnFormation()`,
    `refundSpawnBonus()`. All return `Result<T, E>` for typed-error
    discrimination.
  - **`validateSetup()`** — runs 7 invariants over the setup, returns
    every violation; empty array means finalize-ready.
  - **`finalizeSetup()`** — irreversible commit, materialises XP and
    spawn-bonus purchases into the `FinalizedRoster`, forfeits leftover
    points (per `economy.md §E.5`).
  - **Pre-game setup state machine** — `Idle → DoctrineSelected →
    Composing → Finalized` with full transition table, entry invariants,
    onEntry/onExit effects, forbidden-action cheat sheet, and
    `transitionPhase()` dispatcher.
  - **`ECONOMY_CONFIG` + `DOCTRINE_PROFILES`** — single authoritative
    constants block: `WAR_POINT_BUDGETS` (30/35/25), `UNIT_COSTS` (3/3/5/5/5),
    `XP_COSTS` (2/4/5), `SPAWN_BONUS_COSTS` (3/5), full
    `UNIT_PURCHASE_CAPS` and `XP_UPGRADE_CAPS` tables for all three
    doctrines, with v0.16 "—" rows resolved as 0×.
  - **Cross-reference index** — maps every rule in `economy.md` to its
    computable location in this spec, plus cross-spec references for
    spawn-entrench eligibility (combat invariant 4.7) and formation
    eligibility (units spec §4).

### Resolved

- No new game-design decisions were made this session. The ruleset
  remains at v0.18 (functionally closed). This session is purely a
  translation of existing rules into implementation contracts.

### New questions surfaced

- **Refund / revision policy.** `economy.md` doesn't explicitly state
  whether the pre-game menu allows reversing purchases before finalize.
  The v0.16 "single shared pre-game menu" implies free revision, so
  the spec includes `refundUnitPurchase()` (with cascade for dependent
  XP/spawn-bonus purchases), `refundXpUpgrade()`, and `refundSpawnBonus()`.
  If the design intent is "purchases are committed on click, no refunds
  pre-finalize," these contracts can be removed.
- **Naming-convention reconciliation.** `TECHNICAL_SPEC_units_entities.md`
  uses `motorised_inf`; `TECHNICAL_SPEC_combat.md` uses `motorized_infantry`.
  The economy spec follows the units-spec spelling because that spec is
  the canonical authority for unit identity and where `UnitId` originates.
  A future combat-spec edit should align with this spelling.
- **Stale `economy.md §E.4` "20-point budget" phrase.** §E.4 still reads
  "Both bonuses are paid out of the same 20-point budget", which contradicts
  the v0.16 per-doctrine budgets (30/35/25). The economy spec treats
  the "20" as stale prose and uses the per-doctrine budget as the shared
  pool. The source phrase should be cleaned up in `economy.md` directly;
  flagged at the top of `ECONOMY_CONFIG` in the spec.
- **Missing CHANGELOG entry for `TECHNICAL_SPEC_combat.md`.** `STATUS.md`
  v1.2 references the combat spec as produced, but there is no v1.2
  entry in this CHANGELOG between v1.1 and v1.3. This appears to be a
  prior-session bookkeeping gap, not a content gap — `TECHNICAL_SPEC_combat.md`
  itself exists and is referenced by both v1.3 and the v1.2 STATUS row.
  Surface for next session to backfill if desired.

---

## v1.1 — 2026-05-03

> `combat.md` surfaced as a complete, finalized rule file.
> This session reads it and updates the project index files to reflect
> it. No game-design decisions were made — the file is a translation
> of v0.16–v0.18 decisions already logged in this changelog.

### Added

- **`combat.md`** — confirmed present and complete. Covers:
  - **§5.1 Combat sequence** — 7-step flow: reach check → direction →
    attacker bonuses → 1d6 roll → defender bonuses → damage formula →
    floor of 1.
  - **§5.2 Attacker modifiers** — full table: side +0.5, rear +1,
    double attack +1, encirclement +3, mountain attack −1, forest +1,
    range falloff, doctrine effects. Artillery exemption and tank
    reach-as-adjacency notes embedded.
  - **§5.3 Defender modifiers** — side −0.5, rear −1, encirclement −2,
    trench (Inf +2 / Cav +1.5), terrain, Blitzkrieg still-penalty
    (−1 per still turn, cumulative).
  - **§5.4 Net-swing table** — frontal +0, side +1, rear +2,
    encirclement +5, diagonal encirclement +0.
  - **§5.5 Encirclement** — standard 4-orthogonal-neighbor trigger;
    2-tank reach-hug exception spelled out.
  - **§5.6 Trench digging** — 3-turn trigger, full escalation
    (3-turn exit → disappears; 4-turn exit → persistent re-occupiable;
    6-turn hold → permanent +1), swamp block, no-trench for heavy
    units, pre-game spawn-entrenched option (3 war points).
  - **§5.7 Range falloff** — SF artillery: full strength 1–8,
    −0.5 str per square beyond 8, max range 12.
  - **§5.8 Worked examples** — three annotated combat scenarios.
  - **§5.9 Combat-rule resolutions** — counter-attack (defender rolls
    D6 if stamina remains; bonus D6 × 0.5 str/pip if attacker
    exhausted), Blitzkrieg bounce rule (BZ Corporal tank ≤1 stamina,
    no move → up to −3 attack), diagonal-is-not-a-tactic confirmation.
  - **§5.10 Heavy-unit tactics applicability** — per-unit matrix
    (Tanks / Motorized Infantry / Artillery × all tactics), with
    per-unit prose notes for reach-as-adjacency, Motorized as
    light-equivalent, and Artillery flat-attack rule.
  - **§7 Tactics quick reference** — consolidated one-page table for
    all bonuses, terrain, encirclement variants, formation, range
    falloff, and damage floor.

### Resolved

- No new game-design decisions. `combat.md` documents decisions
  already resolved in v0.16 and v0.18; this entry is purely an
  index update.

### New questions surfaced

- **`TECHNICAL_SPEC_combat.md` is now unblocked.** All rules needed
  to write `resolveAttack()`, the positional modifier pipeline, the
  encirclement checker, counter-attack, bounce, artillery flat-attack,
  and SF range falloff are present in `combat.md`.
- **`CombatContext` fields are now partially inferable.** `grantsXp()`
  needs `defeatedHadDoctrineModifierActive`; the combat resolver will
  also need `attackerExhausted` (for the bonus counter-attack D6) and
  `blitzkriegStillTurns` (for the still-penalty). These should be
  locked in when `TECHNICAL_SPEC_combat.md` is written.

---

## v1.0 — 2026-05-03

> First implementation-spec session. Translating the closed v0.18
> ruleset into computable contracts. This session produced
> `TECHNICAL_SPEC_units_entities.md`, covering the full units &
> entities domain (§2–§8 of `units_and_entities.md`) plus the
> IGOUGO turn state machine.

### Added

- **`TECHNICAL_SPEC_units_entities.md`** — computable TypeScript-style
  translation of `units_and_entities.md`. Covers:
  - **Primitive enums:** `UnitType`, `Facing`, `Direction`, `TerrainType`,
    `Rank`, `DoctrineType`.
  - **`UnitBaseStats` schema + `BASE_UNIT_STATS` data table** — all five
    unit types with correct HP, strength, defense, moveOrtho/Diag,
    reachOrtho/Diag, and unit class. Tank asymmetric reach (4 ortho /
    3 diag) modeled explicitly as split fields.
  - **`TerrainUnitModifier` schema + `TERRAIN_MODIFIERS` table** — all
    four terrain types × five unit types, including Artillery's swamp
    movement-override (replaces base movement entirely), forest/mountain
    entry restrictions, and per-unit defense bonuses.
  - **`isMoveLegal()` contract** — jump-based movement, terrain penalty
    application (including override path), occupancy check with
    formation-partner exception.
  - **`getMovementFootprint()` and `getAttackReachFootprint()`** —
    enumerate reachable/attackable tiles from a position, split by
    ortho/diag reach.
  - **`FACING_ZONE_MAP`** — 3/2/3 Front/Side/Rear mapping for all four
    facings. `getAttackZone()` and `rotateTo()` function contracts.
    `defaultSpawnFacing()` encodes the v0.18 "face the opponent" default.
  - **Formation schema + functions** — `canForm()`, `formationCombinedDefense()`,
    `isFormation()`. Heavy-unit exclusion enforced at type level.
  - **`TrenchState` schema (tile-level, not unit-level)** — three-tier
    escalation: nascent → active → persistent → permanent. `advanceTrench()`,
    `unitLeftTrench()`, `unitEnteredTrench()`, `getTrenchDefenseBonus()`
    function contracts. Architectural note: trench is a tile property,
    NOT a unit property.
  - **Progression tables** — `ProgressionEntry` schema and data for
    Infantry, Cavalry, Tank/Motorised (shared), and Artillery. Drawback
    flag distinguishes permanent stat deltas from per-turn optional
    bonuses. `grantsXp()` encodes the "stronger enemy" trigger.
    `applyRankUp()` and `getBaseStrengthWithXp()` contracts.
  - **`DOCTRINE_PACKS` data table** — all three doctrines with
    warPointBudget, startingArmy, additionalUnitCaps, xpUpgradeCaps,
    maxPreGameRank, unitStatOverrides, and signature-rule flags.
  - **`getEffectiveStats()`** — three-layer resolution: base → doctrine
    override (REPLACE) → XP permanent deltas (ADD). Blitzkrieg
    still-penalty and Tank/Motorised optional bonus drawbacks are
    explicitly NOT folded in here; they resolve in combat and stamina
    modules respectively.
  - **`UnitState` runtime schema** — id, owner, type, rank, pos, facing,
    currentHp, stamina, blitzkriegStillTurns, nextTurnPenalty.
  - **`UnitStaminaState`** — actionsRemaining (2/turn), bonusSquareAvailable/
    Used, bonusAttackAvailable/Used, waitedForDefenseBonus. Models the
    two-action budget and all Tank/Motorised optional bonus slots.
  - **`NextTurnPenalty`** — carry-over noMove / noAttack flags set by
    Tank/Motorised L1/L2 bonus actions; cleared at start of next turn.
  - **IGOUGO turn state machine** — `TurnPhase` enum, `PlayerAction`
    union type, `applyAction()` dispatcher, `applyMove()`,
    `applyAttack()`, `applyBonusSquare()`, `applyBonusAttack()`,
    `applyWaitForDefense()`, `applyEndTurn()`, `resetStaminaForPlayer()`,
    `updateBlitzkriegStillPenalties()`, `advanceTrenchTimers()`.
  - **`legalActions()`** — enumerates all legal actions for a player
    in a given state. This is the AI's entry point to the action space.
  - **Cross-reference index** — maps every rule in `units_and_entities.md`
    to its computable location in this spec.

### Resolved

- No new game-design decisions were made this session. The ruleset
  remains at v0.18 (functionally closed). This session is purely a
  translation of existing rules into implementation contracts.

### New questions surfaced

- **`TECHNICAL_SPEC_combat.md` needed.** The units spec defers
  `resolveAttack()`, positional bonus calculation, counter-attack bonus
  die, artillery tactics exemption, tank reach-as-adjacency in combat,
  range falloff, and the Blitzkrieg bounce rule to a combat spec that
  does not yet exist.
- **`TECHNICAL_SPEC_economy.md` needed.** Pre-game budget validation —
  spending constraints, cap enforcement, formation/entrenchment bonus
  purchasing — is not yet specified.
- **`TECHNICAL_SPEC_game_core.md` needed.** HQ damage tracking,
  5-turn occupation timer, 20-damage threshold, 1000-turn limit, and
  HQ-HP tiebreak are not yet in spec form.
- **`BoardState` shape undefined.** The units spec references `BoardState`
  (via `board.getTerrain()`, `board.getUnit()`, `board.getTrench()`,
  `board.formations`) but does not define its schema. Should be the
  first thing resolved in the game-core spec.
- **`CombatContext` shape undefined.** `grantsXp()` and
  `formationCombinedDefense()` reference `CombatContext`; its fields
  need defining in the combat spec.

---

## v0.18 — 2026-05-02

> Closing pass on the remaining non-UI open questions. Three batched
> question sets resolved at once: heavy-unit tactics applicability,
> facing/rotation/placement, and match-flow/board. The ruleset is now
> functionally complete outside of UI/UX work.

### Resolved

**Combat & tactics**

- **Heavy-unit tactics applicability.**
  - **Motorized Infantry** uses the same tactics rules as the light
    units (Infantry, Cavalry) — all positional, terrain, formation,
    and trench tactics apply normally.
  - **Tanks** participate in tactics with a reach-based rule (next
    bullet).
  - **Artillery** has **no positional tactics** — encirclement,
    rear/side attack, double attack, formation, trench, and terrain
    attack-bonus modifiers all do not apply to artillery attacks.
  Cross-reference: combat.md → §5.10.
- **Tank reach counts as adjacency for positional tactics.** A tank's
  4-ortho / 3-diag attack reach is treated as positional adjacency for
  double attack, encirclement, and rear/side attack direction.
  **Encirclement-via-reach for tanks needs only 2 or more tanks
  "hugging" the target** (rather than the standard 4 orthogonal
  neighbors). Rear/side attack bonuses likewise resolve from the
  tank's relative direction to the defender, even when firing from
  range. Cross-reference: combat.md → §5.10.
- **Minimum damage floor → 1, with one exception.** All combat rolls
  resolve to a minimum of 1 damage. **Exception:** the Blitzkrieg
  Corporal-tank bounce rule (combat.md → §5.9) can still produce a
  negative attack via the over-exhaustion penalty (up to −3).
  Cross-reference: combat.md → §5.9.
- **Stamina bookkeeping for Tank/Motorized progression.**
  - Level-1 "use bonus +1 ortho square": **−1 attack stamina applies
    this turn**; the no-move penalty applies **next turn**.
  - Level-2 "use bonus attack": the no-attack penalty applies **next
    turn**; movement is unaffected on either turn.
  Cross-reference: units_and_entities.md → §3.2a.
- **Plain doctrine confirmed vanilla.** No signature rule beyond the
  slow 2-ortho / 0-diag tank profile. The "Plain has no signature
  rule" decision is intentional, not "TBD". Cross-reference:
  units_and_entities.md → §8.5.

**Facing, rotation, formations, placement**

- **Default facing → both sides face each other.** Replaces the v0.14
  "all units spawn facing North" default. Each side's units spawn
  facing the opposing player's half of the board.
  Cross-reference: game_core.md → §1.5, units_and_entities.md → §6.1.
- **Rotation timing → free, anytime in your turn (including pre-game).**
  Rotation does not consume an action and may happen any number of
  times during a unit's turn (rotate → move → rotate again is legal).
  Cross-reference: units_and_entities.md → §6.3.
- **Formation rotation → individual.** Stacked units in a formation
  rotate **independently** — each unit keeps its own facing. This
  matters because formations cannot move, so individual facing
  becomes the only directional decision available to the formation.
  Cross-reference: units_and_entities.md → §4.4, §6.3.
- **Front/Side/Rear mapping → keep 3/2/3.** Front N/NW/NE, Side E/W,
  Rear S/SW/SE confirmed; no finer 1/2/2/2/1 split.
  Cross-reference: units_and_entities.md → §6.2.
- **Starting placement → half-and-half free placement.** The board is
  divided into two equal halves at pre-game; within their half each
  player freely places their starting army. **Every doctrine starting
  army (Plain, Blitzkrieg, Superior Firepower) may be repositioned
  pre-game** — there are no fixed deployment slots beyond the half-line
  constraint. Cross-reference: units_and_entities.md → §8.1,
  game_core.md → §1.4.

**Match flow & board**

- **Board → handcrafted maps.** Both board layout (size, shape, HQ-
  corner placement details) and terrain population are designer-
  authored per map. No procedural generation.
  Cross-reference: game_core.md → §1.4.
- **Turn limit → 1000 turns (or external timer).** If the limit is
  reached without an HQ falling, **the winner is the side whose HQ has
  more remaining HP**. Equal HQ HP at the limit results in a draw.
  Cross-reference: game_core.md → §1.2, §1.8.
- **No mid-game reinforcements.** Strictly "what you start with."
  Cross-reference: economy.md → §E.5.
- **Leftover war points → forfeit, no mid-game spending.** Confirmed:
  unspent points remain unspent and never re-enter play. Cross-
  reference: economy.md → §E.5.

### Added

- **combat.md → §5.10 "Heavy-unit tactics applicability"** — new
  sub-section consolidating the per-tactic-per-unit rules for Tanks,
  Motorized Infantry, and Artillery, including the tank-reach-as-
  adjacency rule and the relaxed 2-tank encirclement.
- **game_core.md → §1.8 "Turn limit and time-out resolution"** — the
  1000-turn cap with HQ-HP tiebreak.
- **units_and_entities.md → §4.4** — formation rotation note (each
  stacked unit rotates independently).
- **units_and_entities.md → §8.1.1** — starting placement: board
  halved, free placement within your half, all doctrine armies
  repositionable pre-game.

### Changed

- **Default facing: North → "facing each other".** v0.14 decision #15
  ("Default facing = North for all units") is overturned. The new
  spawn default is opposing-side-facing, applied to both armies.
  This only matters at spawn since rotation is already free.
- **Encirclement for tanks: 4 neighbors → 2 hugs via reach.** Tanks
  get a relaxed encirclement threshold reflecting their long reach.
  Other units still require the standard 4-orthogonal-neighbor
  encirclement.
- **Minimum damage floor: open → 1 (with the existing Blitzkrieg-
  bounce exception).**

### New questions surfaced

- **None outside UI/UX.** The base ruleset is functionally closed.
  Remaining open work lives entirely in `ui_and_feedback.md`:
  pre-game menu layout, HUD surfaces for tracked state (facing,
  still-penalty counter, trench status, XP, doctrine effects),
  validation rules, and budget displays.

---

## v0.17 — 2026-05-02

> Source: PDF "AI game Heavy/Special units" — fills in the Tank,
> Motorized Infantry, and Artillery stat blocks, closes four
> doctrine-framework open questions, and refines the long-term trench
> escalation rules.

### Resolved
- **Tank base stat block.** HP 8 (1+7), base strength 3, base defense 3,
  attack reach 4 sq orthogonal / 3 sq diagonal. Base movement 3 ortho /
  0 diag was already on the books; the rest is new. Cross-reference:
  units_and_entities.md → §2.1, §2.3.
- **Motorized Infantry base stat block.** HP 6 (1+5), movement 3 ortho /
  2 diag, attack reach 3 sq (8-side), base strength 2, base defense 1.
  Cross-reference: units_and_entities.md → §2.1, §2.3.
- **Artillery base stat block.** HP 2 (1+1), movement 1 ortho / 1 diag,
  base strength 3, base defense 0.5. Reach 6 sq (already on the books)
  is confirmed as 8-side (diagonal fire is allowed). Cross-reference:
  units_and_entities.md → §2.1, §2.3.
- **Doctrine count → only 3 in the base game.** Plain, Blitzkrieg,
  Superior Firepower. Set is closed for now but flagged as expandable.
  Cross-reference: units_and_entities.md → §8.6.
- **Doctrine combinations → one per army.** Not stackable. Cross-reference:
  units_and_entities.md → §8.6.
- **Doctrine symmetry → same shared pool.** Doctrines are not faction-
  or side-locked. Identical-doctrine matchups (e.g. Blitzkrieg vs.
  Blitzkrieg) are allowed. Cross-reference: units_and_entities.md → §8.6.
- **Doctrine-locked units → none.** All five unit types are purchasable
  by any doctrine, subject only to per-doctrine point-buy caps.
  Cross-reference: units_and_entities.md → §8.6, economy.md → §E.2.
- **Trench reset → fully specified, 3-tier escalation.**
  - **3 turns held → exit:** trench disappears immediately. No carry-over.
  - **4 turns held → exit:** trench remains in place at full modifiers
    (Inf +2 / Cav +1.5). Other Inf/Cav may move onto the square and use
    the standing trench. A new occupant who stays a full 4 turns and
    then leaves resets the "trench remains" state. Empty trench
    eventually disappears.
  - **6 turns held → permanent:** trench locks in for the rest of the
    game, but both modifiers are reduced to **+1 defence**. Any Inf/Cav
    may freely use it; the reduced modifier cannot be restored to
    original values regardless of subsequent occupation.
  Cross-reference: combat.md → §5.6.

### Added
- **Tank attack-reach asymmetry note** (units_and_entities.md → §2.1, §2.3)
  — tanks are the only unit with different orthogonal vs. diagonal
  attack reach, called out explicitly so it doesn't read as a typo.
- **Re-occupation rules for the 4-turn trench tier** (combat.md → §5.6)
  — formalizes that a standing trench is shared infrastructure, not
  unit-bound, with a clear "if empty, eventually disappears" condition.

### Changed
- **Long-term trench (4-turn tier) → re-occupiable.** v0.16 said the
  bonus simply "carries over for 4 more turns." v0.17 replaces this
  with the full re-occupation model: the trench remains as a board
  feature, can be entered by any Inf/Cav, and the timer resets if a
  new occupant holds and leaves. The "4 more turns of free bonus on
  the original unit" framing is overturned.
- **Permanent trench (6-turn tier) → modifier locked, not just reduced.**
  v0.16 said the modifier was "reduced to +1." v0.17 clarifies that the
  reduction is **final** — re-occupation cannot restore the original
  +2 / +1.5 values.

### New questions surfaced
- **Tactics applicability to heavy units** — now that Tank/Motorized/
  Artillery have full base stats, the question of which combat tactics
  (encirclement, terrain attack bonuses, formation, trench, side/rear
  attack modifiers) apply to them is the most pressing remaining gap.
  Currently the only universal rule is "diagonal does not count as a
  positional tactic" (v0.16). Per-tactic per-unit applicability is
  unspecified.
- **Tank attack reach 4/3 in encirclement geometry** — a tank with
  4-square orthogonal reach can strike a target it is *not* adjacent
  to. Whether such attacks count toward "double attack" / "encirclement"
  bonuses (which currently require orthogonal *adjacency*) needs
  clarification once the heavy-tactics question above is addressed.

---

## v0.16 — 2026-05-01

> Source: PDF "Finishing the flagged questions" — a single document
> resolving roughly half of the v0.15 open-question backlog at once.

### Resolved
- **HQ win condition → fully defined.** HQs placed bottom-left and
  top-right (symmetric). Each HQ has a 3-square reach. Two parallel
  win paths: occupy the reach for 5 turns OR deal 20 damage.
  Cross-reference: game_core.md → §1.2.
- **HQ placement → corners (resolved).** Removes the v0.1
  companion-doc question. Cross-reference: game_core.md → §1.2.
- **IGOUGO actions per unit → 2 actions/turn.** Each unit may move or
  attack 2 times, freely split between movement and attack. Defines
  the "stamina" referenced by heavy-unit progression and the
  counter-attack rule. Cross-reference: game_core.md → §1.6.
- **Heavy-unit progression system → same level-based system.** The
  earlier "different (yet to be designed) system" speculation is
  dropped. Tank/Motorized share one progression table; Artillery has
  its own. Cross-reference: units_and_entities.md → §3.2a, §3.2b.
- **XP trigger → "stronger" not "smaller."** A unit gains XP when it
  defeats an enemy that is stronger by any of three criteria: higher
  rank, higher total raw strength, or currently benefiting from
  doctrine modifiers. Cross-reference: units_and_entities.md → §3.3.
- **Rank naming → Corporal / Captain / Colonel.** Named tiers
  confirmed over numbered. Cross-reference: units_and_entities.md → §3.4.
- **Heavy units cannot form formations.** Formation is light-only
  (Infantry + Cavalry). Cross-reference: units_and_entities.md → §4.1.
- **Long-term trench → escalation rules.** 4 turns held → bonus carries
  for 4 more turns even after the unit moves. 6 turns held → trench
  becomes permanent for the rest of the game, bonus reduced to +1 def
  for both Infantry and Cavalry. Cross-reference: combat.md → §5.6.
- **Counter-attack → defined.** Defender auto-rolls a counter-attack D6
  if it has attack-stamina remaining. If the attacker has fully
  exhausted its attacks that turn, the defender additionally gets a
  bonus D6 scaling 0.5 strength per pip (1→+0.5, 6→+3.0).
  Cross-reference: combat.md → §5.9.
- **Diagonal does not count as a positional-attack tactic.** This
  resolves the double-attack-adjacency question (diagonal neighbors
  do NOT contribute to the +1 strength double-attack bonus) and
  generalizes the encirclement-orthogonal-only rule to all positional
  bonuses. Cross-reference: combat.md → §5.9, §5.2, §7.
- **Plain doctrine → fully defined.** 14-unit starting army, player
  chooses up to 5 per class. Tank profile 2 ortho / 0 diag. No
  signature rule beyond the tank profile. War-point budget 30; up to
  5 units per class at point-buy; XP capped at 2nd level (Captain)
  per class. Cross-reference: units_and_entities.md → §8.5,
  economy.md → §E.1, §E.2, §E.3.
- **Per-doctrine war-point budgets.** Plain 30 / Superior Firepower
  35 / Blitzkrieg 25. Replaces the uniform 20. Cross-reference:
  economy.md → §E.1.
- **Unspecified XP-upgrade caps → all 0×.** All previously-"—" rows
  resolve to 0× (no upgrades): Blitzkrieg cavalry, Blitzkrieg
  artillery, Superior Firepower heavy. Cross-reference: economy.md → §E.3.
- **Doctrine selection method → pre-game pick on shared menu (partial).**
  Doctrine is chosen on the same combined pre-game menu used for
  war-point spending, placement, XP allocation, formation pairing,
  and entrenchment toggles. Cross-reference: units_and_entities.md →
  §8.6, ui_and_feedback.md, economy.md → §E.5.

### Added
- **Tank / Motorized progression table** (units_and_entities.md → §3.2a)
- **Artillery progression table** (units_and_entities.md → §3.2b)
- **Counter-attack mechanic** (combat.md → §5.9)
- **Blitzkrieg "bounce" rule** (combat.md → §5.9)
- **Long-term trench escalation** (combat.md → §5.6)
- **Pre-game menu (UI section)** (ui_and_feedback.md)

### Changed
- **Uniform 20-point budget → per-doctrine 30 / 35 / 25.**
- **"Smaller enemy unit" → "stronger enemy unit"** as the XP-gain trigger.
- **Double attack +1 str** now requires **orthogonal** adjacency only.

### New questions surfaced
- Tank / Motorized / Artillery base stat blocks.
- Tank "stamina" interaction with IGOUGO.
- Plain "no signature rule" — confirm intentional.

---

## v0.15 — 2026-05-01 *(backfilled from doc set)*

> Inferred from the v0.15 markers in `economy.md`, `units_and_entities.md`,
> `combat.md`, and `open_questions.md`.

### Resolved
- **Movement style → jump-based.**
- **Terrain types → 4 defined.**
- **Bad terrain → mountains only, all units.**
- **Player-chosen units → replaced by war-point system.**
- **"Heavy units" category → tanks and motorized infantry.**

### Added
- **`economy.md`** — full pre-game point-buy system.
- **Plain doctrine** — referenced as a third doctrine option.
- **Document split** — consolidated rules split into six files.

### New questions surfaced
- Plain doctrine full definition.
- Pre-game setup UI.
- Per-doctrine budget variations.
- Unspecified XP caps.
- Mid-game reinforcements.

---

## v0.14 — *(date unknown — pre-split baseline)*

> The consolidated rules document `strategy_game_rules_v0.14.md` and its
> companion `strategy_game_open_questions_v0.1.md` are the baseline this
> changelog starts tracking from.

### Decisions log (carried forward from v0.14 §10)
1–31: See `game_core.md → §10` for the full decisions log.

---

## Template for new entries

```
## v0.XX — YYYY-MM-DD

### Resolved
- **Question name → resolution.** One-line summary.
  Cross-reference: file.md → §X.Y.

### Added
- **New thing** — what it is, where it lives.

### Changed
- **Old rule → new rule.** Why it was overturned.

### New questions surfaced
- Question name — one-line description.
```
