# Strategy Game — Implementation Plan v1.0

> **Calibration:** Solo developer · v1 = hot-seat (local) + single-player vs AI · Desktop browser first.
> **Source-of-truth ruleset:** v0.18 (six split files). Base ruleset is functionally closed; only UI/UX is open.
> **Companion files:** see `game_core.md`, `units_and_entities.md`, `combat.md`, `economy.md`, `ui_and_feedback.md`, `open_questions.md`, `STATUS.md`, `CHANGELOG.md`.

---

## 1. Project analysis summary

### What v0.18 means for implementation

The ruleset is **not** the bottleneck. `STATUS.md` already scores the base ruleset at ~100% per system, and `open_questions.md` lists zero open base-ruleset items. What's actually unbuilt:

- A *technical* spec (the rules are in markdown prose, not in computable contracts yet)
- The pre-game menu UI
- The in-game HUD
- The rules engine itself
- The AI opponent
- Maps

So the work is translation, not invention. That's a meaningfully different posture than starting a design.

### Key ruleset components, identified for build

| Component | Source file | Build implications |
|---|---|---|
| 8-direction square grid, jump-based movement, 4-facing system, terrain types | `units_and_entities.md` §2.4–§2.5, §6 | Grid datatype + facing enum; movement legality is a pure function of (unit, origin, destination, terrain) |
| Five unit types with asymmetric tank reach (4 ortho / 3 diag) | `units_and_entities.md` §2.1, §2.3 | Per-unit stat record; reach is *not* uniform across units — schema must support split ortho/diag |
| Three progression tables (Inf/Cav, Tank+Motorized, Artillery) | `units_and_entities.md` §3 | XP is data, not control flow. Table lookup with stamina-bookkeeping side-effects |
| Combat resolver: positional bonuses, encirclement (with tank reach-hug exception), trench escalation, counter-attack bonus die, range falloff, min-damage floor with bounce exception | `combat.md` §5 | The single hardest pure module. Property-based tests recommended |
| Doctrine system as override packages | `units_and_entities.md` §8 | Doctrine is a layer that *replaces* base unit stats, not a multiplier. Engine needs a clear "resolve effective stats" step |
| Pre-game economy: per-doctrine war-point budgets, point-buy caps, XP costs, spawn-bonus costs | `economy.md` | Validation logic is non-trivial; budget caps interact with class caps |
| HQ + win condition (3-sq reach, 5-turn occupy OR 20 dmg, 1000-turn HQ-HP tiebreak) | `game_core.md` §1.2, §1.8 | Two parallel win paths + draw resolution + occupy timer per HQ |
| Pre-game shared menu doing six jobs (doctrine, points, placement, formation, entrenchment, XP, rotation) | `ui_and_feedback.md`, `economy.md` §E.5 | The single largest UX surface in the game |

### Technical complexity hotspots

These will eat disproportionate time. Plan around them:

1. **AI opponent.** Tactical games with positional state, asymmetric reach, doctrine-modified evaluation, and a 1000-turn horizon are punishing for game-tree search. Branching factor is wide (~14 units × ~2 actions each × move/attack choices × rotation). This is the single biggest engineering risk.
2. **Combat resolver edge cases.** Tank reach-as-adjacency interacting with 2-tank encirclement-hug, interacting with artillery-no-tactics exemption, interacting with Blitzkrieg corporal-bounce, interacting with formation immune-to-double-attack-but-each-rotates-individually. Combinatorics demand table-driven tests.
3. **Pre-game menu UX.** Six jobs, one screen. Failure mode is a usable but cluttered menu that hides budget remaining or doctrine caps. UX is the chokepoint, not the code.
4. **In-game HUD density.** Per unit you must surface: facing, still-penalty counter (Blitzkrieg tanks), trench tier (1 of 3 escalation states), XP rank, active doctrine effects, plus globals (HQ HP both sides, capture timer, turn count toward 1000). Easy to clutter.
5. **Trench-as-tile-state, not unit-state.** The 4-turn re-occupiable tier and 6-turn permanent-locked-at-+1 tier mean trenches survive their original occupant. Modeling trench as a unit property is the obvious-but-wrong design.

### What's deliberately out of scope for v1

- Netcode, accounts, matchmaking, persistent profiles
- Real-time / async online play
- Mobile responsive layout
- Procedural map generation
- Server-side anything

---

## 2. Phase breakdown

Five phases. Phases 1–3 are strictly sequential. Phase 4 (AI) can begin in parallel with phase 3 once the engine API is stable.

### Phase 1 — Spec freeze + design foundation

**Duration:** 2–3 weeks
**Primary environments:** Cowork + Design
**Goal:** when this phase ends, every rule is computable and every screen is wireframed.

**Cowork tasks**
- Translate the six markdown rule files into a `TECHNICAL_SPEC.md`: data schemas (TypeScript-style records), function contracts (e.g. `resolveAttack(attacker, defender, board, ctx) → DamageResult`), and a state machine for the IGOUGO turn loop including stamina/action tracking.
- Build a `COMBAT_TEST_CASES.md` enumerating edge cases extracted from `combat.md`: every entry in §5.10 (heavy-unit tactics applicability), every counter-attack/bounce scenario in §5.9, every trench tier transition in §5.6, the SF range-falloff bands, the tank-reach-hug encirclement, and the artillery exemption set.
- Maintain a working task list (the existing `STATUS.md` + `open_questions.md` pattern extends naturally).

**Design tasks**
- Pre-game menu wireframes (highest priority — biggest UX risk).
- In-game board rendering direction (pixel-art? clean iconography? top-down 2D? isometric? — desktop-first removes pressure to over-simplify).
- HUD wireframes with explicit information-hierarchy decisions for the dense state. Decide what's always-on vs. hover/click-to-expand.
- Visual style direction + design tokens (colors, spacing, typography) → `design-tokens.json` or Tailwind config.

**Deliverables**
- `TECHNICAL_SPEC.md`, schema files, `COMBAT_TEST_CASES.md`
- Pre-game menu wireframe set
- In-game HUD wireframe set
- Visual style guide + tokens

**Success criteria**
- You can write a combat damage test case from the spec alone, without re-opening `combat.md`.
- The pre-game menu wireframe correctly surfaces: current doctrine pick, war-point budget remaining, per-class buy caps, per-class XP-upgrade caps, board-half placement, formation pairing, entrenchment toggles, per-unit XP allocation, and per-unit facing.

---

### Phase 2 — Headless rules engine

**Duration:** 4–6 weeks
**Primary environment:** Code (Cowork supports test case enumeration)
**Goal:** a fully-tested rules engine that has zero dependency on UI.

**Modules (each a pure-function or data-oriented unit, all individually testable)**
- Grid + terrain layer
- Unit + facing + rotation
- Movement legality (terrain-restricted, jump-based, formation-aware)
- Combat resolver (the hard one) — including positional direction calc, encirclement detection (standard 4-neighbor + tank-reach-hug variant), counter-attack with bonus-die scaling, min-damage floor with bounce exception
- Trench state machine — three tiers (3-vanish / 4-re-occupiable / 6-permanent-at-+1), tile-property model
- Doctrine override layer ("compute effective unit stats given base stats + doctrine + XP")
- XP progression + stamina bookkeeping (level-1 bonus square has *this-turn* atk-stamina hit + *next-turn* no-move; level-2 bonus attack has *next-turn* no-attack)
- HQ damage + occupation-timer tracking
- Win-condition checker (occupy 5 turns OR 20 damage, plus 1000-turn HQ-HP tiebreak)
- Turn-loop state machine (IGOUGO, 2 actions/unit, rotation free anytime)
- Game-state serializer (so any board can become a test fixture and the AI can replay)

**Test approach**
- Test-first. Every module starts from `COMBAT_TEST_CASES.md`.
- For combat: property-based tests where viable (damage floor never goes below 1 except in the bounce case; net swings match the §5.4 table for every direction × position combination).
- Replay tests: serialize a known-good board, play through, assert end-state.

**Deliverables**
- An engine module that exposes `applyAction(state, action) → state` and `legalActions(state, player) → Action[]`. The second function is what unblocks AI in phase 4.
- A test harness with full coverage of the v0.18 rules.

**Success criteria**
- 100% rule coverage in tests, including all v0.18-flagged edge cases (Blitzkrieg bounce, tank reach-hug, artillery no-tactics, formation per-unit rotation, trench re-occupation, 1000-turn tiebreak).
- The engine has no `import` from any UI library.

---

### Phase 3 — Hot-seat playable build

**Duration:** 3–4 weeks
**Primary environments:** Code + Design
**Goal:** end-to-end playable hot-seat game in a desktop browser.

**Code tasks**
- Board renderer (Canvas or SVG — Canvas if you want flashy animations later, SVG if you want simplicity and dev-tools inspection).
- UI components for: pre-game menu (the wireframes from phase 1, now real), in-game HUD, action panel (move/attack/rotate/end-turn), doctrine reference panel.
- Action handling: click-to-select, click-to-move, click-target-to-attack, rotation control, formation stacking gesture.
- Save/resume via `localStorage` (serialize game state on every turn end; restore on page load).
- 2–3 handcrafted starter maps as JSON (one small, one medium, one with mixed terrain).

**Design tasks**
- Iterate on UI based on actually playing. Wireframes always lie a little.
- Tighten visual feedback for state changes (movement preview, attack-range overlay, valid-target highlighting).

**Deliverables**
- Playable hot-seat game (two humans, one keyboard).
- 2–3 starter maps.
- Save/resume working.

**Success criteria**
- Two humans complete a full match without the engine throwing or the UI hiding state.
- Every tracked rule (facing, still-penalty, trench tier, XP, doctrine effects, HQ HP, capture timer, turn count) is visible in the UI without the player needing to remember it. (`game_core.md` §1.1 says "the computer holds all memory" — phase 3 success means the *UI* shows that memory back to the player.)

---

### Phase 4 — AI opponent

**Duration:** 4–8 weeks (highest variance phase; AI quality is open-ended)
**Primary environment:** Code (Cowork tracks tuning logs and difficulty calibration; Design handles AI-difficulty-selection UI)
**Goal:** single-player vs AI fully playable with at least three difficulty tiers.

**Recommended approach**
- **Start dumb.** Day 1 ships an AI that plays random legal moves with a tiny bias (prefer attacks over moves when an attack is legal). This validates the engine API before you sink time in search.
- **Heuristic evaluator first.** A static board-evaluation function that scores positions on: HQ damage delta, unit count delta, positional pressure (units inside opponent's HQ reach), doctrine theme adherence (Blitzkrieg = tank movement bonus, SF = artillery range coverage, Plain = balanced).
- **Iterative-deepening minimax with alpha-beta.** Start at depth 2, push to depth 4 if performance allows. Branching is wide (~14 units × 2 actions × ~10 targets each), so prune aggressively: only consider attacks for units in striking range, only consider movement for units that can affect the next-turn attack window.
- **Fall back to MCTS** *only* if minimax can't reach depth 3 inside a reasonable per-turn budget (~2 sec). Don't preemptively choose MCTS — minimax is simpler to debug.
- **Doctrine-aware behavior** is what will make the AI feel right. A Blitzkrieg AI that lets its tanks sit still is a bug, not a feature. Build doctrine-specific eval bonuses/penalties into the heuristic.
- **AI pre-game army builder** is a *separate* problem from in-game AI. Solve it with simple templates per doctrine (e.g. Blitzkrieg AI always spends its 25 points on +4 infantry + spawn-formations) before adding optimization.

**Difficulty tiers**
- Easy: depth-1 search + weak heuristic, picks suboptimal moves 30% of the time
- Normal: depth-2 or 3 search + full heuristic
- Hard: depth-3 or 4 search + tuned heuristic + opening book per doctrine

**Deliverables**
- Single-player vs AI playable on all three difficulty tiers.
- AI pre-game army builder for all three doctrines.

**Success criteria**
- A normal-difficulty AI demonstrably uses doctrine signature mechanics: Blitzkrieg AI keeps tanks moving (you can see the still-penalty counter staying at 0), SF AI parks artillery at range 6–8 and uses range-falloff zones, Plain AI plays balanced.
- AI turn budget stays under 3 seconds per turn at normal difficulty.

---

### Phase 5 — Polish, content, ship-ready

**Duration:** 3–6 weeks
**Primary environments:** all three
**Goal:** v1 release.

**Tasks**
- **Tutorial / onboarding.** This game has a lot of rules. First-run flow needs to teach core mechanics without dumping the full ruleset. Recommend a guided first-mission.
- **Audio + visual feedback.** None of this is in the docs — pure design work. Hit sounds, movement sounds, doctrine-themed UI sounds, ambient board music.
- **More maps.** Aim for 5–8 handcrafted maps at ship.
- **Map editor (optional for v1).** In-browser JSON map editor is nice-to-have. If time-constrained, ship with hand-written maps + a map authoring guide in `MAP_AUTHORING.md`.
- **Performance audit.** Profile the renderer and AI. Web Workers for AI search is the obvious win if AI turns feel laggy.
- **Accessibility pass.** Keyboard navigation for all menu items, color-blind-safe palette for the doctrine effect indicators, screen-reader labels for unit cards.
- **Browser compatibility test.** Chrome + Firefox + Safari at minimum.
- **Build + deploy pipeline.** Static-site host (Netlify, Vercel, or GH Pages — all three are free for this scope).

**Deliverables**
- Shippable v1 with tutorial, audio, 5+ maps, AI, accessibility pass, deployed publicly.

**Success criteria**
- A friend who has never seen the rules can complete the tutorial and play one full match against the AI without asking you a question.

---

## 3. Environment assignment matrix

| Task category | Code | Cowork | Design | Rationale |
|---|---|---|---|---|
| Technical spec, schemas, function contracts | — | **Primary** | — | Translation from rules prose → computable contracts is documentation work |
| Combat test case enumeration | Supports | **Primary** | — | List-of-edge-cases is documentation; Code consumes the list |
| Wireframes, visual style, design tokens | — | — | **Primary** | UI/UX is what `ui_and_feedback.md` is missing |
| Rules engine implementation | **Primary** | — | — | Pure code work |
| Test suite (unit + property-based + replay) | **Primary** | Supports | — | Code writes the tests; Cowork curates the case list |
| UI components | **Primary** | — | Supplies tokens | Code implements; Design supplies the visual contract |
| Action handling + UX flow | **Primary** | — | Iterates | Code wires it; Design refines after playtest |
| AI search + heuristic | **Primary** | Tracks tuning | — | Pure code, but Cowork keeps a tuning log |
| AI difficulty UI | Supports | — | **Primary** | Difficulty selector is a UX problem, not a code problem |
| Map content (JSON files) | Supports | Supports | **Primary** | Map design is taste and balance — that's a designer's call |
| Audio assets | — | — | **Primary** | Design domain, not in current docs |
| Tutorial flow | Supports | **Primary** | **Primary** | Cowork sequences the lessons; Design renders them |
| Build + deploy pipeline | **Primary** | — | — | Pure infra |
| Documentation (README, MAP_AUTHORING, etc.) | — | **Primary** | — | This is what Cowork is for |
| Open question tracking | — | **Primary** | — | Already the existing pattern in `open_questions.md` and `STATUS.md` |
| Performance audit | **Primary** | — | — | Profiling is code work |
| Accessibility pass | Supports | Supports | **Primary** | Design owns visual accessibility; Code implements it |

---

## 4. Integration & handoff points

Solo dev means handoffs are between *Claude environments*, not between people. The integration discipline is "what artifact does each environment leave behind for the next one to pick up?"

### Cowork → Code
- **Artifact:** `TECHNICAL_SPEC.md` + schema files + `COMBAT_TEST_CASES.md` + ticket-style task list.
- **When:** end of phase 1, then incrementally as new questions surface.
- **Failure mode:** spec ambiguity that forces Code to re-read `combat.md`. Treat that as a Cowork bug — fix the spec, don't fix the code in isolation.

### Design → Code
- **Artifact:** wireframes (image or HTML/CSS prototype) + `design-tokens.json` (or Tailwind config) + interaction notes.
- **When:** end of phase 1, then iteratively in phase 3.
- **Failure mode:** wireframes that don't account for the engine's actual state shape. Mitigation: Design references the schema files Cowork produced.

### Code → Cowork
- **Artifact:** updates to `STATUS.md` (existing pattern), test pass rate, what's blocked.
- **When:** end of every working session, mirroring the existing changelog discipline.
- **Failure mode:** silent drift between what's built and what `STATUS.md` claims. The discipline is already encoded in `STATUS.md`'s "Update this file at the end of every session."

### Code → Design
- **Trigger:** "I built this UI from the wireframe and it feels wrong."
- **Artifact:** annotated screenshot + a description of what feels off.
- **Action:** Design iterates the wireframe; Code re-implements.

### Design → Cowork
- **Trigger:** new UI questions surface as the design progresses.
- **Artifact:** new entries in `ui_and_feedback.md`, mirrored in `open_questions.md`.

### Cross-phase dependencies (the strict ordering)
- Phase 2 needs phase 1 spec frozen. If you start Phase 2 with an unfinished spec, you'll relitigate combat math in code, which is the worst place to do it.
- Phase 3 needs phase 2 engine working — UI is downstream of engine, not parallel to it. The temptation to build "just the board renderer" before the engine is real; resist.
- Phase 4 needs phase 2 engine *plus* a clean `legalActions(state, player)` function. Make sure phase 2 exposes this — it's how the AI sees the world.
- Phase 5 needs phases 3 and 4 functionally complete. Polish-before-function is a classic time sink.

---

## 5. Risk & mitigation

Top risks specific to *this* project, not generic software risks.

| # | Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|---|
| 1 | AI quality is open-ended; "good AI" eats unbounded time | High | High | Ship dumb AI on day 1 of phase 4. Iterate. Set "AI plays the doctrine theme" as the bar, not "AI is hard to beat." |
| 2 | Combat resolver edge case explosion | High | Med | Property-based tests + table-driven tests. Start `COMBAT_TEST_CASES.md` in phase 1 before any code. |
| 3 | Pre-game menu UX is cluttered | Med | High | Prototype this *before* writing engine UI integration. Paper or Figma → clickable HTML prototype → implementation. Three iterations before Code touches it. |
| 4 | HUD information density (8+ tracked things per unit) | Med | Med | Progressive disclosure: hover/click-to-expand for per-unit detail; only critical state always-on (HP, facing arrow, trench tier badge). Color-code doctrine effects. |
| 5 | Trench modeled as unit state instead of tile state | Med | Med | Caught at spec time: `TECHNICAL_SPEC.md` must explicitly model trench as a tile property with an occupant-timer. Re-read `combat.md` §5.6 before locking the schema. |
| 6 | Scope creep ("what if I added online?") | Low | High | Online is explicitly out of v1. If it returns, fork after v1 ships. |
| 7 | Solo burnout | Med | High | Phases are independently shippable: hot-seat at end of phase 3 is *playable* without AI. A friend can playtest there. Don't rebuild architecture for AI in phase 4 — design phase 2's engine API to support AI from day 1. |
| 8 | Map editor temptation eats phase 3 | Med | Med | Don't build the editor before phase 5. Hand-write JSON for the first 3 maps. The editor is a bonus, not a blocker. |
| 9 | Doctrine override layer leaks into base unit math | Med | Med | Architecture rule: `getEffectiveStats(unit, doctrine, level)` is a pure function called once per combat resolution. Base stats are never mutated. This stays clean if encoded as a rule from day 1. |
| 10 | AI search performance fails at depth 3+ in a desktop browser | Low | Med | Web Workers for AI search. Aggressive pruning (don't search moves for units that can't affect anything next turn). MCTS as fallback. |

---

## 6. Timeline & resource notes

### Sequencing summary
- Phases 1 → 2 → 3 are **strictly sequential**.
- Phase 4 (AI) can begin **in parallel with phase 3** once the engine API is stable. AI dev is essentially a CLI client of the engine — it doesn't need UI.
- Phase 5 polish has many parallel tracks (audio, tutorial, more maps, performance audit, accessibility). Pick whichever is most fun on a given day.

### Estimated calendar duration

Assuming roughly 15–25 hours/week (typical solo side-project hours):

| Phase | Duration | Notes |
|---|---|---|
| Phase 1 — Spec + design | 2–3 weeks | Don't skimp; this saves time later |
| Phase 2 — Engine | 4–6 weeks | Combat resolver is the long pole |
| Phase 3 — Hot-seat playable | 3–4 weeks | Faster if Phase 1 design was thorough |
| Phase 4 — AI | 4–8 weeks | Highest variance; budget conservatively |
| Phase 5 — Polish + ship | 3–6 weeks | Can be cut short for a v1.0 release, then v1.1 etc. |
| **Total** | **~16–27 weeks (4–7 months)** | |

If full-time (40 hrs/week), roughly halve the calendar duration → ~2.5–3.5 months total.

### Quick wins to do in week 1, regardless of phase plan

These don't need a finished spec and pay back immediately:

- Set up a TypeScript + Vite + Vitest project scaffold.
- Encode the unit roster from `units_and_entities.md` §2.1 as a TypeScript data file. It's already a table — just transcribe it.
- Encode the four terrain types and their per-unit modifiers from §2.5 as a table.
- Encode the doctrine starting armies from §8.3 / §8.4 / §8.5 as data.
- Build a "render-the-board-from-JSON" harness that takes a board state and draws it. No game logic; just visual feedback you can see.

That gets you visual feedback within day 1 and gives Phase 1's design work something to react to.

### Parallel vs. sequential at a glance

```
Phase 1 ──────┐
              │
Phase 2 ──────────────────┐
              │           │
Phase 3 ──────────────────┐
                          │
Phase 4 ──────────────┐   (Phase 4 can start mid-Phase 3
                      │    once engine API is stable)
Phase 5 ──────────────────────────┐
                                  │
                                  v
                                v1 ship
```

---

## Appendix A — Quick environment-by-environment cheat sheet

**When to reach for Claude Code**
- Writing or debugging engine logic (rules, combat resolver, AI search)
- Test suites (unit, property-based, replay)
- UI component implementation (after design hands off the wireframe)
- Build + deploy pipeline
- Performance profiling
- Anything where the deliverable is a runnable file

**When to reach for Claude Cowork**
- Translating rule prose into a technical spec
- Maintaining the task list / kanban
- Writing `COMBAT_TEST_CASES.md` and similar enumerations
- Updating `STATUS.md` and `CHANGELOG.md` (the existing pattern)
- Tutorial lesson sequencing
- Final-pass documentation (README, MAP_AUTHORING.md)
- Anything where the deliverable is a markdown document or a list

**When to reach for Claude Design**
- Pre-game menu wireframes and interaction flows
- HUD information hierarchy
- Visual style direction and design tokens
- Map content design (taste + balance)
- Audio direction
- Tutorial visual flow
- Accessibility (palette, layout, screen-reader labels)
- Anything where the deliverable is a visual artifact or a UX decision

---

## Appendix B — Self-check against the original requirements

- ✅ Each major ruleset component is mapped to a phase and an environment (see §1 component table + §2 phase breakdown + §3 matrix)
- ✅ Integration points are explicit (§4)
- ✅ Plan is actionable without further clarification (week-1 quick wins in §6)
- ✅ Risks are identified with mitigations (§5, ten enumerated risks)
- ✅ Timeline is realistic for solo, hot-seat + AI, desktop-first, ~15–25 hrs/week scope (§6)
- ✅ Recommendations tie to specific rules files, not generic boilerplate (every section cross-references the actual project docs)

---

*Living document. Update at the end of each phase to reflect what shipped, what slipped, and what new questions surfaced — same discipline as `STATUS.md` and `CHANGELOG.md`.*
