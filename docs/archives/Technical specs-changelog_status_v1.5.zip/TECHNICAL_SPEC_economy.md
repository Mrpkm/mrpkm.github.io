# TECHNICAL_SPEC — Economy (Pre-Game Point-Buy)

> Translated from `economy.md` (resolved as of v0.16; confirmed v0.18). Source-of-truth
> prose lives in `economy.md`; this file is the computable contract derived from it.
> If they conflict, update this file and note the discrepancy.
>
> **Scope:** The pre-game point-buy system — war-point budgets, unit purchases, XP
> purchases, spawn-state bonuses, doctrine caps, validation, and the pre-game setup
> state machine.
> **Out of scope:** All in-game economy (none exists — see §E.5 of source). The
> in-game IGOUGO turn loop and per-unit stamina live in `TECHNICAL_SPEC_units_entities.md §10`
> and are deliberately NOT redefined here. Combat resolution lives in
> `TECHNICAL_SPEC_combat.md`.
>
> **Cross-spec type imports:** This spec assumes `UnitType`, `DoctrineType`, `Rank`,
> `UnitId`, `PlayerIndex`, `Facing`, `GridPos`, and `UnitState` are imported from
> `TECHNICAL_SPEC_units_entities.md`. It does not redeclare them.

---

## 1. Data Schemas

### 1.1 Primitive Enums and Literal Types

```typescript
/**
 * The four point-buy categories used by both unit-purchase caps (E.2) and
 * XP-upgrade caps (E.3). Derived from UnitType via categoryOf().
 *
 * - 'heavy'         = Tank + MotorisedInf
 * - 'lightInfantry' = Infantry only
 * - 'lightCavalry'  = Cavalry only
 * - 'special'       = Artillery only
 */
type PurchaseCategory =
  | 'heavy'
  | 'lightInfantry'
  | 'lightCavalry'
  | 'special';

/** The two spawn-state bonus types defined in §E.4. */
type SpawnBonusType =
  | 'entrenched'   // unit begins game with trench bonus active (bypasses 3-turn timer)
  | 'formation';   // two light units begin game already stacked as a formation

/**
 * Phases of the pre-game setup state machine. See §3.
 * NOTE: Distinct from `TurnPhase` in TECHNICAL_SPEC_units_entities.md §10.
 * After Finalized, control passes to TurnPhase.PreGame → PlayerTurnStart(0)
 * in the units spec.
 */
type PreGameSetupPhase =
  | 'Idle'              // no doctrine selected; no economy operations valid
  | 'DoctrineSelected'  // transient: doctrine picked, budget materialised, no purchases yet
  | 'Composing'         // player is freely allocating war points (purchase / refund / adjust)
  | 'Finalized';        // setup committed; no further mutations; roster handed to in-game

/** Discriminator for fallible economy operations. */
type Result<T, E extends EconomyError> =
  | { readonly ok: true;  readonly value: T }
  | { readonly ok: false; readonly error: E };
```

### 1.2 Purchase Records

```typescript
/**
 * A single additional unit bought via §E.2.
 * Free-doctrine starting-army units are NOT represented here — they live
 * in the doctrine's free roster (units_and_entities.md §8.3 / §8.4 / §8.5).
 */
interface UnitPurchase {
  readonly purchaseId: string;     // stable id within the setup; survives refunds via tombstones
  readonly unitType: UnitType;
  readonly category: PurchaseCategory;
  readonly cost: number;           // ECONOMY_CONFIG.UNIT_COSTS[unitType] at purchase time
}

/**
 * An XP upgrade purchased for ONE specific unit (free or bought).
 * The unit is identified by UnitId — the same id it will carry into the match.
 * Cost is the cumulative cost from the unit's *current* rank up to targetRank.
 */
interface XpPurchase {
  readonly purchaseId: string;
  readonly targetUnitId: UnitId;
  readonly targetUnitCategory: PurchaseCategory;
  readonly fromRank: Rank;          // unit's rank before this purchase (usually Recruit)
  readonly targetRank: Rank;        // strictly greater than fromRank
  readonly cost: number;            // sum of ECONOMY_CONFIG.XP_COSTS[r] for r in (fromRank, targetRank]
}

/**
 * A spawn-state bonus purchase per §E.4.
 * - Entrenched: applies to one unit. eligibleUnitIds.length === 1.
 * - Formation:  pairs two light units. eligibleUnitIds.length === 2.
 */
interface SpawnBonusPurchase {
  readonly purchaseId: string;
  readonly bonusType: SpawnBonusType;
  readonly eligibleUnitIds: readonly UnitId[];
  readonly cost: number;            // 3 for entrenched, 5 for formation
}
```

### 1.3 Caps

```typescript
/**
 * Per-category cap on additional units a doctrine may PURCHASE (E.2).
 * Caps deliberately exceed what the budget can fund — see economy.md §E.2.
 * 0 means the doctrine forbids purchases in this category (e.g. Blitzkrieg heavy = 0).
 */
type UnitPurchaseCap = number;

/**
 * Per-category cap on XP upgrades a doctrine permits (E.3).
 *
 * - `maxRank`: highest rank reachable via pre-game purchase.
 *   `Rank.Recruit` (0) means NO upgrades allowed in this category for this doctrine.
 *   This handles the v0.16 resolution: all "—" rows are 0×.
 *
 * - `maxUpgradedUnits`: how many distinct units of this category may be upgraded
 *   pre-game. `null` means "no per-category count limit beyond the budget itself"
 *   (Plain's special rule, v0.16). A finite number is the literal "up to N×" rule.
 */
interface DoctrineXpCap {
  readonly maxRank: Rank;
  readonly maxUpgradedUnits: number | null;
}

/**
 * Full cap set for one doctrine. Aggregates §E.1 / §E.2 / §E.3 in one struct.
 */
interface DoctrineEconomyProfile {
  readonly doctrine: DoctrineType;
  readonly warPointBudget: number;
  readonly unitPurchaseCaps: Readonly<Record<PurchaseCategory, UnitPurchaseCap>>;
  readonly xpUpgradeCaps:    Readonly<Record<PurchaseCategory, DoctrineXpCap>>;
}
```

### 1.4 Setup State

```typescript
/**
 * Full mutable state of one player's pre-game setup.
 *
 * Mutation occurs ONLY through the function contracts in §2. Direct field
 * mutation by callers is forbidden — fields are typed as readonly arrays so
 * helpers must produce new state objects (immutable update style preferred).
 *
 * The `freeRoster` is supplied at construction (from doctrine selection) and
 * is the input from `units_and_entities.md §8.3 / §8.4 / §8.5`. It is INCLUDED
 * in xp-purchase eligibility (§E.3 explicitly: "Any unit in the player's army,
 * free starting unit *or* point-bought") but NOT in the unit-purchase tally
 * (caps in §E.2 apply to *additional* units only).
 */
interface PreGameSetupState {
  readonly playerId: PlayerIndex;
  readonly phase: PreGameSetupPhase;
  readonly doctrine: DoctrineType | null;     // null iff phase === 'Idle'
  readonly profile: DoctrineEconomyProfile | null; // null iff phase === 'Idle'

  /** Units provided free by the doctrine. Read-only after phase enters DoctrineSelected. */
  readonly freeRoster: readonly UnitId[];

  /** All bought-via-§E.2 units, in purchase order. */
  readonly unitPurchases: readonly UnitPurchase[];

  /** All §E.3 XP purchases, in purchase order. */
  readonly xpPurchases: readonly XpPurchase[];

  /** All §E.4 spawn-bonus purchases, in purchase order. */
  readonly spawnBonusPurchases: readonly SpawnBonusPurchase[];

  /** Monotonically increasing counter for purchaseId minting. */
  readonly nextPurchaseSeq: number;
}

/**
 * Frozen output of finalizeSetup(). Hand-off contract to the in-game system.
 * The economy system retains NO state after producing this — leftover war
 * points are forfeit (§E.5).
 */
interface FinalizedRoster {
  readonly playerId: PlayerIndex;
  readonly doctrine: DoctrineType;

  /** Every unit (free + bought) that will exist on board at match start. */
  readonly units: readonly RosterEntry[];

  /** Formation pairings declared at setup; the in-game system materialises these. */
  readonly formationPairs: readonly (readonly [UnitId, UnitId])[];

  /** Total war points spent. ALWAYS ≤ profile.warPointBudget; the rest is forfeit. */
  readonly pointsSpent: number;
  readonly pointsForfeit: number;
}

/**
 * One unit's spec at match start, ready for the units spec to ingest as UnitState.
 * `startsEntrenched` is the only field that crosses into combat-spec territory
 * (it pre-populates a `TrenchState` on the unit's tile per combat.md §5.6).
 */
interface RosterEntry {
  readonly unitId: UnitId;
  readonly unitType: UnitType;
  readonly rank: Rank;
  readonly startsEntrenched: boolean;
  readonly source: 'free' | 'purchased';
}
```

---

## 2. Function Contracts

### 2.1 Typed Error Classes

```typescript
/** Discriminated base class for every fallible economy operation. */
abstract class EconomyError extends Error {
  abstract readonly kind: string;
}

/** Caller attempted an operation requiring a doctrine before one was selected. */
class DoctrineNotSelectedError extends EconomyError {
  readonly kind = 'DoctrineNotSelected' as const;
  constructor() { super('No doctrine selected; setup is in Idle phase.'); }
}

/**
 * Caller attempted to mutate setup after finalizeSetup() succeeded.
 * Setup is immutable post-finalize.
 */
class SetupAlreadyFinalizedError extends EconomyError {
  readonly kind = 'SetupAlreadyFinalized' as const;
  constructor() { super('Setup is finalized; no further mutations are allowed.'); }
}

/** Total spend after the operation would exceed profile.warPointBudget. */
class BudgetExceededError extends EconomyError {
  readonly kind = 'BudgetExceeded' as const;
  constructor(
    public readonly attemptedSpend: number,
    public readonly budget: number,
  ) {
    super(`Budget exceeded: ${attemptedSpend} > ${budget}.`);
  }
}

/** Purchasing this unit would exceed the doctrine's cap for its category. */
class UnitCapExceededError extends EconomyError {
  readonly kind = 'UnitCapExceeded' as const;
  constructor(
    public readonly category: PurchaseCategory,
    public readonly cap: number,
    public readonly currentCount: number,
  ) {
    super(`Unit cap exceeded for ${category}: ${currentCount}/${cap}.`);
  }
}

/**
 * XP purchase exceeds the doctrine's cap — either the rank ceiling
 * (e.g. Plain cannot reach Colonel) or the per-category count cap.
 */
class XpCapExceededError extends EconomyError {
  readonly kind = 'XpCapExceeded' as const;
  constructor(
    public readonly category: PurchaseCategory,
    public readonly reason: 'maxRankBreached' | 'maxUpgradedUnitsBreached',
    public readonly detail: string,
  ) {
    super(`XP cap exceeded for ${category} (${reason}): ${detail}.`);
  }
}

/**
 * XP purchase target is malformed: targetRank ≤ fromRank, fromRank not the
 * unit's actual rank, or rank value out of enum range.
 */
class InvalidXpTargetError extends EconomyError {
  readonly kind = 'InvalidXpTarget' as const;
  constructor(public readonly detail: string) { super(`Invalid XP target: ${detail}.`); }
}

/** Unit referenced by a purchase does not exist in the player's setup roster. */
class UnknownUnitError extends EconomyError {
  readonly kind = 'UnknownUnit' as const;
  constructor(public readonly unitId: UnitId) {
    super(`Unit ${unitId} is not in the player's roster.`);
  }
}

/**
 * Spawn-bonus purchase failed eligibility check:
 * - Entrenched: unit cannot normally trench (Heavy / Artillery ineligible per
 *   combat invariant 4.7 + units spec trench advancement filter).
 * - Formation: at least one designated unit is not light, OR fewer/more than
 *   2 units supplied, OR a unit is already in another formation.
 */
class IneligibleSpawnBonusError extends EconomyError {
  readonly kind = 'IneligibleSpawnBonus' as const;
  constructor(
    public readonly bonusType: SpawnBonusType,
    public readonly detail: string,
  ) {
    super(`Spawn bonus ${bonusType} is ineligible: ${detail}.`);
  }
}

/** A purchase being refunded does not exist in the corresponding purchase list. */
class PurchaseNotFoundError extends EconomyError {
  readonly kind = 'PurchaseNotFound' as const;
  constructor(public readonly purchaseId: string) {
    super(`Purchase ${purchaseId} not found.`);
  }
}

/** State-machine event illegal in the current phase. */
class InvalidPhaseTransitionError extends EconomyError {
  readonly kind = 'InvalidPhaseTransition' as const;
  constructor(
    public readonly from: PreGameSetupPhase,
    public readonly event: string,
  ) {
    super(`Cannot apply event '${event}' in phase '${from}'.`);
  }
}

/** Aggregate error returned by finalizeSetup() when ANY validator fails. */
class SetupValidationFailedError extends EconomyError {
  readonly kind = 'SetupValidationFailed' as const;
  constructor(public readonly errors: readonly EconomyError[]) {
    super(`Setup validation failed with ${errors.length} error(s).`);
  }
}
```

### 2.2 Pure Helpers (no side effects)

```typescript
/**
 * Maps a UnitType to its PurchaseCategory.
 * @throws never — total over UnitType.
 */
declare function categoryOf(unitType: UnitType): PurchaseCategory;

/**
 * Returns the per-level XP cost (NOT cumulative) for buying *up to* targetRank.
 * E.g. costForLevel(Rank.Captain) === 4.
 * @throws InvalidXpTargetError if targetRank === Rank.Recruit (no level 0 cost).
 */
declare function costForLevel(targetRank: Rank): number;

/**
 * Returns the cumulative XP cost to upgrade a unit from `fromRank` to `targetRank`.
 * Equals sum of costForLevel(r) for r in (fromRank, targetRank].
 * @returns 0 if fromRank === targetRank.
 * @throws InvalidXpTargetError if targetRank < fromRank.
 */
declare function cumulativeXpCost(fromRank: Rank, targetRank: Rank): number;

/**
 * Computes total points spent across all three purchase categories.
 * Pure summation — does NOT validate.
 * @throws never
 */
declare function totalSpent(setup: PreGameSetupState): number;

/**
 * Computes remaining budget. Negative is possible only via internal bug
 * (validators guard against overspend); callers should treat <0 as a defect.
 * @throws DoctrineNotSelectedError if setup.profile === null.
 */
declare function remainingBudget(setup: PreGameSetupState): number;

/**
 * Returns the unit's CURRENT rank inside this setup, factoring in any
 * pending XpPurchase already in setup.xpPurchases.
 * @throws UnknownUnitError if unitId not in freeRoster ∪ unitPurchases.
 */
declare function effectiveRank(setup: PreGameSetupState, unitId: UnitId): Rank;

/**
 * Counts how many distinct units of the given category have at least one
 * XpPurchase in the setup. Used by xpUpgradeCap validation.
 * @throws never
 */
declare function countUpgradedUnitsInCategory(
  setup: PreGameSetupState,
  category: PurchaseCategory,
): number;

/**
 * Returns true iff the unit may be spawned entrenched per combat invariant 4.7
 * (Infantry or Cavalry only — Heavy and Artillery cannot trench).
 * @throws UnknownUnitError if unitId not in roster.
 */
declare function canSpawnEntrenched(
  setup: PreGameSetupState,
  unitId: UnitId,
): boolean;

/**
 * Returns true iff both unitIds are light (Infantry or Cavalry), distinct,
 * and neither already participates in another formation purchase in setup.
 * @throws UnknownUnitError if any unitId not in roster.
 */
declare function canFormFormation(
  setup: PreGameSetupState,
  unitIdA: UnitId,
  unitIdB: UnitId,
): boolean;
```

### 2.3 Construction

```typescript
/**
 * Creates a fresh setup in Idle phase. No doctrine, no budget, no purchases.
 * @param playerId - Identifier of the player who owns this setup.
 * @returns A new PreGameSetupState in phase 'Idle'.
 * @throws never
 * @sideEffects None.
 */
declare function createPreGameSetup(playerId: PlayerIndex): PreGameSetupState;

/**
 * Selects a doctrine for an Idle setup, materialising the doctrine's profile
 * (budget + caps) and free roster. Transitions phase Idle → DoctrineSelected → Composing.
 *
 * If called on a non-Idle setup, fails — to change doctrine after composing,
 * call resetSetup() first.
 *
 * @param setup - Must be in 'Idle' phase.
 * @param doctrine - The doctrine being selected.
 * @param freeRoster - The doctrine's free starting army; supplied by caller from
 *                     units_and_entities.md §8.3/§8.4/§8.5. Each entry must already
 *                     have a stable UnitId.
 * @returns Updated setup in 'Composing' phase with profile populated.
 * @throws InvalidPhaseTransitionError if setup.phase !== 'Idle'.
 * @sideEffects Returns a new state object; does not mutate `setup`.
 */
declare function selectDoctrine(
  setup: PreGameSetupState,
  doctrine: DoctrineType,
  freeRoster: readonly UnitId[],
): Result<PreGameSetupState, InvalidPhaseTransitionError>;

/**
 * Discards all purchases and the doctrine selection, returning to Idle.
 * Allowed from Composing only (Finalized is irreversible).
 *
 * @throws SetupAlreadyFinalizedError if setup.phase === 'Finalized'.
 * @sideEffects Returns a new state object; does not mutate `setup`.
 */
declare function resetSetup(
  setup: PreGameSetupState,
): Result<PreGameSetupState, SetupAlreadyFinalizedError>;
```

### 2.4 Unit Purchases (§E.2)

```typescript
/**
 * Buys one additional unit of the given type per §E.2.
 * Validates: phase, budget, doctrine unit-purchase cap for the unit's category.
 *
 * @param setup - Must be in 'Composing' phase.
 * @param unitType - The unit class being bought.
 * @param newUnitId - Caller-supplied stable id for the unit-to-be. Must not collide
 *                    with any existing roster id.
 * @returns Updated setup with the new UnitPurchase appended, on success.
 * @throws DoctrineNotSelectedError    if setup.profile === null.
 * @throws SetupAlreadyFinalizedError  if setup.phase === 'Finalized'.
 * @throws BudgetExceededError         if remainingBudget < UNIT_COSTS[unitType].
 * @throws UnitCapExceededError        if doctrine cap for this category is reached.
 * @sideEffects Returns a new state object; does not mutate `setup`.
 */
declare function purchaseUnit(
  setup: PreGameSetupState,
  unitType: UnitType,
  newUnitId: UnitId,
): Result<
  PreGameSetupState,
  | DoctrineNotSelectedError
  | SetupAlreadyFinalizedError
  | BudgetExceededError
  | UnitCapExceededError
>;

/**
 * Refunds (cancels) a previously-made unit purchase, returning its cost to
 * the available budget. Cascades: if the refunded unit had any XpPurchases
 * or was part of a SpawnBonusPurchase, those are ALSO refunded automatically
 * (the cascade is required because their target unit ceases to exist).
 *
 * @throws PurchaseNotFoundError       if no UnitPurchase has this purchaseId.
 * @throws SetupAlreadyFinalizedError  if setup.phase === 'Finalized'.
 * @sideEffects Returns a new state object. The cascade may remove other purchases.
 */
declare function refundUnitPurchase(
  setup: PreGameSetupState,
  purchaseId: string,
): Result<
  PreGameSetupState,
  | PurchaseNotFoundError
  | SetupAlreadyFinalizedError
>;
```

### 2.5 XP Upgrade Purchases (§E.3)

```typescript
/**
 * Buys an XP upgrade for one specific unit — free or bought — moving it from
 * its current rank to `targetRank` (must be strictly higher).
 *
 * Validates ALL of:
 *  1. Phase is 'Composing'.
 *  2. Target unit exists in freeRoster ∪ unitPurchases.
 *  3. targetRank > effectiveRank(setup, unitId) AND targetRank ≤ Rank.Colonel.
 *  4. targetRank ≤ doctrine.xpUpgradeCaps[category].maxRank.
 *  5. If maxUpgradedUnits is finite AND this unit is not already in the
 *     XP-upgraded set, then countUpgradedUnitsInCategory + 1 ≤ maxUpgradedUnits.
 *  6. Budget covers cumulativeXpCost(fromRank, targetRank).
 *
 * @param setup
 * @param unitId       Unit being upgraded.
 * @param targetRank   New rank after this purchase.
 * @returns Updated setup with one XpPurchase appended, on success.
 * @throws DoctrineNotSelectedError
 * @throws SetupAlreadyFinalizedError
 * @throws UnknownUnitError
 * @throws InvalidXpTargetError       if targetRank ≤ current rank or out of range.
 * @throws XpCapExceededError         if maxRank or maxUpgradedUnits is breached.
 * @throws BudgetExceededError
 * @sideEffects Returns a new state object.
 */
declare function purchaseXpUpgrade(
  setup: PreGameSetupState,
  unitId: UnitId,
  targetRank: Rank,
): Result<
  PreGameSetupState,
  | DoctrineNotSelectedError
  | SetupAlreadyFinalizedError
  | UnknownUnitError
  | InvalidXpTargetError
  | XpCapExceededError
  | BudgetExceededError
>;

/**
 * Refunds an XpPurchase by id, returning its cost to the budget.
 * Does NOT cascade — the target unit remains in the roster at its prior rank.
 *
 * @throws PurchaseNotFoundError
 * @throws SetupAlreadyFinalizedError
 * @sideEffects Returns a new state object.
 */
declare function refundXpUpgrade(
  setup: PreGameSetupState,
  purchaseId: string,
): Result<
  PreGameSetupState,
  | PurchaseNotFoundError
  | SetupAlreadyFinalizedError
>;
```

### 2.6 Spawn-State Bonus Purchases (§E.4)

```typescript
/**
 * Buys the "spawn entrenched" bonus for one unit (cost: 3 points).
 * Eligibility: canSpawnEntrenched(unitId) === true. Per combat invariant 4.7
 * this means the unit is Infantry or Cavalry. Heavy and Artillery are rejected.
 *
 * No doctrine cap is currently defined for spawn bonuses (§E.4: "Available
 * across all doctrines (no doctrine cap currently defined).").
 *
 * @throws DoctrineNotSelectedError
 * @throws SetupAlreadyFinalizedError
 * @throws UnknownUnitError
 * @throws IneligibleSpawnBonusError if the unit cannot normally trench.
 * @throws BudgetExceededError
 * @sideEffects Returns a new state object.
 */
declare function purchaseSpawnEntrenched(
  setup: PreGameSetupState,
  unitId: UnitId,
): Result<
  PreGameSetupState,
  | DoctrineNotSelectedError
  | SetupAlreadyFinalizedError
  | UnknownUnitError
  | IneligibleSpawnBonusError
  | BudgetExceededError
>;

/**
 * Buys the "spawn in formation" bonus pairing two light units (cost: 5 points).
 * Eligibility: canFormFormation(unitIdA, unitIdB) === true. Both must be
 * Infantry or Cavalry, distinct, and neither already in another formation pair.
 *
 * Per economy.md §E.4: "The 5-point formation bonus pays for the formation
 * itself — the two units participating must still be acquired separately
 * (free from the starting army or bought via §E.2)."
 *
 * @throws DoctrineNotSelectedError
 * @throws SetupAlreadyFinalizedError
 * @throws UnknownUnitError
 * @throws IneligibleSpawnBonusError if either unit is non-light, identical, or already paired.
 * @throws BudgetExceededError
 * @sideEffects Returns a new state object.
 */
declare function purchaseSpawnFormation(
  setup: PreGameSetupState,
  unitIdA: UnitId,
  unitIdB: UnitId,
): Result<
  PreGameSetupState,
  | DoctrineNotSelectedError
  | SetupAlreadyFinalizedError
  | UnknownUnitError
  | IneligibleSpawnBonusError
  | BudgetExceededError
>;

/**
 * Refunds a spawn-bonus purchase. Does not cascade.
 *
 * @throws PurchaseNotFoundError
 * @throws SetupAlreadyFinalizedError
 * @sideEffects Returns a new state object.
 */
declare function refundSpawnBonus(
  setup: PreGameSetupState,
  purchaseId: string,
): Result<
  PreGameSetupState,
  | PurchaseNotFoundError
  | SetupAlreadyFinalizedError
>;
```

### 2.7 Validation and Finalization

```typescript
/**
 * Runs ALL invariants over the setup and returns every violation found.
 * An empty array means the setup is finalize-ready.
 *
 * Invariants checked (each maps to one or more error classes):
 *  - phase === 'Composing' (or 'Finalized' iff `allowFinalized === true`).
 *  - totalSpent(setup) ≤ profile.warPointBudget.
 *  - For each PurchaseCategory: count of UnitPurchase ≤ unitPurchaseCaps[cat].
 *  - For each PurchaseCategory: every XpPurchase respects xpUpgradeCaps[cat]
 *    (both maxRank and maxUpgradedUnits if non-null).
 *  - Every XpPurchase.fromRank matches the unit's resolved rank from prior purchases.
 *  - Every SpawnBonusPurchase passes its eligibility check.
 *  - All purchaseIds are unique within their respective lists.
 *
 * @returns Empty array on success; populated on any violation.
 * @throws never
 * @sideEffects None — pure inspection.
 */
declare function validateSetup(
  setup: PreGameSetupState,
  options?: { readonly allowFinalized?: boolean },
): readonly EconomyError[];

/**
 * Commits the setup. Transitions phase 'Composing' → 'Finalized' and produces
 * the FinalizedRoster handed to the in-game system.
 *
 * - Forfeits any remaining budget into pointsForfeit (per §E.5).
 * - Materialises every XpPurchase into the corresponding RosterEntry.rank.
 * - Materialises every SpawnBonusPurchase: 'entrenched' → RosterEntry.startsEntrenched,
 *   'formation' → an entry in FinalizedRoster.formationPairs.
 *
 * Finalize is IRREVERSIBLE. After it succeeds, no economy mutation function
 * accepts the resulting setup.
 *
 * @throws SetupAlreadyFinalizedError    if already finalized.
 * @throws InvalidPhaseTransitionError   if phase ∉ {'Composing'}.
 * @throws SetupValidationFailedError    aggregating any validateSetup() errors.
 * @sideEffects Returns a new state object AND a FinalizedRoster. Callers must
 *              persist BOTH — the post-finalize setup is the audit trail; the
 *              roster is the in-game input.
 */
declare function finalizeSetup(
  setup: PreGameSetupState,
): Result<
  { readonly setup: PreGameSetupState; readonly roster: FinalizedRoster },
  | SetupAlreadyFinalizedError
  | InvalidPhaseTransitionError
  | SetupValidationFailedError
>;
```

---

## 3. State Machine — Pre-Game Setup

> **Why this state machine, not the IGOUGO loop:** `economy.md §E.5` states there
> is no in-game economy. The IGOUGO turn loop (with `TurnPhase`, `UnitStaminaState`,
> `actionsRemaining`, etc.) is fully owned by `TECHNICAL_SPEC_units_entities.md §10`
> and has zero economy events. Modelling it here would duplicate that spec and
> invent rules absent from the source. The only economy-relevant state machine is
> the pre-game setup flow.

### 3.1 Phase Union

```typescript
/** Re-exported from §1.1 for convenience. */
type PreGameSetupPhase =
  | 'Idle'
  | 'DoctrineSelected'
  | 'Composing'
  | 'Finalized';
```

### 3.2 Events

```typescript
/** All events the setup state machine accepts. */
type SetupEvent =
  | { readonly kind: 'SelectDoctrine';   readonly doctrine: DoctrineType; readonly freeRoster: readonly UnitId[] }
  | { readonly kind: 'BeginComposition' } // synthetic: emitted internally after SelectDoctrine
  | { readonly kind: 'PurchaseUnit';      readonly unitType: UnitType; readonly newUnitId: UnitId }
  | { readonly kind: 'RefundUnit';        readonly purchaseId: string }
  | { readonly kind: 'PurchaseXp';        readonly unitId: UnitId; readonly targetRank: Rank }
  | { readonly kind: 'RefundXp';          readonly purchaseId: string }
  | { readonly kind: 'PurchaseEntrench';  readonly unitId: UnitId }
  | { readonly kind: 'PurchaseFormation'; readonly unitIdA: UnitId; readonly unitIdB: UnitId }
  | { readonly kind: 'RefundSpawnBonus';  readonly purchaseId: string }
  | { readonly kind: 'Reset' }
  | { readonly kind: 'Finalize' };
```

### 3.3 Transition Table

The machine is encoded as the `TurnStateMachine` record below. Each entry
documents entry conditions, valid exit events, economy effects on entry/exit,
and the error class thrown when a forbidden event is dispatched.

```typescript
interface PhaseRules {
  /** Conditions that must hold for the setup to be in this phase. */
  readonly entryInvariants: readonly string[];

  /** Events accepted in this phase, mapped to the resulting next phase. */
  readonly transitions: Readonly<Record<SetupEvent['kind'], PreGameSetupPhase | 'reject'>>;

  /** Side effects applied when the machine ENTERS this phase. */
  readonly onEntry: readonly string[];

  /** Side effects applied when the machine EXITS this phase. */
  readonly onExit: readonly string[];

  /** Error class thrown when an event maps to 'reject' in this phase. */
  readonly rejectionError: typeof InvalidPhaseTransitionError;
}

/** The complete state machine. */
const TurnStateMachine: Readonly<Record<PreGameSetupPhase, PhaseRules>> = {
  Idle: {
    entryInvariants: [
      'doctrine === null',
      'profile === null',
      'unitPurchases.length === 0',
      'xpPurchases.length === 0',
      'spawnBonusPurchases.length === 0',
    ],
    transitions: {
      SelectDoctrine:    'DoctrineSelected',
      BeginComposition:  'reject',
      PurchaseUnit:      'reject',
      RefundUnit:        'reject',
      PurchaseXp:        'reject',
      RefundXp:          'reject',
      PurchaseEntrench:  'reject',
      PurchaseFormation: 'reject',
      RefundSpawnBonus:  'reject',
      Reset:             'Idle', // no-op idempotent
      Finalize:          'reject',
    },
    onEntry: ['(none — Idle is the initial state)'],
    onExit:  ['(none)'],
    rejectionError: InvalidPhaseTransitionError,
  },

  DoctrineSelected: {
    entryInvariants: [
      'doctrine !== null',
      'profile !== null and profile.doctrine === doctrine',
      'unitPurchases.length === 0',
      'xpPurchases.length === 0',
      'spawnBonusPurchases.length === 0',
      'freeRoster has been bound from the doctrine pack',
    ],
    transitions: {
      SelectDoctrine:    'reject',                 // must Reset first
      BeginComposition:  'Composing',              // synthetic — auto-fired
      PurchaseUnit:      'reject',                 // wait for BeginComposition
      RefundUnit:        'reject',
      PurchaseXp:        'reject',
      RefundXp:          'reject',
      PurchaseEntrench:  'reject',
      PurchaseFormation: 'reject',
      RefundSpawnBonus:  'reject',
      Reset:             'Idle',
      Finalize:          'reject',
    },
    onEntry: [
      'profile := DOCTRINE_PROFILES[doctrine]',
      'freeRoster := caller-supplied IDs from units spec §8.3/§8.4/§8.5',
      'nextPurchaseSeq := 0',
    ],
    onExit: ['(none — transient phase)'],
    rejectionError: InvalidPhaseTransitionError,
  },

  Composing: {
    entryInvariants: [
      'doctrine !== null',
      'profile !== null',
      'totalSpent(setup) ≤ profile.warPointBudget',  // never overspends mid-edit
    ],
    transitions: {
      SelectDoctrine:    'reject',                 // must Reset first
      BeginComposition:  'reject',                 // already here
      PurchaseUnit:      'Composing',
      RefundUnit:        'Composing',
      PurchaseXp:        'Composing',
      RefundXp:          'Composing',
      PurchaseEntrench:  'Composing',
      PurchaseFormation: 'Composing',
      RefundSpawnBonus:  'Composing',
      Reset:             'Idle',
      Finalize:          'Finalized',              // only if validateSetup() passes
    },
    onEntry: ['(none — entered from DoctrineSelected without state changes)'],
    onExit:  [
      'On exit to Finalized: pointsForfeit := profile.warPointBudget − totalSpent(setup)',
      'On exit to Idle (Reset): all purchase lists cleared, profile := null, doctrine := null',
    ],
    rejectionError: InvalidPhaseTransitionError,
  },

  Finalized: {
    entryInvariants: [
      'validateSetup(setup) returned []',
      'a FinalizedRoster has been produced',
      'pointsForfeit = profile.warPointBudget − totalSpent(setup)',
    ],
    transitions: {
      SelectDoctrine:    'reject',
      BeginComposition:  'reject',
      PurchaseUnit:      'reject',
      RefundUnit:        'reject',
      PurchaseXp:        'reject',
      RefundXp:          'reject',
      PurchaseEntrench:  'reject',
      PurchaseFormation: 'reject',
      RefundSpawnBonus:  'reject',
      Reset:             'reject',                 // finalize is irreversible
      Finalize:          'reject',                 // already finalized
    },
    onEntry: [
      'Materialise XpPurchases into RosterEntry.rank',
      'Materialise SpawnBonusPurchases into RosterEntry.startsEntrenched and FinalizedRoster.formationPairs',
      'Hand control to in-game: TurnPhase.PreGame → TurnPhase.PlayerTurnStart(0) (see units spec §10)',
    ],
    onExit: ['(none — terminal phase)'],
    rejectionError: SetupAlreadyFinalizedError,    // distinct from the others
  },
};
```

### 3.4 Transition Function

```typescript
/**
 * Applies a SetupEvent to the current setup, dispatching to the correct
 * function from §2 and returning the new state — OR an error if the event
 * is not legal in the current phase.
 *
 * The transition function is the SINGLE entry point for state-machine
 * progression. Direct calls to purchaseUnit / purchaseXpUpgrade / etc. are
 * permitted, but transitionPhase() is the canonical wrapper that also
 * enforces the phase rules in TurnStateMachine.
 *
 * @param setup - Current setup state.
 * @param event - Event to apply.
 * @returns Updated setup on success.
 * @throws InvalidPhaseTransitionError if TurnStateMachine[setup.phase].transitions[event.kind] === 'reject'
 *         (or SetupAlreadyFinalizedError when rejection occurs in 'Finalized').
 * @throws Whatever the dispatched §2 function throws (BudgetExceededError, etc.).
 * @sideEffects Returns a new state object; does not mutate `setup`.
 */
declare function transitionPhase(
  setup: PreGameSetupState,
  event: SetupEvent,
): Result<PreGameSetupState, EconomyError>;
```

### 3.5 Forbidden-Action Cheat Sheet

| Phase                | Forbidden events                                                 | Error thrown                       |
|---|---|---|
| `Idle`               | every event except `SelectDoctrine` and `Reset`                  | `InvalidPhaseTransitionError`      |
| `DoctrineSelected`   | every event except `BeginComposition` and `Reset`                | `InvalidPhaseTransitionError`      |
| `Composing`          | `SelectDoctrine`, `BeginComposition`                             | `InvalidPhaseTransitionError`      |
| `Finalized`          | every event                                                      | `SetupAlreadyFinalizedError`       |

### 3.6 Integration With In-Game Turn Loop

`economy.md §E.5` is explicit: there are no per-turn economy events. The in-game
IGOUGO turn loop (`TurnPhase` enum and `applyAction` in `TECHNICAL_SPEC_units_entities.md §10`)
operates with **no economy state**. Once `finalizeSetup()` produces a `FinalizedRoster`,
the economy module's role ends for the rest of the match.

The handoff is one-way: the in-game system's `TurnPhase.PreGame → TurnPhase.PlayerTurnStart(0)`
transition consumes `FinalizedRoster.units` (mapping each `RosterEntry` into a `UnitState`
with `rank`, `startsEntrenched`-derived `TrenchState`, etc.) and `FinalizedRoster.formationPairs`
(materialising formation links per units spec §5). After that, `pointsForfeit` is
preserved only as audit metadata; no in-game function reads it.

---

## 4. Constants & Configuration

```typescript
/**
 * The single authoritative configuration object for the entire economy module.
 * Every numeric value here traces directly to a row in `economy.md`.
 *
 * IMPORTANT: economy.md §E.4 contains a stale phrase referring to "the same
 * 20-point budget" — this predates the v0.16 per-doctrine budget update
 * (Plain 30 / SF 35 / Blitzkrieg 25). The correct semantic is "the same
 * SHARED budget for the doctrine"; the "20" figure is no longer canonical.
 * WAR_POINT_BUDGETS below reflects v0.16, NOT the stale §E.4 sentence.
 */
const ECONOMY_CONFIG = {
  /** §E.1 — per-doctrine starting war-point budget. */
  WAR_POINT_BUDGETS: {
    plain:               30,
    superior_firepower:  35,
    blitzkrieg:          25,
  } as const satisfies Record<DoctrineType, number>,

  /** §E.2 — cost per additional unit purchased. Keyed by UnitType. */
  UNIT_COSTS: {
    infantry:        3,
    cavalry:         3,
    tank:            5,
    motorised_inf:   5,
    artillery:       5,
  } as const satisfies Record<UnitType, number>,

  /**
   * §E.3 — cost to buy a unit UP TO the keyed rank (single-level, NOT cumulative).
   * Recruit (rank 0) is omitted because there is no "buy to Recruit" operation.
   * Cumulative totals: Corporal 2, Captain 6, Colonel 11.
   * The 2 → 4 → 5 progression is irregular by design (§E.3).
   */
  XP_COSTS: {
    1: 2,  // Rank.Corporal
    2: 4,  // Rank.Captain
    3: 5,  // Rank.Colonel
  } as const satisfies Record<Exclude<Rank, Rank.Recruit>, number>,

  /** §E.4 — flat costs for spawn-state bonuses. No doctrine-specific override. */
  SPAWN_BONUS_COSTS: {
    entrenched: 3,
    formation:  5,
  } as const satisfies Record<SpawnBonusType, number>,

  /**
   * §E.2 — per-doctrine ceilings on additional units bought, by category.
   * 0 means no purchases allowed in this category for this doctrine.
   * The caps deliberately exceed what the budget can fund — the player must choose.
   */
  UNIT_PURCHASE_CAPS: {
    plain: {
      heavy:         5,
      lightInfantry: 5,
      lightCavalry:  5,
      special:       5,
    },
    blitzkrieg: {
      heavy:         0,   // by design — Blitzkrieg starts with 6 tanks + 4 motorised
      lightInfantry: 4,
      lightCavalry:  2,
      special:       2,
    },
    superior_firepower: {
      heavy:         2,
      lightInfantry: 2,
      lightCavalry:  2,
      special:       2,
    },
  } as const satisfies Record<DoctrineType, Record<PurchaseCategory, number>>,

  /**
   * §E.3 — per-doctrine XP-upgrade caps.
   * - maxRank = Rank.Recruit means "0× (no upgrades allowed)" (v0.16 — replaces stale "—" rows).
   * - maxUpgradedUnits = null means "no per-category count limit" (Plain only).
   */
  XP_UPGRADE_CAPS: {
    plain: {
      heavy:         { maxRank: 2 /* Captain */, maxUpgradedUnits: null }, // Plain caps at Captain, unlimited per-category
      lightInfantry: { maxRank: 2,                maxUpgradedUnits: null },
      lightCavalry:  { maxRank: 2,                maxUpgradedUnits: null },
      special:       { maxRank: 2,                maxUpgradedUnits: null },
    },
    blitzkrieg: {
      heavy:         { maxRank: 3 /* Colonel */, maxUpgradedUnits: 1  }, // "up to 1×"
      lightInfantry: { maxRank: 3,                maxUpgradedUnits: 2  }, // "up to 2×"
      lightCavalry:  { maxRank: 0 /* Recruit */, maxUpgradedUnits: 0  }, // 0× — no upgrades
      special:       { maxRank: 0,                maxUpgradedUnits: 0  }, // 0× — no upgrades
    },
    superior_firepower: {
      heavy:         { maxRank: 0,                maxUpgradedUnits: 0  }, // 0× — SF heavy locked
      lightInfantry: { maxRank: 3,                maxUpgradedUnits: 3  }, // "up to 3×"
      lightCavalry:  { maxRank: 3,                maxUpgradedUnits: 3  }, // "up to 3×"
      special:       { maxRank: 3,                maxUpgradedUnits: 1  }, // "up to 1×"
    },
  } as const satisfies Record<DoctrineType, Record<PurchaseCategory, DoctrineXpCap>>,
} as const;

/**
 * Doctrine profiles are derived from ECONOMY_CONFIG and consumed by selectDoctrine().
 * Pre-built for O(1) lookup at runtime.
 */
const DOCTRINE_PROFILES: Readonly<Record<DoctrineType, DoctrineEconomyProfile>> = {
  plain: {
    doctrine:          'plain' as DoctrineType,
    warPointBudget:    ECONOMY_CONFIG.WAR_POINT_BUDGETS.plain,
    unitPurchaseCaps:  ECONOMY_CONFIG.UNIT_PURCHASE_CAPS.plain,
    xpUpgradeCaps:     ECONOMY_CONFIG.XP_UPGRADE_CAPS.plain,
  },
  blitzkrieg: {
    doctrine:          'blitzkrieg' as DoctrineType,
    warPointBudget:    ECONOMY_CONFIG.WAR_POINT_BUDGETS.blitzkrieg,
    unitPurchaseCaps:  ECONOMY_CONFIG.UNIT_PURCHASE_CAPS.blitzkrieg,
    xpUpgradeCaps:     ECONOMY_CONFIG.XP_UPGRADE_CAPS.blitzkrieg,
  },
  superior_firepower: {
    doctrine:          'superior_firepower' as DoctrineType,
    warPointBudget:    ECONOMY_CONFIG.WAR_POINT_BUDGETS.superior_firepower,
    unitPurchaseCaps:  ECONOMY_CONFIG.UNIT_PURCHASE_CAPS.superior_firepower,
    xpUpgradeCaps:     ECONOMY_CONFIG.XP_UPGRADE_CAPS.superior_firepower,
  },
};
```

---

## 5. Integration Notes

- **Units spec (`TECHNICAL_SPEC_units_entities.md`):** Imports `UnitType`, `DoctrineType`,
  `Rank`, `UnitId`, `PlayerIndex`, `Facing`, `GridPos`, and `UnitState`. The free
  starting army supplied to `selectDoctrine()` originates from §8.3 / §8.4 / §8.5 of
  that spec. After `finalizeSetup()`, each `RosterEntry` is consumed to populate a
  `UnitState` with `rank` (from `XpPurchase` materialisation) and stamina reset by
  `resetStaminaForPlayer()` at `TurnPhase.PlayerTurnStart`.

- **Combat spec (`TECHNICAL_SPEC_combat.md`):** `RosterEntry.startsEntrenched === true`
  is the only path that bypasses the 3-turn trench timer in `combat.md §5.6` — the
  in-game system must materialise this as a pre-populated `TrenchState` on the unit's
  starting tile. Spawn-entrench eligibility is gated by combat invariant 4.7 ("Heavy
  classes never trench") — Artillery is also excluded per the trench-advancement
  filter in the units spec. Formation pairs from `FinalizedRoster.formationPairs`
  feed the formation system in units spec §5.

- **No in-game economy hooks:** The in-game IGOUGO loop in
  `TECHNICAL_SPEC_units_entities.md §10` (`TurnPhase`, `applyAction`, `applyEndTurn`,
  `UnitStaminaState`) executes WITHOUT any economy callbacks. Per-unit stamina
  (`actionsRemaining`) is a unit/turn concept, not an economy concept; it is owned
  entirely by that spec. This module exposes no functions for in-game use.

- **Naming-convention reconciliation:** `TECHNICAL_SPEC_units_entities.md` uses
  `enum UnitType { ..., MotorisedInf = "motorised_inf", ... }`. `TECHNICAL_SPEC_combat.md`
  uses string-literal types and the spelling `motorized_infantry`. **This spec follows
  the units-spec spelling (`motorised_inf`)** because that spec is the canonical authority
  for unit identity and the `UnitId` lifecycle starts there. Any future combat-spec edit
  should align with this spelling.

- **Single shared pre-game menu (UI, deferred):** `economy.md §E.5` flags that the
  pre-game UI (the menu surfacing budget, caps, validation errors, placement, etc.)
  is still TBD and lives in `ui_and_feedback.md`. This spec defines the data + state
  contract the UI binds to; UI flow rules are out of scope.

---

## 6. Cross-Reference Index

| Rule (source) | Source citation             | Computable location in this spec       |
|---|---|---|
| Per-doctrine budgets               | `economy.md §E.1`        | `ECONOMY_CONFIG.WAR_POINT_BUDGETS`        |
| Unit costs by class                | `economy.md §E.2`        | `ECONOMY_CONFIG.UNIT_COSTS`               |
| Doctrine unit-purchase caps        | `economy.md §E.2`        | `ECONOMY_CONFIG.UNIT_PURCHASE_CAPS`       |
| XP cost progression (2/4/5)        | `economy.md §E.3`        | `ECONOMY_CONFIG.XP_COSTS`                 |
| Doctrine XP-upgrade caps           | `economy.md §E.3`        | `ECONOMY_CONFIG.XP_UPGRADE_CAPS`          |
| Plain's "no per-class count limit" | `economy.md §E.3`        | `DoctrineXpCap.maxUpgradedUnits = null`   |
| "—" rows resolved as 0×            | `economy.md §E.3` (v0.16)| `maxRank: Rank.Recruit, maxUpgradedUnits: 0` |
| Spawn-entrench cost + eligibility  | `economy.md §E.4`        | `purchaseSpawnEntrenched()`, `canSpawnEntrenched()` |
| Spawn-formation cost + eligibility | `economy.md §E.4`        | `purchaseSpawnFormation()`, `canFormFormation()` |
| Leftover points forfeit            | `economy.md §E.5`        | `FinalizedRoster.pointsForfeit` (set on entry to `Finalized`) |
| No in-game economy                 | `economy.md §E.5`        | §3.6 Integration with in-game loop        |
| 3-turn trench-timer bypass         | `combat.md §5.6`         | `RosterEntry.startsEntrenched`            |
| Heavy/Artillery cannot trench      | `combat.md` invariant 4.7 + units spec §10.4 trench filter | `canSpawnEntrenched()` |
| Formation requires light units     | `units_and_entities.md §4` + `economy.md §E.4` | `canFormFormation()`            |
| In-game turn loop (no economy)     | `game_core.md §1.6`      | → `TECHNICAL_SPEC_units_entities.md §10`  |
| Pre-game menu UI (deferred)        | `economy.md §E.5`        | → `ui_and_feedback.md` (out of scope here) |

---

*End of `TECHNICAL_SPEC_economy.md`. Translated faithfully from `economy.md`
(v0.16/v0.18). No rules invented; cross-spec types imported from
`TECHNICAL_SPEC_units_entities.md`.*
