# TECHNICAL_SPEC — Units & Entities
> Translated from `units_and_entities.md` (v0.18, base ruleset closed).
> Source-of-truth prose lives in `units_and_entities.md`; this file is
> the computable contract derived from it. If they conflict, update this
> file and note the discrepancy.
>
> **Scope:** Unit roster, terrain, movement, facing, formation, XP/progression,
> doctrines, and the IGOUGO turn state machine.
> **Out of scope:** Combat resolution (→ `TECHNICAL_SPEC_combat.md`),
> economy / pre-game setup (→ `TECHNICAL_SPEC_economy.md`).

---

## 1. Primitive Enums

```typescript
/** The five unit classes in the game. */
enum UnitType {
  Infantry        = "infantry",
  Cavalry         = "cavalry",
  Tank            = "tank",
  MotorisedInf    = "motorised_inf",
  Artillery       = "artillery",
}

/** Four cardinal facings only. No diagonal facing exists. */
enum Facing {
  North = "N",
  South = "S",
  East  = "E",
  West  = "W",
}

/**
 * Eight movement/attack directions on the square grid.
 * Orthogonal = N/S/E/W; Diagonal = NE/NW/SE/SW.
 */
enum Direction {
  N  = "N",
  S  = "S",
  E  = "E",
  W  = "W",
  NE = "NE",
  NW = "NW",
  SE = "SE",
  SW = "SW",
}

/** The four terrain tile types. Every tile is exactly one of these. */
enum TerrainType {
  Grasslands = "grasslands",
  Swamp      = "swamp",
  Forest     = "forest",
  Mountains  = "mountains",
}

/**
 * XP rank tiers. Earned in-game (defeat a stronger enemy)
 * or purchased pre-game via war points.
 * Corporal = 1st level, Captain = 2nd, Colonel = 3rd.
 */
enum Rank {
  Recruit  = 0,   // base — no level bonus
  Corporal = 1,
  Captain  = 2,
  Colonel  = 3,
}

/** The three doctrines available in the base game. */
enum DoctrineType {
  Plain              = "plain",
  Blitzkrieg         = "blitzkrieg",
  SuperiorFirepower  = "superior_firepower",
}
```

---

## 2. Base Unit Stats

### 2.1 Schema

```typescript
/**
 * Immutable base stats for a unit type.
 * These are the *pre-doctrine, pre-XP* values.
 * Effective stats are resolved via getEffectiveStats().
 *
 * Reach is asymmetric for Tanks (4 ortho / 3 diag).
 * All other units use a single uniform value for both directions
 * (stored in reachOrtho; reachDiag === reachOrtho for them).
 */
interface UnitBaseStats {
  type: UnitType;

  // --- HP ---
  hpBase:   1;          // always 1 (the formula is 1 + bonus)
  hpBonus:  number;     // Infantry 3, Cavalry 2, Tank 7, Motorised 5, Artillery 1
  // Derived: hp = hpBase + hpBonus

  // --- Strength / Defense ---
  baseStrength: number; // Infantry 1, Cavalry 0.5, Tank 3, Motorised 2, Artillery 3
  baseDefense:  number; // Infantry 0, Cavalry 1,   Tank 3, Motorised 1, Artillery 0.5

  // --- Movement (squares per turn) ---
  moveOrtho: number;    // orthogonal movement range
  moveDiag:  number;    // diagonal movement range (0 = cannot move diagonally)

  // --- Attack reach (squares) ---
  reachOrtho: number;   // orthogonal attack reach
  reachDiag:  number;   // diagonal attack reach
                        // Tanks: reachOrtho=4, reachDiag=3
                        // All others: reachOrtho === reachDiag

  // --- Metadata ---
  unitClass: "light" | "heavy" | "special";
  // light   = Infantry, Cavalry
  // heavy   = Tank, MotorisedInf
  // special = Artillery
}
```

### 2.2 Data Table

```typescript
const BASE_UNIT_STATS: Record<UnitType, UnitBaseStats> = {
  [UnitType.Infantry]: {
    type:         UnitType.Infantry,
    hpBase:       1,
    hpBonus:      3,       // total HP = 4
    baseStrength: 1,
    baseDefense:  0,
    moveOrtho:    2,
    moveDiag:     1,
    reachOrtho:   1,
    reachDiag:    1,       // 8-side uniform reach
    unitClass:    "light",
  },

  [UnitType.Cavalry]: {
    type:         UnitType.Cavalry,
    hpBase:       1,
    hpBonus:      2,       // total HP = 3
    baseStrength: 0.5,
    baseDefense:  1,
    moveOrtho:    2,
    moveDiag:     2,       // moves equally in all 8 directions
    reachOrtho:   2,
    reachDiag:    2,       // 8-side uniform reach
    unitClass:    "light",
  },

  [UnitType.Tank]: {
    type:         UnitType.Tank,
    hpBase:       1,
    hpBonus:      7,       // total HP = 8
    baseStrength: 3,
    baseDefense:  3,
    moveOrtho:    3,       // base (overridable by doctrine; see §3)
    moveDiag:     0,       // tanks cannot move diagonally (base)
    reachOrtho:   4,       // ASYMMETRIC — longest ortho lines
    reachDiag:    3,       // ASYMMETRIC — shorter diagonals
    unitClass:    "heavy",
  },

  [UnitType.MotorisedInf]: {
    type:         UnitType.MotorisedInf,
    hpBase:       1,
    hpBonus:      5,       // total HP = 6
    baseStrength: 2,
    baseDefense:  1,
    moveOrtho:    3,
    moveDiag:     2,
    reachOrtho:   3,
    reachDiag:    3,       // 8-side uniform reach
    unitClass:    "heavy",
  },

  [UnitType.Artillery]: {
    type:         UnitType.Artillery,
    hpBase:       1,
    hpBonus:      1,       // total HP = 2
    baseStrength: 3,
    baseDefense:  0.5,
    moveOrtho:    1,
    moveDiag:     1,
    reachOrtho:   6,       // base reach — overridable by Superior Firepower
    reachDiag:    6,       // diagonal fire IS allowed (8-side)
    unitClass:    "special",
  },
};

/** Convenience: compute maximum HP for a unit type. */
function maxHp(type: UnitType): number {
  const s = BASE_UNIT_STATS[type];
  return s.hpBase + s.hpBonus;
}
```

### 2.3 Movement Footprint (derived)

```typescript
/**
 * Returns all grid positions reachable by the unit in one turn,
 * given a jump-based movement model (intermediate tiles do NOT block).
 * Result includes only positions that are within the movement range
 * for each direction — does NOT filter by terrain or occupancy.
 * Call isMoveLegal() after to apply terrain + occupancy checks.
 *
 * @param origin   Current position of the unit.
 * @param stats    Effective stats (post-doctrine, post-XP).
 */
function getMovementFootprint(
  origin: GridPos,
  stats:  EffectiveUnitStats,
): GridPos[] {
  const result: GridPos[] = [];
  for (const dir of ORTHOGONAL_DIRS) {
    for (let d = 1; d <= stats.moveOrtho; d++) {
      result.push(step(origin, dir, d));
    }
  }
  for (const dir of DIAGONAL_DIRS) {
    for (let d = 1; d <= stats.moveDiag; d++) {
      result.push(step(origin, dir, d));
    }
  }
  return result;  // deduplicated by caller if needed
}

/**
 * Returns all grid positions the unit can attack from its current position.
 * Uses reachOrtho for N/S/E/W directions, reachDiag for diagonals.
 * The origin tile itself is excluded.
 *
 * Key note: Tanks have reachOrtho=4, reachDiag=3 — the only asymmetric unit.
 */
function getAttackReachFootprint(
  origin: GridPos,
  stats:  EffectiveUnitStats,
): GridPos[] {
  const result: GridPos[] = [];
  for (const dir of ORTHOGONAL_DIRS) {
    for (let d = 1; d <= stats.reachOrtho; d++) {
      result.push(step(origin, dir, d));
    }
  }
  for (const dir of DIAGONAL_DIRS) {
    for (let d = 1; d <= stats.reachDiag; d++) {
      result.push(step(origin, dir, d));
    }
  }
  return result;
}
```

---

## 3. Terrain Types

### 3.1 Schema

```typescript
/**
 * Per-unit terrain modifiers for a given terrain type.
 * `null` means the unit CANNOT enter this terrain.
 */
interface TerrainUnitModifier {
  canEnter:           boolean;
  movePenaltyOrtho:   number;   // subtracted from effective moveOrtho
  movePenaltyDiag:    number;   // subtracted from effective moveDiag
  defenseBonus:       number;   // added to effective defense while standing here
  canTrench:          boolean;  // only Infantry/Cavalry can trench at all

  /**
   * Special override: if set, the unit's movement is *replaced* (not modified)
   * by these values when entering this terrain.
   * Currently only used for Artillery in swamp.
   */
  movementOverride?: {
    moveOrtho: number;
    moveDiag:  number;
  };
}

/** Full terrain modifiers, keyed by TerrainType then UnitType. */
type TerrainTable = Record<TerrainType, Record<UnitType, TerrainUnitModifier>>;
```

### 3.2 Data Table

```typescript
const TERRAIN_MODIFIERS: TerrainTable = {

  [TerrainType.Grasslands]: {
    // Default tile — no modifiers for any unit.
    [UnitType.Infantry]:     { canEnter: true, movePenaltyOrtho: 0, movePenaltyDiag: 0, defenseBonus: 0,   canTrench: true  },
    [UnitType.Cavalry]:      { canEnter: true, movePenaltyOrtho: 0, movePenaltyDiag: 0, defenseBonus: 0,   canTrench: true  },
    [UnitType.Tank]:         { canEnter: true, movePenaltyOrtho: 0, movePenaltyDiag: 0, defenseBonus: 0,   canTrench: false },
    [UnitType.MotorisedInf]: { canEnter: true, movePenaltyOrtho: 0, movePenaltyDiag: 0, defenseBonus: 0,   canTrench: false },
    [UnitType.Artillery]:    { canEnter: true, movePenaltyOrtho: 0, movePenaltyDiag: 0, defenseBonus: 0,   canTrench: false },
  },

  [TerrainType.Swamp]: {
    // Infantry/Cavalry: −1 move, +1 def, no trench.
    // Artillery: movement REPLACED by "1 square in any of 8 directions" (effectively neutralised).
    // Tank/Motorised: no movement penalty, +0.5 def.
    [UnitType.Infantry]:     { canEnter: true, movePenaltyOrtho: 1, movePenaltyDiag: 1, defenseBonus: 1,   canTrench: false },
    [UnitType.Cavalry]:      { canEnter: true, movePenaltyOrtho: 1, movePenaltyDiag: 1, defenseBonus: 1,   canTrench: false },
    [UnitType.Tank]:         { canEnter: true, movePenaltyOrtho: 0, movePenaltyDiag: 0, defenseBonus: 0.5, canTrench: false },
    [UnitType.MotorisedInf]: { canEnter: true, movePenaltyOrtho: 0, movePenaltyDiag: 0, defenseBonus: 0.5, canTrench: false },
    [UnitType.Artillery]:    {
      canEnter: true,
      movePenaltyOrtho: 0,   // penalty irrelevant — override takes precedence
      movePenaltyDiag:  0,
      defenseBonus:     1,
      canTrench:        false,
      movementOverride: { moveOrtho: 1, moveDiag: 1 },  // replaces base movement entirely
    },
  },

  [TerrainType.Forest]: {
    // Infantry/Cavalry/Tank/Motorised: −1 move, +1.5 def.
    // Artillery: CANNOT ENTER. Artillery may only move on grasslands.
    // Infantry/Cavalry can trench; others cannot.
    [UnitType.Infantry]:     { canEnter: true,  movePenaltyOrtho: 1, movePenaltyDiag: 1, defenseBonus: 1.5, canTrench: true  },
    [UnitType.Cavalry]:      { canEnter: true,  movePenaltyOrtho: 1, movePenaltyDiag: 1, defenseBonus: 1.5, canTrench: true  },
    [UnitType.Tank]:         { canEnter: true,  movePenaltyOrtho: 1, movePenaltyDiag: 0, defenseBonus: 1.5, canTrench: false },
    //  Note: Tank base moveDiag=0; penalty on diag is irrelevant but recorded as 0 for consistency.
    [UnitType.MotorisedInf]: { canEnter: true,  movePenaltyOrtho: 1, movePenaltyDiag: 1, defenseBonus: 1.5, canTrench: false },
    [UnitType.Artillery]:    { canEnter: false, movePenaltyOrtho: 0, movePenaltyDiag: 0, defenseBonus: 0,   canTrench: false },
  },

  [TerrainType.Mountains]: {
    // Only Infantry and Cavalry can climb mountains.
    // +2 def; trench allowed. No movement penalty noted (movement is simply legal/illegal).
    [UnitType.Infantry]:     { canEnter: true,  movePenaltyOrtho: 0, movePenaltyDiag: 0, defenseBonus: 2, canTrench: true  },
    [UnitType.Cavalry]:      { canEnter: true,  movePenaltyOrtho: 0, movePenaltyDiag: 0, defenseBonus: 2, canTrench: true  },
    [UnitType.Tank]:         { canEnter: false, movePenaltyOrtho: 0, movePenaltyDiag: 0, defenseBonus: 0, canTrench: false },
    [UnitType.MotorisedInf]: { canEnter: false, movePenaltyOrtho: 0, movePenaltyDiag: 0, defenseBonus: 0, canTrench: false },
    [UnitType.Artillery]:    { canEnter: false, movePenaltyOrtho: 0, movePenaltyDiag: 0, defenseBonus: 0, canTrench: false },
  },
};
```

### 3.3 Movement Legality Function

```typescript
/**
 * Returns true if the unit may move from `origin` to `destination`.
 *
 * Rules (all must be satisfied):
 *  1. `destination` is inside the unit's effective movement footprint.
 *  2. The unit type can enter the destination terrain.
 *  3. The destination is not occupied by another unit
 *     (exception: the unit's own formation partner — see §4).
 *  4. Jump-based movement: intermediate tiles are NOT checked.
 */
function isMoveLegal(
  unit:        UnitState,
  destination: GridPos,
  board:       BoardState,
): boolean {
  const stats   = getEffectiveStats(unit, board.doctrine[unit.owner]);
  const terrain = board.getTerrain(destination);
  const modifiers = TERRAIN_MODIFIERS[terrain][unit.type];

  // Rule 2: terrain entry
  if (!modifiers.canEnter) return false;

  // Rule 1: inside movement footprint (accounting for terrain penalty)
  const effectiveMoveOrtho = modifiers.movementOverride
    ? modifiers.movementOverride.moveOrtho
    : Math.max(0, stats.moveOrtho - modifiers.movePenaltyOrtho);
  const effectiveMoveDiag = modifiers.movementOverride
    ? modifiers.movementOverride.moveDiag
    : Math.max(0, stats.moveDiag - modifiers.movePenaltyDiag);

  const dir      = directionTo(unit.pos, destination);
  const distance = chebyshevDistance(unit.pos, destination);  // same-axis distance
  const isOrtho  = isOrthogonalDirection(dir);

  if (isOrtho  && distance > effectiveMoveOrtho) return false;
  if (!isOrtho && distance > effectiveMoveDiag)  return false;

  // Rule 3: occupancy
  const occupant = board.getUnit(destination);
  if (occupant && !isFormationPartner(unit, occupant)) return false;

  return true;
}
```

---

## 4. Facing System

### 4.1 Schema

```typescript
/**
 * Which zone a direction falls into relative to a unit's facing.
 * Used for positional combat modifiers (see combat spec).
 */
type AttackZone = "front" | "side" | "rear";

/**
 * 3/2/3 split: Front (3 tiles) / Side (2 tiles) / Rear (3 tiles).
 * For a unit facing North:
 *   Front = N, NW, NE
 *   Side  = E, W
 *   Rear  = S, SW, SE
 *
 * The 1/2/2/2/1 finer split was considered and NOT adopted (v0.18).
 */
const FACING_ZONE_MAP: Record<Facing, Record<Direction, AttackZone>> = {
  [Facing.North]: {
    [Direction.N]:  "front",
    [Direction.NW]: "front",
    [Direction.NE]: "front",
    [Direction.E]:  "side",
    [Direction.W]:  "side",
    [Direction.S]:  "rear",
    [Direction.SW]: "rear",
    [Direction.SE]: "rear",
  },
  [Facing.South]: {
    [Direction.S]:  "front",
    [Direction.SW]: "front",
    [Direction.SE]: "front",
    [Direction.E]:  "side",
    [Direction.W]:  "side",
    [Direction.N]:  "rear",
    [Direction.NW]: "rear",
    [Direction.NE]: "rear",
  },
  [Facing.East]: {
    [Direction.E]:  "front",
    [Direction.NE]: "front",
    [Direction.SE]: "front",
    [Direction.N]:  "side",
    [Direction.S]:  "side",
    [Direction.W]:  "rear",
    [Direction.NW]: "rear",
    [Direction.SW]: "rear",
  },
  [Facing.West]: {
    [Direction.W]:  "front",
    [Direction.NW]: "front",
    [Direction.SW]: "front",
    [Direction.N]:  "side",
    [Direction.S]:  "side",
    [Direction.E]:  "rear",
    [Direction.NE]: "rear",
    [Direction.SE]: "rear",
  },
};
```

### 4.2 Facing Functions

```typescript
/**
 * Returns the attack zone that `attackerPos` falls into
 * relative to the defender's current facing.
 *
 * @param defenderFacing  Defender's current facing direction.
 * @param attackerPos     Grid position of the attacker.
 * @param defenderPos     Grid position of the defender.
 */
function getAttackZone(
  defenderFacing: Facing,
  attackerPos:    GridPos,
  defenderPos:    GridPos,
): AttackZone {
  const dir = directionFrom(defenderPos, attackerPos); // direction FROM defender TO attacker
  return FACING_ZONE_MAP[defenderFacing][dir];
}

/**
 * Rotate a unit. Rotation is:
 *   - Free (costs 0 actions).
 *   - Allowed at any point during the owning player's turn.
 *   - Allowed multiple times in a single turn.
 *   - Allowed pre-game.
 *   - Per-unit in a formation (rotating one does NOT rotate the other).
 *   - NOT reactive — being attacked does not trigger a rotation.
 *
 * @returns New facing for the unit.
 */
function rotateTo(unit: UnitState, newFacing: Facing): UnitState {
  return { ...unit, facing: newFacing };
}

/**
 * Returns the default facing for a unit at spawn.
 * Both sides face each other — toward the opposing player's board half.
 *
 * @param owner    Player index (0 or 1).
 * @param board    BoardState used to determine which half is "opposing".
 */
function defaultSpawnFacing(owner: PlayerIndex, board: BoardState): Facing {
  // Player 0 spawns in the top half → faces South (toward player 1's half).
  // Player 1 spawns in the bottom half → faces North (toward player 0's half).
  // Exact mapping depends on board layout; the rule is "face the opponent's half."
  return owner === 0 ? Facing.South : Facing.North;
}
```

---

## 5. Formation

### 5.1 Schema

```typescript
/**
 * Represents a formation — two light units stacked on the same tile.
 * Heavy units (Tank, MotorisedInf, Artillery) CANNOT form formations.
 *
 * Restrictions:
 *   - Infantry can only pair with Infantry or Cavalry.
 *   - Two Cavalry units can form together (not explicitly forbidden).
 *
 * Properties while in formation:
 *   - IMMOBILE: the formation cannot move.
 *   - Cannot counter-attack together.
 *   - Immune to double-attack bonus.
 *   - Combined defense: sum of both units' effective defense.
 *   - Each unit keeps its own independent facing.
 *
 * Pre-game: two light units may spawn already in formation (5 war points).
 */
interface FormationState {
  unitA: UnitId;
  unitB: UnitId;
  pos:   GridPos;
  // Facings are stored per-unit on each UnitState, not here.
}
```

### 5.2 Formation Functions

```typescript
/**
 * Returns true if the two units are allowed to form a formation together.
 *
 * Rules:
 *   - Both units must be light class (Infantry or Cavalry).
 *   - Infantry can only pair with Infantry or Cavalry.
 *   - Tanks, MotorisedInf, Artillery: cannot participate.
 *   - Both units must be owned by the same player.
 *   - Both units must be on the same tile (or moving to the same tile).
 */
function canForm(unitA: UnitState, unitB: UnitState): boolean {
  const lightTypes = new Set<UnitType>([UnitType.Infantry, UnitType.Cavalry]);
  if (!lightTypes.has(unitA.type)) return false;
  if (!lightTypes.has(unitB.type)) return false;
  if (unitA.owner !== unitB.owner) return false;
  // Infantry can only pair with Infantry or Cavalry — both are in lightTypes,
  // so no additional restriction beyond the above.
  return true;
}

/**
 * Returns the combined defense of a formation for incoming attacks.
 * = effectiveDefense(unitA) + effectiveDefense(unitB)
 *
 * Note: the trench bonus (if applicable) is applied once to each unit
 * individually via their effective defense, then summed here.
 */
function formationCombinedDefense(
  unitA:   UnitState,
  unitB:   UnitState,
  context: CombatContext,
): number {
  return getEffectiveDefense(unitA, context) + getEffectiveDefense(unitB, context);
}

/**
 * A formation is immune to the +1 str double-attack bonus.
 * This flag is checked by the combat resolver before applying that bonus.
 */
function isFormation(unit: UnitState, board: BoardState): boolean {
  return board.formations.some(
    f => f.unitA === unit.id || f.unitB === unit.id
  );
}
```

---

## 6. Trench State (Tile-Level)

> **Critical architecture note:** Trench is a *tile property*, NOT a unit
> property. A trench can outlive its original digger and be occupied by other
> Infantry/Cavalry units. Modeling it as a unit property is the wrong design.

### 6.1 Schema

```typescript
/** Three escalation tiers. */
type TrenchTier =
  | "nascent"    // unit has been still 1–2 turns; no bonus yet
  | "active"     // still 3+ turns; full bonus active (Infantry +2, Cavalry +1.5)
  | "persistent" // still 4+ turns total — survives unit departure as re-occupiable trench
  | "permanent"; // 6 turns total — locked at +1 for rest of game (reduced, final)

/**
 * A trench on a specific tile.
 * Exists independently of any specific unit.
 */
interface TrenchState {
  pos:            GridPos;
  tier:           TrenchTier;
  stillTurnCount: number;     // cumulative turns the *current* occupant has held this position
  occupantId:     UnitId | null; // null if no unit currently in the trench
}

/** Defense bonuses granted by active trenches. */
const TRENCH_DEFENSE_BONUS: Record<UnitType, Record<"active" | "permanent", number>> = {
  [UnitType.Infantry]:     { active: 2,   permanent: 1 },
  [UnitType.Cavalry]:      { active: 1.5, permanent: 1 },
  // Heavy units and artillery cannot use trenches.
  [UnitType.Tank]:         { active: 0,   permanent: 0 },
  [UnitType.MotorisedInf]: { active: 0,   permanent: 0 },
  [UnitType.Artillery]:    { active: 0,   permanent: 0 },
};
```

### 6.2 Trench Functions

```typescript
/**
 * Called at the end of every turn for each Infantry/Cavalry unit
 * that has NOT moved this turn. Increments the still counter and
 * advances the trench tier.
 *
 * Trench cannot form on Swamp tiles (returns trench unchanged).
 */
function advanceTrench(trench: TrenchState, terrain: TerrainType): TrenchState {
  if (terrain === TerrainType.Swamp) return trench; // blocked on swamp

  const newCount = trench.stillTurnCount + 1;

  let newTier: TrenchTier = trench.tier;
  if      (newCount >= 6) newTier = "permanent";
  else if (newCount >= 4) newTier = "persistent";
  else if (newCount >= 3) newTier = "active";
  else                    newTier = "nascent";

  return { ...trench, stillTurnCount: newCount, tier: newTier };
}

/**
 * Called when the unit occupying a trench moves away.
 * Returns the tile's new trench state (may be null if trench disappears).
 *
 * Escalation on departure:
 *  stillTurnCount < 4 (nascent/active): trench disappears immediately → return null.
 *  stillTurnCount >= 4 (persistent): trench remains as a board feature (occupantId = null).
 *  tier === "permanent": trench remains permanently at +1 (occupantId = null).
 */
function unitLeftTrench(trench: TrenchState): TrenchState | null {
  if (trench.stillTurnCount < 4) {
    return null; // vanishes immediately
  }
  // Persistent or permanent: trench stays, resets occupant and counter.
  return {
    ...trench,
    occupantId:     null,
    stillTurnCount: 0,   // counter resets for any future occupant
    // tier stays "persistent" or "permanent" — new occupant starts fresh timer
  };
}

/**
 * Called when a new Infantry/Cavalry unit moves onto a tile that has
 * a persistent trench (occupantId === null, tier === "persistent").
 * The unit can immediately benefit from the existing trench bonus.
 * The counter restarts from 0 for the new occupant.
 */
function unitEnteredTrench(trench: TrenchState, unitId: UnitId): TrenchState {
  return {
    ...trench,
    occupantId:     unitId,
    stillTurnCount: 0, // fresh counter; the persistent trench is still active
  };
}

/**
 * Returns the defense bonus for a unit standing in this trench.
 * Returns 0 if the unit type cannot use trenches, or if the trench
 * is not yet active (nascent tier).
 */
function getTrenchDefenseBonus(trench: TrenchState, unitType: UnitType): number {
  if (trench.tier === "nascent") return 0;
  if (trench.tier === "permanent") {
    return TRENCH_DEFENSE_BONUS[unitType].permanent;
  }
  // active or persistent
  return TRENCH_DEFENSE_BONUS[unitType].active;
}
```

---

## 7. Experience & Progression

### 7.1 Schemas

```typescript
/**
 * A single level-up bonus entry in a progression table.
 * Some bonuses come with drawbacks tracked in UnitStaminaState.
 */
interface ProgressionEntry {
  rank:        Rank;           // which rank grants this bonus
  description: string;         // human-readable summary
  statDelta: Partial<{         // permanent stat changes on level-up
    strength:  number;
    defense:   number;
    hp:        number;
    moveOrtho: number;
    moveDiag:  number;
    reachOrtho:number;
    reachDiag: number;
  }>;
  hasDrawback: boolean;        // if true, see drawback logic in stamina section
}
```

### 7.2 Progression Tables

```typescript
// ─── Infantry ────────────────────────────────────────────────────────────────
const INFANTRY_PROGRESSION: ProgressionEntry[] = [
  {
    rank: Rank.Corporal,
    description: "+1 strength, +1 defense",
    statDelta:   { strength: 1, defense: 1 },
    hasDrawback: false,
    // Cumulative after Corporal: str 2, def 1
  },
  {
    rank: Rank.Captain,
    description: "+1 hp, +1 defense",
    statDelta:   { hp: 1, defense: 1 },
    hasDrawback: false,
    // Cumulative after Captain: str 2, HP 5, def 2
  },
  {
    rank: Rank.Colonel,
    description: "+1 strength, +1 defense",
    statDelta:   { strength: 1, defense: 1 },
    hasDrawback: false,
    // Cumulative after Colonel: str 3, HP 5, def 3
  },
];

// ─── Cavalry ─────────────────────────────────────────────────────────────────
const CAVALRY_PROGRESSION: ProgressionEntry[] = [
  {
    rank: Rank.Corporal,
    description: "+1 strength, +1 defense",
    statDelta:   { strength: 1, defense: 1 },
    hasDrawback: false,
    // Cumulative after Corporal: str 1.5, def 2
  },
  {
    rank: Rank.Captain,
    description: "+1 defense, +2 movement in every direction",
    statDelta:   { defense: 1, moveOrtho: 2, moveDiag: 2 },
    hasDrawback: false,
    // Cumulative after Captain: str 1.5, def 3, moveOrtho 4, moveDiag 4
  },
  {
    rank: Rank.Colonel,
    description: "+1 strength, +1 defense",
    statDelta:   { strength: 1, defense: 1 },
    hasDrawback: false,
    // Cumulative after Colonel: str 2.5, def 4, moveOrtho 4, moveDiag 4
  },
];

// ─── Tank / Motorised Infantry (shared table) ─────────────────────────────────
// Bonuses here are OPTIONAL per-turn activations, not permanent stat changes.
// The drawback details are handled in the IGOUGO stamina state machine (§9).
const TANK_MOTORISED_PROGRESSION: ProgressionEntry[] = [
  {
    rank: Rank.Corporal,
    description: "+1 square orthogonal movement (optional; activating costs -1 atk stamina THIS turn and no-move NEXT turn)",
    statDelta:   {},         // not a permanent stat change; optional per-turn bonus
    hasDrawback: true,
    // Under Blitzkrieg: activating also causes an extra -1 defense (see doctrine modifiers).
  },
  {
    rank: Rank.Captain,
    description: "+1 attack stamina (optional; activating means no-attack NEXT turn; movement unaffected)",
    statDelta:   {},         // optional per-turn bonus, not permanent
    hasDrawback: true,
  },
  {
    rank: Rank.Colonel,
    description: "Wait 1 turn → +2 defense the following turn",
    statDelta:   {},         // conditional, per-turn
    hasDrawback: true,
    // Under Blitzkrieg: net +1 def on wait-turn (still-penalty −1 offsets one);
    // then immediately −2 def the turn after (bonus expires, penalty continues).
  },
];

// ─── Artillery ───────────────────────────────────────────────────────────────
const ARTILLERY_PROGRESSION: ProgressionEntry[] = [
  {
    rank: Rank.Corporal,
    description: "+1 attack reach (no drawback). Stacks with Superior Firepower: falloff shifts 8→9, max range 12→13.",
    statDelta:   { reachOrtho: 1, reachDiag: 1 },
    hasDrawback: false,
  },
  {
    rank: Rank.Captain,
    description: "+2 strength when target is within 5 squares (close-range spike only).",
    statDelta:   {},         // conditional — applied in combat resolver, not as a flat stat change
    hasDrawback: false,
  },
  {
    rank: Rank.Colonel,
    description: "+1 orthogonal movement",
    statDelta:   { moveOrtho: 1 },
    hasDrawback: false,
  },
];

const PROGRESSION_TABLES: Record<UnitType, ProgressionEntry[]> = {
  [UnitType.Infantry]:     INFANTRY_PROGRESSION,
  [UnitType.Cavalry]:      CAVALRY_PROGRESSION,
  [UnitType.Tank]:         TANK_MOTORISED_PROGRESSION,
  [UnitType.MotorisedInf]: TANK_MOTORISED_PROGRESSION,
  [UnitType.Artillery]:    ARTILLERY_PROGRESSION,
};
```

### 7.3 XP Gain

```typescript
/**
 * Returns true if defeating `defeated` grants an XP level to `attacker`.
 *
 * A defeated unit is "stronger" if ANY of the three criteria hold:
 *   1. It has a higher rank than the attacker.
 *   2. Its total strength (without drawbacks) exceeds the attacker's.
 *   3. It was benefiting from doctrine modifiers at the time of combat.
 *
 * Note: "without drawbacks" means base strength + XP stat deltas,
 * excluding Blitzkrieg still-penalty or Tank/Motorised optional-bonus costs.
 */
function grantsXp(attacker: UnitState, defeated: UnitState, ctx: CombatContext): boolean {
  if (defeated.rank > attacker.rank) return true;

  const attackerStrength = getBaseStrengthWithXp(attacker);
  const defeatedStrength = getBaseStrengthWithXp(defeated);
  if (defeatedStrength > attackerStrength) return true;

  if (ctx.defeatedHadDoctrineModifierActive) return true;

  return false;
}

/**
 * Returns total strength (base + XP progression deltas) without any
 * combat-context drawbacks (still-penalties, etc.).
 */
function getBaseStrengthWithXp(unit: UnitState): number {
  const base = BASE_UNIT_STATS[unit.type].baseStrength;
  let delta = 0;
  for (const entry of PROGRESSION_TABLES[unit.type]) {
    if (unit.rank >= entry.rank && entry.statDelta.strength) {
      delta += entry.statDelta.strength;
    }
  }
  return base + delta;
}

/**
 * Applies a rank-up to the unit.
 * Only applies permanent stat changes (hasDrawback=false entries).
 * Drawback-based level bonuses are handled at action time.
 *
 * @returns Updated UnitState with new rank and any permanent stat deltas applied.
 */
function applyRankUp(unit: UnitState, newRank: Rank): UnitState {
  const entry = PROGRESSION_TABLES[unit.type].find(e => e.rank === newRank);
  if (!entry || entry.hasDrawback) return { ...unit, rank: newRank };

  return {
    ...unit,
    rank: newRank,
    currentHp:   unit.currentHp + (entry.statDelta.hp ?? 0),
    // Permanent stat deltas are folded into EffectiveUnitStats via getEffectiveStats().
    // UnitState itself stores only the rank; stats are derived at resolution time.
  };
}
```

---

## 8. Doctrines

### 8.1 Schemas

```typescript
/**
 * A doctrine is a package of:
 *   1. Free starting army composition.
 *   2. War-point budget and per-class point-buy caps.
 *   3. Signature rules that override or add to base rules.
 *
 * Overrides in this record REPLACE base unit stats — they do not stack.
 * getEffectiveStats() applies these overrides after base stat lookup.
 */
interface DoctrineStatOverride {
  moveOrtho?: number;
  moveDiag?:  number;
  reachOrtho?:number;
  reachDiag?: number;
  // Add more fields as new doctrines introduce them.
}

interface DoctrinePack {
  type: DoctrineType;

  // --- Economy ---
  warPointBudget: number;

  // --- Free starting army ---
  startingArmy: Partial<Record<UnitType, number>>;

  // --- Point-buy caps (additional units) ---
  additionalUnitCaps: Partial<Record<UnitType, number>>;

  // --- XP upgrade caps (how many units of each class may be pre-upgraded) ---
  // Value = max number of units of that type that may receive pre-game XP upgrades.
  // 0 = no upgrades allowed for that type.
  xpUpgradeCaps: Partial<Record<UnitType, number>>;

  // --- Max XP level purchasable pre-game per class ---
  // Plain restricts to Rank.Captain (2nd level) pre-game; Colonel must be earned in-game.
  maxPreGameRank: Partial<Record<UnitType, Rank>>;

  // --- Unit stat overrides ---
  // Keyed by UnitType; values REPLACE base stats (not add to them).
  unitStatOverrides: Partial<Record<UnitType, DoctrineStatOverride>>;

  // --- Signature rules (boolean flags; resolved in their respective modules) ---
  hasBlitzkriegStillPenalty: boolean;    // tanks accrue −1 def/still turn
  hasSuperiorFirepowerRange: boolean;    // artillery gets extended range with falloff
}
```

### 8.2 Doctrine Data

```typescript
const DOCTRINE_PACKS: Record<DoctrineType, DoctrinePack> = {

  // ─── Plain ─────────────────────────────────────────────────────────────────
  [DoctrineType.Plain]: {
    type: DoctrineType.Plain,
    warPointBudget: 30,

    // 14 units total, player-chosen — up to 5 per class.
    // Starting army is empty here; the player fills it at pre-game setup.
    startingArmy:       {},
    additionalUnitCaps: {
      [UnitType.Infantry]:     5,
      [UnitType.Cavalry]:      5,
      [UnitType.Tank]:         5,
      [UnitType.MotorisedInf]: 5,
      [UnitType.Artillery]:    5,
    },
    xpUpgradeCaps: {
      // No per-class count limit (only budget and maxPreGameRank constrain).
      // Represented as a large sentinel; enforce via maxPreGameRank instead.
      [UnitType.Infantry]:     99,
      [UnitType.Cavalry]:      99,
      [UnitType.Tank]:         99,
      [UnitType.MotorisedInf]: 99,
      [UnitType.Artillery]:    99,
    },
    maxPreGameRank: {
      // ALL classes capped at Captain (2nd level). Colonel must be earned in-game.
      [UnitType.Infantry]:     Rank.Captain,
      [UnitType.Cavalry]:      Rank.Captain,
      [UnitType.Tank]:         Rank.Captain,
      [UnitType.MotorisedInf]: Rank.Captain,
      [UnitType.Artillery]:    Rank.Captain,
    },
    unitStatOverrides: {
      // Plain tanks: 2 ortho / 0 diag (slower than base 3 ortho).
      [UnitType.Tank]: { moveOrtho: 2, moveDiag: 0 },
    },
    hasBlitzkriegStillPenalty: false,
    hasSuperiorFirepowerRange: false,
  },

  // ─── Blitzkrieg ────────────────────────────────────────────────────────────
  [DoctrineType.Blitzkrieg]: {
    type: DoctrineType.Blitzkrieg,
    warPointBudget: 25,

    startingArmy: {
      [UnitType.Tank]:         6,
      [UnitType.MotorisedInf]: 4,
      [UnitType.Infantry]:     4,
    },
    additionalUnitCaps: {
      [UnitType.Tank]:         0,  // 0 heavy — already stacked with free tanks
      [UnitType.Infantry]:     4,
      [UnitType.Cavalry]:      2,
      [UnitType.Artillery]:    2,
    },
    xpUpgradeCaps: {
      [UnitType.Infantry]:     2,
      [UnitType.Cavalry]:      0,  // no cavalry XP upgrades allowed
      [UnitType.Tank]:         1,
      [UnitType.MotorisedInf]: 1,  // shares heavy class rule
      [UnitType.Artillery]:    0,  // no artillery XP upgrades allowed
    },
    maxPreGameRank: {
      // Not separately specified — budget is the constraint.
      // (Blitzkrieg can buy XP up to any rank for eligible classes,
      //  subject to xpUpgradeCaps and budget.)
    },
    unitStatOverrides: {
      // Blitzkrieg tanks: 4 ortho / 0 diag (faster than base).
      [UnitType.Tank]: { moveOrtho: 4, moveDiag: 0 },
    },
    hasBlitzkriegStillPenalty: true,   // core signature rule
    hasSuperiorFirepowerRange: false,
  },

  // ─── Superior Firepower ────────────────────────────────────────────────────
  [DoctrineType.SuperiorFirepower]: {
    type: DoctrineType.SuperiorFirepower,
    warPointBudget: 35,

    startingArmy: {
      [UnitType.Artillery]: 6,
      [UnitType.Cavalry]:   4,
      [UnitType.Infantry]:  4,
    },
    additionalUnitCaps: {
      [UnitType.Tank]:         2,
      [UnitType.MotorisedInf]: 2,
      [UnitType.Infantry]:     2,
      [UnitType.Cavalry]:      2,
      [UnitType.Artillery]:    2,
    },
    xpUpgradeCaps: {
      [UnitType.Infantry]:     3,
      [UnitType.Cavalry]:      3,
      [UnitType.Tank]:         0,  // 0× — no heavy XP upgrades
      [UnitType.MotorisedInf]: 0,
      [UnitType.Artillery]:    1,
    },
    maxPreGameRank: {},
    unitStatOverrides: {
      // SF tanks: 2 ortho / 1 diag — slower but can move diagonally.
      [UnitType.Tank]: { moveOrtho: 2, moveDiag: 1 },
    },
    hasBlitzkriegStillPenalty: false,
    hasSuperiorFirepowerRange: true,   // core signature rule
  },
};
```

### 8.3 Effective Stats Resolution

```typescript
/**
 * Computes effective stats for a unit given its doctrine and XP rank.
 * This is the single authoritative function for resolving what a unit
 * can actually do. Called once per combat resolution, movement check, etc.
 *
 * Layering order:
 *   1. Base stats from BASE_UNIT_STATS.
 *   2. Doctrine stat overrides (REPLACE, not add to base stats).
 *   3. XP progression permanent stat deltas (added on top of doctrine stats).
 *
 * Important: Blitzkrieg still-penalty and Tank/Motorised optional-bonus
 * drawbacks are NOT folded in here — they are applied in the combat
 * resolver and stamina state machine respectively.
 */
function getEffectiveStats(unit: UnitState, doctrine: DoctrinePack): EffectiveUnitStats {
  const base    = BASE_UNIT_STATS[unit.type];
  const override = doctrine.unitStatOverrides[unit.type] ?? {};

  // Step 1 + 2: base overridden by doctrine.
  let stats: EffectiveUnitStats = {
    type:        base.type,
    hp:          base.hpBase + base.hpBonus,
    strength:    base.baseStrength,
    defense:     base.baseDefense,
    moveOrtho:   override.moveOrtho   ?? base.moveOrtho,
    moveDiag:    override.moveDiag    ?? base.moveDiag,
    reachOrtho:  override.reachOrtho  ?? base.reachOrtho,
    reachDiag:   override.reachDiag   ?? base.reachDiag,
    unitClass:   base.unitClass,
    rank:        unit.rank,
  };

  // Step 3: XP permanent stat deltas.
  for (const entry of PROGRESSION_TABLES[unit.type]) {
    if (unit.rank >= entry.rank && !entry.hasDrawback) {
      stats.hp        += entry.statDelta.hp        ?? 0;
      stats.strength  += entry.statDelta.strength  ?? 0;
      stats.defense   += entry.statDelta.defense   ?? 0;
      stats.moveOrtho += entry.statDelta.moveOrtho ?? 0;
      stats.moveDiag  += entry.statDelta.moveDiag  ?? 0;
      stats.reachOrtho+= entry.statDelta.reachOrtho?? 0;
      stats.reachDiag += entry.statDelta.reachDiag ?? 0;
    }
  }

  return stats;
}
```

---

## 9. Runtime Unit State

```typescript
/** Unique identifier for a unit instance. */
type UnitId = string; // e.g. "p0_infantry_3"

/** Player index: 0 or 1. */
type PlayerIndex = 0 | 1;

/** Grid coordinate. */
interface GridPos { row: number; col: number; }

/**
 * Full runtime state of a single unit on the board.
 * All fields here are mutable during the game.
 */
interface UnitState {
  id:        UnitId;
  owner:     PlayerIndex;
  type:      UnitType;
  rank:      Rank;
  pos:       GridPos;
  facing:    Facing;
  currentHp: number;

  // Stamina tracking (resets each turn; see §10 for the state machine).
  stamina: UnitStaminaState;

  // Trench: stored on the tile (BoardState.trenches), not here.
  // UnitState does NOT own the trench.

  // Blitzkrieg still-penalty counter (only relevant for BZ tanks).
  // Counts consecutive turns the unit has not moved.
  blitzkriegStillTurns: number;

  // Tank/Motorised level-2 and level-3 progression drawback tracking.
  nextTurnPenalty: NextTurnPenalty | null;
}

/**
 * Stamina tracking for one unit within a turn.
 * Resets to `{ actionsRemaining: 2, bonusSquareUsed: false, bonusAttackUsed: false }`
 * at the start of the owning player's turn.
 */
interface UnitStaminaState {
  actionsRemaining: number;   // starts at 2; each move or attack costs 1

  // Level-1 Tank/Motorised: the optional +1 ortho bonus square.
  // Using it costs 1 action stamina THIS turn AND sets a next-turn no-move penalty.
  bonusSquareAvailable: boolean; // true if unit is Tank/Motorised at Corporal+
  bonusSquareUsed:      boolean;

  // Level-2 Tank/Motorised: the optional +1 bonus attack.
  // Using it sets a next-turn no-attack penalty (movement unaffected).
  bonusAttackAvailable: boolean; // true if unit is Tank/Motorised at Captain+
  bonusAttackUsed:      boolean;

  // Level-3 Tank/Motorised: the wait-1-turn → +2 def bonus.
  // Activated by explicitly "waiting" this turn; benefit applies next turn.
  waitedForDefenseBonus: boolean;
}

/**
 * Carry-over penalties from this turn into next turn.
 * Set during this turn's action; checked and cleared at the start of next turn.
 */
interface NextTurnPenalty {
  noMove:   boolean;  // Tank/Motorised L1 bonus square was used; may not move next turn.
  noAttack: boolean;  // Tank/Motorised L2 bonus attack was used; may not attack next turn.
}
```

---

## 10. IGOUGO Turn State Machine

> **Rule summary (game_core.md §1.6):**
> - One player takes their full turn, then the other.
> - Each unit gets **2 actions** (move or attack, freely split).
> - Rotation is **free**, **anytime** in your turn (and pre-game), costs 0 actions.
> - Multiple rotations per turn allowed.
> - Counter-attack is NOT part of the active player's turn (handled in combat resolver).

### 10.1 Turn Phase Enum

```typescript
enum TurnPhase {
  PreGame         = "pre_game",        // placement, doctrine, XP, formation, entrenchment
  PlayerTurnStart = "player_turn_start",// begin player N's turn; reset stamina
  UnitAction      = "unit_action",     // player selects a unit and issues an action
  TurnEnd         = "turn_end",        // player passes; post-turn bookkeeping
  GameOver        = "game_over",       // win condition met
}

/** Actions a player can issue during UnitAction phase. */
type PlayerAction =
  | { kind: "move";         unitId: UnitId; destination: GridPos }
  | { kind: "attack";       unitId: UnitId; targetPos: GridPos }
  | { kind: "rotate";       unitId: UnitId; newFacing: Facing }
  | { kind: "useBonusSquare"; unitId: UnitId; destination: GridPos } // Tank/Motorised L1
  | { kind: "useBonusAttack"; unitId: UnitId; targetPos: GridPos }   // Tank/Motorised L2
  | { kind: "waitForDefense"; unitId: UnitId }                       // Tank/Motorised L3
  | { kind: "endTurn" }
```

### 10.2 Turn Loop

```typescript
/**
 * Top-level IGOUGO turn processor.
 * Returns the new game state after applying the action.
 *
 * The state machine is:
 *
 *   PreGame ──(setup complete)──► PlayerTurnStart(0)
 *     │
 *     ▼
 *   PlayerTurnStart(N) ──► UnitAction(N) ◄──────────────────────────┐
 *                            │                                       │
 *                            ├─(move/attack/rotate/bonus action)─────┘
 *                            │                                         (loop until endTurn)
 *                            └─(endTurn)──► TurnEnd(N)
 *                                            │
 *                                            ├─(win condition met)──► GameOver
 *                                            └─(not over)──► PlayerTurnStart(1-N)
 *
 * Rotation is legal at ANY point during UnitAction phase — even after a unit
 * has used both its actions, and even for units the player has already
 * "finished with" this turn. It is not tracked in actionsRemaining.
 */
function applyAction(state: GameState, action: PlayerAction): GameState {
  switch (state.phase) {
    case TurnPhase.UnitAction:
      return applyUnitAction(state, action);
    default:
      throw new Error(`Action ${action.kind} not valid in phase ${state.phase}`);
  }
}

function applyUnitAction(state: GameState, action: PlayerAction): GameState {
  if (action.kind === "endTurn") {
    return applyEndTurn(state);
  }
  if (action.kind === "rotate") {
    // Free — no stamina cost, no restrictions.
    return applyRotate(state, action.unitId, action.newFacing);
  }
  if (action.kind === "move") {
    return applyMove(state, action.unitId, action.destination);
  }
  if (action.kind === "attack") {
    return applyAttack(state, action.unitId, action.targetPos);
  }
  if (action.kind === "useBonusSquare") {
    return applyBonusSquare(state, action.unitId, action.destination);
  }
  if (action.kind === "useBonusAttack") {
    return applyBonusAttack(state, action.unitId, action.targetPos);
  }
  if (action.kind === "waitForDefense") {
    return applyWaitForDefense(state, action.unitId);
  }
  throw new Error(`Unknown action kind: ${(action as any).kind}`);
}
```

### 10.3 Stamina Bookkeeping Functions

```typescript
/**
 * Reset stamina for all units owned by `player` at the start of their turn.
 * Also applies or clears any next-turn penalties from the previous turn.
 */
function resetStaminaForPlayer(state: GameState, player: PlayerIndex): GameState {
  const updatedUnits = state.units.map(unit => {
    if (unit.owner !== player) return unit;

    const penalty = unit.nextTurnPenalty ?? { noMove: false, noAttack: false };

    const freshStamina: UnitStaminaState = {
      actionsRemaining:     2,
      bonusSquareAvailable: unit.type === UnitType.Tank || unit.type === UnitType.MotorisedInf
                              ? unit.rank >= Rank.Corporal : false,
      bonusSquareUsed:      false,
      bonusAttackAvailable: unit.type === UnitType.Tank || unit.type === UnitType.MotorisedInf
                              ? unit.rank >= Rank.Captain : false,
      bonusAttackUsed:      false,
      waitedForDefenseBonus:false,
    };

    return {
      ...unit,
      stamina:         freshStamina,
      nextTurnPenalty: null,
      // Penalties from last turn: if noMove, this unit cannot move this turn.
      // Stored as flags checked in isMoveLegal() and isAttackLegal().
      _noMoveThisTurn:   penalty.noMove,
      _noAttackThisTurn: penalty.noAttack,
    };
  });

  return { ...state, units: updatedUnits };
}

/**
 * Applies a standard move action (costs 1 action stamina).
 *
 * Pre-conditions (all must pass):
 *   - unit.stamina.actionsRemaining >= 1
 *   - !unit._noMoveThisTurn (no L1 bonus-square next-turn penalty pending)
 *   - isMoveLegal(unit, destination, board) === true
 *
 * Post-conditions:
 *   - actionsRemaining decremented by 1.
 *   - unit.pos updated.
 *   - Trench state updated (unitLeftTrench / advanceTrench).
 *   - blitzkriegStillTurns reset to 0 (if Blitzkrieg tank).
 */
function applyMove(state: GameState, unitId: UnitId, destination: GridPos): GameState { /* ... */ }

/**
 * Applies a standard attack action (costs 1 action stamina).
 *
 * Pre-conditions:
 *   - unit.stamina.actionsRemaining >= 1
 *   - !unit._noAttackThisTurn
 *   - isAttackLegal(unit, targetPos, board) === true
 *
 * Post-conditions:
 *   - actionsRemaining decremented by 1.
 *   - Combat resolved via resolveAttack() (→ combat spec).
 *   - If attacker has actionsRemaining === 0 after decrement, defender
 *     gets the bonus counter-attack die (→ combat spec §5.9).
 */
function applyAttack(state: GameState, unitId: UnitId, targetPos: GridPos): GameState { /* ... */ }

/**
 * Applies Tank/Motorised level-1 bonus square move.
 *
 * Stamina rules (v0.18):
 *   THIS TURN:   actionsRemaining decremented by 1 (the cost of activation).
 *   THIS TURN:   unit may still attack if it has remaining actions.
 *   NEXT TURN:   unit cannot move (nextTurnPenalty.noMove = true).
 *
 * Under Blitzkrieg: also applies an extra -1 defense this turn
 * (interacts inversely with the still-penalty; handled in combat resolver).
 *
 * Pre-conditions:
 *   - unit.rank >= Rank.Corporal
 *   - unit.stamina.bonusSquareAvailable && !unit.stamina.bonusSquareUsed
 *   - unit.stamina.actionsRemaining >= 1
 *   - !unit._noMoveThisTurn
 *   - destination is within (effectiveMoveOrtho + 1) orthogonally
 */
function applyBonusSquare(state: GameState, unitId: UnitId, destination: GridPos): GameState {
  const unit = getUnit(state, unitId);
  // Consume 1 action stamina THIS turn.
  const newStamina = {
    ...unit.stamina,
    actionsRemaining: unit.stamina.actionsRemaining - 1,
    bonusSquareUsed:  true,
  };
  // Set next-turn no-move penalty.
  const newPenalty: NextTurnPenalty = {
    noMove:   true,
    noAttack: unit.nextTurnPenalty?.noAttack ?? false,
  };
  // Apply move.
  return moveUnit(state, unitId, destination, newStamina, newPenalty);
}

/**
 * Applies Tank/Motorised level-2 bonus attack.
 *
 * Stamina rules (v0.18):
 *   THIS TURN:   attack resolves normally (no extra this-turn cost).
 *   NEXT TURN:   unit cannot attack (nextTurnPenalty.noAttack = true).
 *   MOVEMENT:    unaffected on either turn.
 *
 * Pre-conditions:
 *   - unit.rank >= Rank.Captain
 *   - unit.stamina.bonusAttackAvailable && !unit.stamina.bonusAttackUsed
 *   - !unit._noAttackThisTurn
 *   - isAttackLegal(unit, targetPos, board) === true
 */
function applyBonusAttack(state: GameState, unitId: UnitId, targetPos: GridPos): GameState {
  const unit = getUnit(state, unitId);
  const newStamina = {
    ...unit.stamina,
    bonusAttackUsed: true,
  };
  const newPenalty: NextTurnPenalty = {
    noMove:   unit.nextTurnPenalty?.noMove ?? false,
    noAttack: true,
  };
  return resolveAndApplyAttack(state, unitId, targetPos, newStamina, newPenalty);
}

/**
 * Applies Tank/Motorised level-3 wait-for-defense.
 * The unit explicitly waits this turn; +2 defense applies NEXT turn.
 *
 * Under Blitzkrieg:
 *   Wait-turn net defense = +2 (L3 bonus) − 1 (still-penalty for this turn) = +1.
 *   The turn after: L3 bonus expires, still-penalty continues to compound → −2 net swing.
 *
 * Pre-conditions:
 *   - unit.rank >= Rank.Colonel
 *   - unit did NOT move this turn (confirmed by caller or tracked via blitzkriegStillTurns)
 */
function applyWaitForDefense(state: GameState, unitId: UnitId): GameState {
  const unit = getUnit(state, unitId);
  const newStamina = {
    ...unit.stamina,
    waitedForDefenseBonus: true,
  };
  return updateUnit(state, { ...unit, stamina: newStamina });
}
```

### 10.4 End-of-Turn Bookkeeping

```typescript
/**
 * Called when the active player issues `endTurn`.
 * Performs all post-turn bookkeeping before switching to the other player.
 *
 * Order of operations:
 *  1. Update blitzkriegStillTurns for all Blitzkrieg tanks owned by this player.
 *     (A tank that did NOT move this turn increments by 1; one that moved resets to 0.)
 *  2. Advance trench timers for all Infantry/Cavalry that did NOT move this turn.
 *  3. Check win conditions (HQ capture, HQ damage threshold, turn limit).
 *  4. Switch active player.
 *  5. Reset stamina for the new active player (resetStaminaForPlayer).
 */
function applyEndTurn(state: GameState): GameState {
  let next = state;
  next = updateBlitzkriegStillPenalties(next);
  next = advanceTrenchTimers(next);
  next = checkWinConditions(next);
  if (next.phase === TurnPhase.GameOver) return next;
  next = switchActivePlayer(next);
  next = resetStaminaForPlayer(next, next.activePlayer);
  return next;
}

/**
 * Updates blitzkriegStillTurns for all Blitzkrieg tanks.
 * A tank with blitzkriegStillTurns > 0 suffers −(stillTurns) defense
 * in combat resolution (handled in combat resolver).
 */
function updateBlitzkriegStillPenalties(state: GameState): GameState {
  const doctrine = state.doctrines; // Record<PlayerIndex, DoctrinePack>
  const updatedUnits = state.units.map(unit => {
    if (unit.type !== UnitType.Tank) return unit;
    if (!doctrine[unit.owner].hasBlitzkriegStillPenalty) return unit;

    const movedThisTurn = unit._movedThisTurn ?? false;
    return {
      ...unit,
      blitzkriegStillTurns: movedThisTurn ? 0 : unit.blitzkriegStillTurns + 1,
      _movedThisTurn: false, // reset for next turn
    };
  });
  return { ...state, units: updatedUnits };
}

/**
 * Advances trench timers for all Infantry/Cavalry that did not move this turn.
 * Checks terrain before advancing (swamp blocks trench).
 */
function advanceTrenchTimers(state: GameState): GameState {
  const player = state.activePlayer;
  let nextBoard = state.board;

  for (const unit of state.units) {
    if (unit.owner !== player) continue;
    if (unit.type !== UnitType.Infantry && unit.type !== UnitType.Cavalry) continue;

    const movedThisTurn = unit._movedThisTurn ?? false;
    if (movedThisTurn) continue; // unit moved — no trench advance

    const terrain = nextBoard.getTerrain(unit.pos);
    const existingTrench = nextBoard.getTrench(unit.pos);

    if (existingTrench) {
      const advanced = advanceTrench(existingTrench, terrain);
      nextBoard = nextBoard.setTrench(unit.pos, advanced);
    } else if (terrain !== TerrainType.Swamp) {
      // First turn of stillness — create a nascent trench.
      const nascent: TrenchState = {
        pos:            unit.pos,
        tier:           "nascent",
        stillTurnCount: 1,
        occupantId:     unit.id,
      };
      nextBoard = nextBoard.setTrench(unit.pos, nascent);
    }
  }

  return { ...state, board: nextBoard };
}
```

### 10.5 Legal Action Generator

```typescript
/**
 * Returns all legal actions for the given player in the current state.
 * This is the function the AI uses to enumerate its options.
 *
 * Always includes `endTurn` as a legal action (a player may end their
 * turn without acting if they choose).
 *
 * Rotation actions for any unit the player owns are ALWAYS legal
 * (free, anytime — including after both actions are spent).
 */
function legalActions(state: GameState, player: PlayerIndex): PlayerAction[] {
  const actions: PlayerAction[] = [{ kind: "endTurn" }];

  for (const unit of state.units) {
    if (unit.owner !== player) continue;

    // Rotations: always legal for any facing the unit isn't already in.
    for (const facing of Object.values(Facing)) {
      if (facing !== unit.facing) {
        actions.push({ kind: "rotate", unitId: unit.id, newFacing: facing as Facing });
      }
    }

    // Moves: requires actionsRemaining >= 1 and no noMove penalty.
    if (unit.stamina.actionsRemaining >= 1 && !unit._noMoveThisTurn) {
      for (const dest of getMovementFootprint(unit.pos, getEffectiveStats(unit, state.doctrines[player]))) {
        if (isMoveLegal(unit, dest, state.board)) {
          actions.push({ kind: "move", unitId: unit.id, destination: dest });
        }
      }
    }

    // Attacks: requires actionsRemaining >= 1 and no noAttack penalty.
    if (unit.stamina.actionsRemaining >= 1 && !unit._noAttackThisTurn) {
      for (const target of getAttackReachFootprint(unit.pos, getEffectiveStats(unit, state.doctrines[player]))) {
        if (isAttackLegal(unit, target, state.board)) {
          actions.push({ kind: "attack", unitId: unit.id, targetPos: target });
        }
      }
    }

    // Bonus square (Tank/Motorised L1).
    if (
      unit.stamina.bonusSquareAvailable &&
      !unit.stamina.bonusSquareUsed &&
      unit.stamina.actionsRemaining >= 1 &&
      !unit._noMoveThisTurn
    ) {
      // Enumerate destinations at (effectiveMoveOrtho + 1) orthogonal range.
      // (Implementation detail: same as move enumeration but +1 ortho range.)
      // ... push bonusSquare actions ...
    }

    // Bonus attack (Tank/Motorised L2).
    if (
      unit.stamina.bonusAttackAvailable &&
      !unit.stamina.bonusAttackUsed &&
      !unit._noAttackThisTurn
    ) {
      // Same target set as normal attacks; different action kind.
      // ... push bonusAttack actions ...
    }

    // Wait for defense (Tank/Motorised L3): legal if unit hasn't moved this turn.
    if (
      unit.rank >= Rank.Colonel &&
      (unit.type === UnitType.Tank || unit.type === UnitType.MotorisedInf) &&
      !unit._movedThisTurn
    ) {
      actions.push({ kind: "waitForDefense", unitId: unit.id });
    }
  }

  return actions;
}
```

---

## 11. Helper Type Aliases & Utilities

```typescript
/** Effective stats after doctrine override + XP progression. */
interface EffectiveUnitStats {
  type:       UnitType;
  hp:         number;
  strength:   number;
  defense:    number;
  moveOrtho:  number;
  moveDiag:   number;
  reachOrtho: number;
  reachDiag:  number;
  unitClass:  "light" | "heavy" | "special";
  rank:       Rank;
}

const ORTHOGONAL_DIRS: Direction[] = [Direction.N, Direction.S, Direction.E, Direction.W];
const DIAGONAL_DIRS:   Direction[] = [Direction.NE, Direction.NW, Direction.SE, Direction.SW];

/** Returns true if the direction is orthogonal (N/S/E/W). */
function isOrthogonalDirection(dir: Direction): boolean {
  return ORTHOGONAL_DIRS.includes(dir);
}

/**
 * Returns the direction from `from` to `to` in 8-direction grid terms.
 * Assumes `to` is reachable from `from` in a single direction.
 */
function directionFrom(from: GridPos, to: GridPos): Direction { /* ... */ }

/**
 * Returns the position that is `distance` steps in `dir` from `origin`.
 */
function step(origin: GridPos, dir: Direction, distance: number): GridPos { /* ... */ }

/**
 * Returns the Chebyshev distance between two positions
 * (max of row-diff and col-diff — same as "steps in 8-direction grid").
 */
function chebyshevDistance(a: GridPos, b: GridPos): number {
  return Math.max(Math.abs(a.row - b.row), Math.abs(a.col - b.col));
}

/** Checks if `unitA` and `unitB` are in the same formation. */
function isFormationPartner(unitA: UnitState, unitB: UnitState): boolean { /* ... */ }
```

---

## 12. Cross-Reference Index

| Rule | Source | Computable location in this spec |
|---|---|---|
| Unit roster + base stats | `units_and_entities.md §2.1` | §2.2 `BASE_UNIT_STATS` |
| Jump-based movement | `units_and_entities.md §2.4` | §3.3 `isMoveLegal()` |
| Terrain modifiers | `units_and_entities.md §2.5` | §3.2 `TERRAIN_MODIFIERS` |
| Trench rules (3-tier escalation) | `units_and_entities.md §2.5.5`, `combat.md §5.6` | §6 |
| Infantry progression | `units_and_entities.md §3.1` | §7.2 `INFANTRY_PROGRESSION` |
| Cavalry progression | `units_and_entities.md §3.2` | §7.2 `CAVALRY_PROGRESSION` |
| Tank/Motorised progression + stamina | `units_and_entities.md §3.2a` | §7.2 + §10.3 |
| Artillery progression | `units_and_entities.md §3.2b` | §7.2 `ARTILLERY_PROGRESSION` |
| XP gain trigger ("stronger enemy") | `units_and_entities.md §3.3` | §7.3 `grantsXp()` |
| Rank naming | `units_and_entities.md §3.4` | `Rank` enum §1 |
| Formation rules | `units_and_entities.md §4` | §5 |
| Facing system (4 facings, 3/2/3 split) | `units_and_entities.md §6` | §4 |
| Rotation timing (free, anytime, multi) | `units_and_entities.md §6.3` | §10.2, `legalActions()` |
| Default spawn facing | `units_and_entities.md §6.1` | §4.2 `defaultSpawnFacing()` |
| Formation per-unit rotation | `units_and_entities.md §4.4` | §4.2 `rotateTo()` |
| Doctrine packages | `units_and_entities.md §8` | §8.2 `DOCTRINE_PACKS` |
| Effective stats resolution | `units_and_entities.md §8.2` | §8.3 `getEffectiveStats()` |
| Blitzkrieg still-penalty | `units_and_entities.md §8.3` | §10.4 `updateBlitzkriegStillPenalties()` |
| SF artillery range override | `units_and_entities.md §8.4` | → `TECHNICAL_SPEC_combat.md §range_falloff` |
| Plain doctrine (vanilla) | `units_and_entities.md §8.5` | §8.2 `DOCTRINE_PACKS[Plain]` |
| IGOUGO 2-action budget | `game_core.md §1.6` | §10 `UnitStaminaState` |
| Turn limit / tiebreak | `game_core.md §1.8` | → `TECHNICAL_SPEC_game_core.md` |

---

*End of TECHNICAL_SPEC_units_entities.md*
*Next specs: `TECHNICAL_SPEC_combat.md` (resolveAttack, positional bonuses, counter-attack, bounce, artillery exemptions) and `TECHNICAL_SPEC_economy.md` (pre-game budget validation).*
