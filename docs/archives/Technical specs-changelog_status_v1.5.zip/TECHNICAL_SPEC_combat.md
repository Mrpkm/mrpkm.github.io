# Strategy Game — Technical Spec (Combat Module) v1.0

> **Source ruleset:** `combat.md` (rules v0.18).
> **Scope of this document:** the **combat module only**. Sibling concerns
> (full unit stat blocks, doctrine signature rules, terrain entry restrictions,
> facing system, economy, win conditions) are referenced as **[external]**
> and will be specified in their own modules. Where combat.md cross-references
> another file, this spec preserves the reference rather than guessing past it.
>
> **What this document is for.** Translate the prose rules of combat into
> computable contracts: typed data records, pure-function signatures with
> pre/post conditions, and the state machine governing IGOUGO turn flow.
> The output should be sufficient to write the engine without re-opening
> `combat.md`, and sufficient to drive `COMBAT_TEST_CASES.md`.

---

## 0. Conventions

- **TypeScript-style records** are used throughout. They are illustrative;
  the implementation may use any equivalent representation (Rust enums,
  Python dataclasses, etc.).
- **Function signatures use `→`** for the return type. Functions are
  marked **pure** (no side effects, deterministic given args) or
  **effectful** (mutates state and/or reads RNG).
- **All combat math uses half-step precision.** `+0.5` and `−0.5` are
  legal modifiers; the engine should not round intermediate values.
- **Half-open ranges** for tile-distance checks (i.e. `range ≤ 8` means
  squares 1–8 inclusive get full-power treatment; square 9 begins
  falloff).

---

## 1. Type definitions

### 1.1 Primitives

```ts
type UnitId = string;                     // stable per match
type TileCoord = { x: number; y: number };

type Direction      = 'N' | 'E' | 'S' | 'W';
type DiagonalDir    = 'NE' | 'SE' | 'SW' | 'NW';
type AnyDirection   = Direction | DiagonalDir;

type AttackDirection = 'frontal' | 'side' | 'rear';

type Doctrine   = 'plain' | 'blitzkrieg' | 'superior_firepower';
type UnitClass  = 'infantry' | 'cavalry' | 'tank' | 'motorized_infantry' | 'artillery';

// Named tiers per units_and_entities.md §3.4 — referenced here
// because §5.9 bounce-rule keys off rank ('Corporal').
type Rank = 'recruit' | 'corporal' | 'captain' | 'colonel';

type TerrainType = 'grasslands' | 'swamp' | 'forest' | 'mountains';
```

### 1.2 Unit state (combat-relevant fields only)

> **[external]** The full unit record (movement footprints, level
> progression, etc.) is defined elsewhere. This spec lists only the
> fields the combat resolver reads or writes.

```ts
interface Unit {
  id: UnitId;
  unitClass: UnitClass;
  doctrine: Doctrine;          // determined at army setup; never changes mid-match
  rank: Rank;                  // current XP tier
  position: TileCoord;
  facing: Direction;           // 4-facing system (N/E/S/W only)

  hp: number;                  // current HP, decremented by damage
  baseStrength: number;        // [external] from unit roster
  baseDefense: number;         // [external] from unit roster

  // Per-turn stamina — see §3 IGOUGO state machine
  attackStaminaRemaining: number;   // resets to attackStaminaMax each turn
  moveStaminaRemaining: number;     // resets to moveStaminaMax each turn
  attackStaminaMax: number;         // base 2; can be modified by progression [external]
  moveStaminaMax: number;           // base 2; can be modified by progression [external]

  // Attack reach (asymmetric for tanks; uniform 8-side for others)
  // [external] sourced from unit roster. Combat reads these to compute
  // valid targets and tank-reach-as-adjacency.
  attackReachOrtho: number;
  attackReachDiag: number;

  // State counters relevant to combat
  turnsSinceLastMove: number;       // drives trench timer + Blitzkrieg still-penalty
  hasMovedThisTurn: boolean;        // for trench timer reset and bounce-rule "unable to move"
}
```

> **Note on `turnsSinceLastMove`.** This single counter feeds two combat
> mechanics: (a) the trench timer (3-turn trigger, §5.6) and (b) the
> Blitzkrieg still-penalty (cumulative −1 def per still turn, §5.3).
> The two mechanics are independent in their *effects* but share their
> *trigger condition* — a single counter is sufficient.

### 1.3 Tile state

```ts
interface Tile {
  coord: TileCoord;
  terrain: TerrainType;
  occupant: UnitId | null;      // null when empty
  trench: TrenchState;
}

type TrenchState =
  | { tier: 'none' }
  | {
      // Active: an Inf/Cav unit has held the tile ≥ 3 turns and is still here.
      tier: 'active';
      occupantId: UnitId;
      turnsHeld: number;        // counts up; ≥ 3 means trench bonus is live
    }
  | {
      // Standing: original occupant exited at ≥ 4 turns held.
      // Trench remains as a tile feature with full modifiers
      // (Inf +2 / Cav +1.5) until either (a) a new Inf/Cav occupant
      // moves on and resets the timer or (b) it is left empty
      // without a new occupant — see §2.5 for the disappear rule.
      tier: 'standing';
      // No occupantId — the trench is an empty tile feature.
    }
  | {
      // Permanent: any occupant held for 6 turns total without moving.
      // Bonuses locked at +1 def for both Inf and Cav, irreversibly.
      tier: 'permanent';
    };
```

> **Important: trench is a tile property, not a unit property.** Modeling
> trench on the unit record is incorrect — the standing tier explicitly
> survives its original occupant.

### 1.4 Board + match state

```ts
interface Board {
  width: number;
  height: number;
  tiles: Tile[][];              // tiles[y][x]
}

interface MatchState {
  board: Board;
  units: Map<UnitId, Unit>;
  turnNumber: number;           // increments after both players have acted
  activePlayer: PlayerId;
  // ... HQ state, win-condition tracking — [external]
}

type PlayerId = 'P1' | 'P2';
```

### 1.5 Combat context and result

```ts
interface AttackContext {
  attackerId: UnitId;
  defenderId: UnitId;
  matchState: MatchState;
  // RNG is injected so combat is deterministic given a seed (testability).
  rng: () => number;            // returns uniform [0, 1)
}

interface DamageResult {
  damage: number;               // final, post-floor (≥ 1 except bounce-rule case)
  rolledD6: number;             // the raw 1d6 (1–6) for replay/debug
  bonusBreakdown: {
    attackerStrengthBonuses: ModifierBreakdown;
    defenderDefenseBonuses: ModifierBreakdown;
  };
  attackDirection: AttackDirection;
  encirclementApplied: boolean;
  wasBounceRule: boolean;       // true only for the Blitzkrieg Corporal-tank exception
  counterAttack: CounterAttackResult | null;
}

interface ModifierBreakdown {
  // Each entry tags the source so UI/debugging can explain "why is this +3.5?"
  entries: { source: string; amount: number }[];
  total: number;
}

interface CounterAttackResult {
  damage: number;
  rolledD6: number;
  bonusD6: number | null;       // null if no exhausted-attacker bonus
  bonusStrength: number;        // 0 if no bonus die; otherwise rolledBonusD6 * 0.5
}
```

---

## 2. Function contracts

All functions in this section are **pure** unless explicitly marked
**effectful**. Pure functions take state as input and return new
values; they never mutate the inputs.

### 2.1 Geometry helpers

```ts
// Compute the attack direction relative to the defender's facing.
// Pure. Total function.
function computeAttackDirection(
  attackerPos: TileCoord,
  defenderPos: TileCoord,
  defenderFacing: Direction
): AttackDirection;
```

**Contract.**
- Maps the relative bearing from defender → attacker into one of three
  arcs based on §6.2 Front/Side/Rear mapping (3/2/3 split, confirmed
  v0.18; finer 1/2/2/2/1 not adopted).
- For a defender facing N: front = {N, NE, NW}, side = {E, W},
  rear = {S, SE, SW}.
- Other facings are rotations of the same arc.
- **Tank reach-as-adjacency:** when the attacker is a tank and the
  defender is not orthogonally adjacent, the *direction* still resolves
  using the angle from tank → defender (the tank is treated as if it
  were sitting at its closest in-reach orthogonal neighbor). This
  matches the §5.10 statement: "the angle from tank to defender
  determines the attack direction relative to the defender's facing,
  exactly as if the tank were adjacent."

```ts
// Chebyshev distance — used for 8-side reach checks.
function chebyshevDistance(a: TileCoord, b: TileCoord): number;

// Manhattan-style ortho distance — used for ortho-reach checks.
// Returns Infinity if a and b are not on the same row or column.
function orthoDistance(a: TileCoord, b: TileCoord): number;

// Returns true iff the two tiles share a row or column (i.e. one of
// N/S/E/W from one to the other).
function isOrthogonal(a: TileCoord, b: TileCoord): boolean;
```

### 2.2 Reach checks

```ts
// Is the defender inside the attacker's attack reach?
// Honors the tank-asymmetric reach (4 ortho / 3 diag).
function isInReach(attacker: Unit, defenderPos: TileCoord): boolean;
```

**Contract.**
- For tanks: returns true if `isOrthogonal(...) && orthoDistance ≤ 4`
  OR `chebyshevDistance ≤ 3` for diagonal cases.
- For all other units: returns true if
  `chebyshevDistance ≤ attackReachOrtho` (which equals
  `attackReachDiag` for non-tanks; the asymmetry is tank-only).

### 2.3 Tactic-applicability gating

```ts
// Whether positional tactics (rear/side/double/encirclement/terrain
// attack-bonus) apply to a given attacker.
// Hard rule per §5.10: artillery returns false; everything else returns true.
function appliesPositionalTactics(unit: Unit): boolean;
```

**Contract.**
- `unit.unitClass === 'artillery'` → returns `false`.
- Otherwise → returns `true`.
- Used as a gate at the top of every modifier-resolving step. If it
  returns `false`, all positional and terrain-attack-bonus modifiers
  are skipped (defense-side terrain bonuses still apply — see §2.7).

### 2.4 Encirclement detection

```ts
// Standard encirclement: are all 4 of the defender's orthogonal
// neighbors occupied by enemies of the defender?
function isStandardEncirclement(
  defender: Unit,
  matchState: MatchState
): boolean;
```

**Contract.**
- All 4 neighbors must exist (within board bounds), be occupied, and
  the occupants must be enemies of the defender.
- Returns `true` only if all four conditions hold for all four tiles.

```ts
// Tank reach-hug encirclement (v0.18 §5.10): are 2+ enemy tanks
// with the defender inside their orthogonal attack reach from
// orthogonal directions?
function isTankReachHugEncirclement(
  defender: Unit,
  matchState: MatchState
): boolean;
```

**Contract.**
- Find all enemy tanks `t` such that `defender.position` is inside
  `t`'s orthogonal attack reach (`isOrthogonal(t.pos, defender.pos)
   && orthoDistance ≤ 4`).
- Returns `true` if there are **2 or more** such tanks.
- **Diagonal-reach tanks do not count** — consistent with the v0.16
  rule that diagonals never contribute to positional tactics (§5.9).

```ts
// Combined check used by the resolver.
function isEncircled(
  defender: Unit,
  matchState: MatchState
): boolean;
//   = isStandardEncirclement(...) || isTankReachHugEncirclement(...)
```

### 2.5 Trench state machine

The trench is the most stateful part of combat. It's a tile-level
state machine driven by the unit's `turnsSinceLastMove` counter and
by movement events.

```ts
// Called at the START of each turn for every Inf/Cav unit standing on
// a tile that doesn't already have an active or permanent trench.
// Pure — returns the next TrenchState; caller writes it back.
function tickTrenchTimer(
  tile: Tile,
  occupant: Unit
): TrenchState;
```

**Contract — transitions.**

| From | Trigger | To | Notes |
|---|---|---|---|
| `none` | occupant Inf/Cav stationary, `turnsSinceLastMove` reaches 3 on tile that isn't swamp | `active(turnsHeld=3)` | Swamp blocks trenching entirely (§5.6). |
| `active(n)` | occupant remains stationary | `active(n+1)` | |
| `active(n), n ≥ 6` | (immediately on hitting 6) | `permanent` | The 6-turn lock; bonuses reduce to +1/+1, irreversible. |
| `active(n), n == 3` and unit moves | `none` | The 3-turn-then-exit "vanish" rule. |
| `active(n), n ≥ 4 && n < 6` and unit moves | `standing` | The 4-turn-then-exit "remains" rule. |
| `standing` | new Inf/Cav occupant moves onto tile and stays | `active(turnsHeld=1)` | Timer resets; new occupant's hold counts from scratch. (The standing trench's bonus still applies during this re-occupation hold — see §2.7.) |
| `standing` | tile remains empty for one full turn cycle | `none` | The "left empty without a new occupant, it disappears" rule (§5.6). **See open question Q1** about exact disappear timing. |
| `permanent` | any | `permanent` | Permanent is terminal. Bonuses locked at +1/+1. |

**Pre-conditions for entry into `active` from `none`:**
1. Occupant's `unitClass` is `infantry` OR `cavalry` (§5.6 — confirmed v0.18).
2. Tile's terrain is **not** `swamp`.
3. Occupant has `turnsSinceLastMove ≥ 3`.

**Effect on movement.** When a unit moves *off* a tile that has a
non-`none` trench, fire `onUnitLeavesTrench(tile, unit, turnsHeld)`
to compute the next state per the table above. When a unit moves *onto*
a tile, it doesn't grant the bonus immediately — the bonus only applies
once the occupant has held the tile for the required duration (or
inherits a `standing` trench, which is bonus-immediately-eligible).

```ts
// Returns the defense bonus from the trench, given the defender's class.
// Used during damage calculation (§2.7).
function trenchDefenseBonus(
  trench: TrenchState,
  defenderClass: UnitClass
): number;
```

**Contract.**
- `tier === 'none'` → 0
- `tier === 'permanent'` → +1 for both Inf and Cav; 0 for everything else
  (permanent trench is locked at +1 regardless of class).
- `tier === 'active'` or `tier === 'standing'`:
  - `infantry` → +2
  - `cavalry`  → +1.5
  - other classes → 0 (heavy units cannot benefit; §5.10).

### 2.6 Range falloff (§5.7)

```ts
// Returns the strength penalty from range falloff.
// Currently used only by Superior Firepower artillery.
function computeRangeFalloff(
  attacker: Unit,
  defenderPos: TileCoord
): number;
```

**Contract.**
- Default: returns `0` (no falloff).
- If `attacker.doctrine === 'superior_firepower' &&
   attacker.unitClass === 'artillery'`:
  - Let `d = chebyshevDistance(attacker.position, defenderPos)`.
  - If `d ≤ 8` → return `0`.
  - If `9 ≤ d ≤ 12` → return `−0.5`.
  - If `d > 12` → attack is illegal; this function should never be
    called in that case (caller validates reach first via §2.2).

### 2.7 Modifier resolution

```ts
// Compute the full attacker-side strength bonus breakdown.
function computeAttackerBonuses(
  attacker: Unit,
  defender: Unit,
  matchState: MatchState
): ModifierBreakdown;
```

**Contract.**

The function gates on `appliesPositionalTactics(attacker)`. When `false`
(artillery), only doctrine effects (e.g. range falloff, level-2
close-range bonus [external]) and the unit's base strength contribute.
Otherwise, sum all of the following entries that apply:

| Source | Amount | Conditions |
|---|---|---|
| Frontal | 0 | direction === 'frontal' |
| Side | +0.5 | direction === 'side' |
| Rear | +1 | direction === 'rear' |
| Double attack | +1 | 2 friendlies orthogonally adjacent to defender (tanks count via reach — see below) |
| Encirclement (orthogonal attacker) | +3 | `isEncircled(defender)` AND attacker is contributing orthogonally; for tanks: attacker tank's reach to defender is orthogonal |
| Encirclement attacked diagonally | 0 | per §5.4: diagonals get nothing. Diagonal contributions to encirclement are always 0. |
| Mountain attack penalty | −1 | attacker stands on mountain tile (§5.2); applies to ALL unit classes — cavalry exemption is removed (v0.15) |
| Forest attack bonus | +1 | attacker stands on forest tile |
| Range falloff | varies | per §2.6 |
| Doctrine effects | varies | [external — applied by `applyDoctrineEffects(...)`] |

**Tank double-attack bookkeeping.** A tank that has the target inside
its orthogonal reach counts as one of the "2 friendlies orthogonally
adjacent" required for the +1 double-attack bonus. Specifically:

- Light/motorized friendly orthogonally adjacent + tank with target
  inside ortho reach → double attack triggers.
- Two tanks each with the target inside ortho reach → double attack
  triggers (and is a sub-case of the 2-tank reach-hug encirclement
  check; both bonuses can apply if all conditions are met).

```ts
// Compute the full defender-side defense bonus breakdown.
function computeDefenderBonuses(
  attacker: Unit,
  defender: Unit,
  attackDirection: AttackDirection,
  matchState: MatchState
): ModifierBreakdown;
```

**Contract.**

| Source | Amount | Conditions |
|---|---|---|
| Frontal | 0 | direction === 'frontal' |
| Side received | −0.5 | direction === 'side' |
| Rear received | −1 | direction === 'rear' |
| Encirclement received (orthogonal) | −2 | `isEncircled(defender)` AND attacker is contributing orthogonally |
| Encirclement received, attacker is diagonal | 0 | diagonals contribute nothing |
| Trench (Inf/Cav) | trenchDefenseBonus(...) | per §2.5 |
| Forest defense bonus | +1.5 | defender stands on forest tile (per units_and_entities.md §2.5; combat.md §5.3 says "+1" for forest defense — **see open question Q2**) |
| Mountain defense bonus | +2 | defender stands on mountains (Inf/Cav only — heavy units cannot enter mountains [external]) |
| Swamp defense bonus | +1 (Inf/Cav) / +0.5 (heavy) | per units_and_entities.md §2.5 — terrain defense always applies, including to artillery (§5.10) |
| Blitzkrieg still-penalty | −1 × turnsSinceLastMove | only if attacker is a Blitzkrieg tank — *wait, this is a defender modifier* — actually only if **defender** is a Blitzkrieg tank (§5.3 entry refers to "Blitzkrieg tanks only" as defenders accruing the penalty). Cumulative; resets to 0 when the tank moves. |
| XP-level defense | varies | [external] subsumed by §3 progression |
| Doctrine effects | varies | [external] |

> **Open issue Q2 flagged above:** combat.md §5.3 lists forest defense
> bonus as `+1`, while units_and_entities.md §2.5.3 says `+1.5`. Since
> we're working from combat.md only, the spec uses **+1** here and
> flags the discrepancy for cross-module reconciliation. Same for
> mountain (`+1` in §5.3 example vs. `+2` in §2.5.4) — this spec uses
> the values from the §5.3 generic table where it gives one, and the
> example values for direct quotes.
>
> *(Resolution path: when the units module spec is written, reconcile.
>  Until then, treat the `+1.5` / `+2` values as the v0.18 canonical
>  numbers since they appear in the more recent §5.10 update.)*

### 2.8 The main resolver

```ts
function resolveAttack(ctx: AttackContext): DamageResult;
```

**Pre-conditions.**
1. `ctx.attacker.attackStaminaRemaining ≥ 1` (caller must validate;
   the resolver does NOT decrement stamina — see §3).
2. `isInReach(attacker, defender.position) === true`.
3. `attacker` and `defender` are enemies of each other.
4. Both units have HP > 0.

**Algorithm (§5.1).**

```
1. attackDirection ← computeAttackDirection(attackerPos, defenderPos, defenderFacing)
2. attackerBonuses ← computeAttackerBonuses(attacker, defender, matchState)
3. rolledD6      ← floor(rng() * 6) + 1
4. defenderBonuses ← computeDefenderBonuses(attacker, defender, attackDirection, matchState)
5. baseDamage   ← rolledD6
                + attacker.baseStrength + attackerBonuses.total
                − defender.baseDefense  − defenderBonuses.total
6. wasBounce    ← isBlitzkriegBounceCase(attacker)
7. damage       ← wasBounce
                  ? max(baseDamage, -3)         // bounce can go to −3
                  : max(baseDamage, 1)          // standard floor at 1
8. apply damage to defender (mutation via caller; resolver returns the result)
9. counterAttack ← (defender alive after step 8)
                   ? resolveCounterAttack(defender, attacker, ctx)
                   : null
10. return DamageResult
```

```ts
// Predicate for the bounce-rule exception.
function isBlitzkriegBounceCase(attacker: Unit): boolean;
//   true iff:
//     attacker.doctrine === 'blitzkrieg'
//     && attacker.unitClass === 'tank'
//     && attacker.rank === 'corporal'
//     && attacker.attackStaminaRemaining === 1
//     && attacker.cannotMoveThisTurn === true
//   ("cannotMoveThisTurn" is computed from move stamina + terrain
//    constraints — [external] needs spec from movement module)
```

> **Floor semantics (§5.1, v0.18).** Final damage is clamped to ≥ 1
> for all attacks except `wasBounceRule === true`, which clamps to ≥ −3.
> A negative damage value does **not** heal the defender — the bounce
> represents the attacker hitting itself. The caller is responsible
> for routing negative damage back to the attacker if a self-damage
> rule is later codified; for now, it surfaces as `damage < 0` in
> the result and the caller decides what to do (this is intentionally
> deferred — combat.md describes the "hits itself in effect" behavior
> as flavor without nailing down the mechanic).

### 2.9 Counter-attack

```ts
function resolveCounterAttack(
  defender: Unit,
  originalAttacker: Unit,
  ctx: AttackContext
): CounterAttackResult | null;
```

**Pre-conditions / branching.**
- If `defender.attackStaminaRemaining === 0` → return `null`. No counter-attack.
- Else: roll 1d6 (regular counter die).
- Additionally, if `originalAttacker.attackStaminaRemaining === 0`
  (the attacker already used all their attacks this turn before
  attacking — §5.9), roll a second bonus d6 and apply +0.5 strength
  per pip:
  - 1 → +0.5 str
  - 2 → +1.0 str
  - …
  - 6 → +3.0 str

**Algorithm.**

```
1. regularRoll ← floor(rng() * 6) + 1
2. bonusRoll   ← (originalAttacker.attackStaminaRemaining === 0)
                  ? floor(rng() * 6) + 1
                  : null
3. bonusStrength ← bonusRoll === null ? 0 : bonusRoll * 0.5
4. counterDamage ← regularRoll
                 + defender.baseStrength + bonusStrength
                 − originalAttacker.baseDefense
   // Note: the counter-attack does NOT apply positional tactics
   // unless explicitly stated — combat.md §5.9 describes counter-attack
   // strictly as "defender D6" + optional bonus. Positional bonuses
   // for the counter (which would now reverse direction since the
   // counter targets the original attacker) are intentionally NOT
   // applied here. **See open question Q3.**
5. counterDamage ← max(counterDamage, 1)  // standard floor
6. apply to originalAttacker
7. return CounterAttackResult
```

**Note on stamina.** The counter-attack consumes one attack-stamina
from the defender. This is enforced by the caller (the turn loop), not
by `resolveCounterAttack` itself. The resolver only checks that
stamina is available before rolling.

---

## 3. IGOUGO state machine

This section codifies how attacks fit into the turn loop. It draws
**only on what combat.md exposes**: §5.1 references "2 of their attack
actions this turn", §5.9 references "attack-stamina remaining", and
the bounce rule references "1 attack stamina". The full action budget
is owned by [external] `game_core.md` §1.6.

### 3.1 States

```ts
type TurnPhase =
  | 'turn_start'        // start-of-turn bookkeeping (timers, doctrine effects)
  | 'awaiting_action'   // active player is choosing what to do
  | 'resolving_action'  // an action (move/attack/rotate) is being applied
  | 'resolving_counter' // post-attack counter-attack is being resolved
  | 'turn_end'          // end-of-turn bookkeeping
  | 'game_over';

interface TurnState {
  phase: TurnPhase;
  activePlayer: PlayerId;
  turnNumber: number;
}
```

### 3.2 Per-unit action budget

```ts
interface UnitActionBudget {
  // Combat.md doesn't define these directly; pulled from §5.1 + §5.9 references.
  // Authoritative source is [external] game_core.md §1.6.
  attackStaminaMax: number;      // base 2 (referenced in §5.1 "both of their attack actions")
  moveStaminaMax: number;        // base 2 — combat.md doesn't reference this directly;
                                 //   inferred from "move OR attack 2 times per turn" cross-ref.

  attackStaminaRemaining: number;
  moveStaminaRemaining: number;

  // The 2 actions are shared: any combination of moves and attacks summing to 2.
  // The "stamina" terms are convenience accessors; a single shared counter
  // would suffice mathematically. We keep them split because:
  //   - the bounce rule keys off attackStamina specifically (§5.9);
  //   - the counter-attack rule keys off whether the *attacker* has
  //     used all attacks vs. some attacks (§5.9 bonus die trigger);
  //   - progression bonuses (level-1 / level-2 — [external]) modify
  //     the two pools differently.
}
```

> **Important nuance from §5.9.** The counter-attack bonus die fires
> when the **attacker** has used **all** their attack-stamina. The
> bounce rule fires when the attacker has **1** attack-stamina remaining
> (i.e. one attack left). These are two different stamina-states and
> the engine must distinguish them.

### 3.3 Transitions

| From | Event | To | Side effects |
|---|---|---|---|
| `turn_start` | (entry) | `awaiting_action` | For each unit owned by activePlayer: refresh stamina to max; tick `turnsSinceLastMove++` for units that did NOT move last turn; tick trench timers (§2.5); apply Blitzkrieg still-penalty refresh; doctrine on-turn-start hooks [external]. |
| `awaiting_action` | player chooses move | `resolving_action` | Validate legality (movement module — [external]). |
| `awaiting_action` | player chooses attack | `resolving_action` | Validate via `resolveAttack` pre-conditions (§2.8). |
| `awaiting_action` | player chooses rotate | `resolving_action` | Free per units_and_entities.md §6.3 [external]; combat module needs only to know that rotation does NOT consume stamina and updates `unit.facing`. |
| `awaiting_action` | player chooses end-turn | `turn_end` | Cleanup. |
| `resolving_action` | move resolved | `awaiting_action` | Decrement moveStamina. Set `unit.hasMovedThisTurn = true`. **Trench-on-leave** trigger fires here (§2.5). Reset `unit.turnsSinceLastMove = 0`. |
| `resolving_action` | attack resolved | `resolving_counter` | Apply DamageResult.damage to defender. If defender dies, skip counter-attack and go to `awaiting_action`. |
| `resolving_action` | rotate resolved | `awaiting_action` | No stamina changes. |
| `resolving_counter` | counter resolved | `awaiting_action` | Decrement defender.attackStamina by 1. Apply CounterAttackResult.damage to original attacker. If attacker dies, the original attack still counted as resolved — no rollback. |
| `turn_end` | (entry) | `awaiting_action` (other player) OR `game_over` | Swap activePlayer; increment turnNumber on the second player's end-of-turn (so a "turn" = both players acting once). Check win conditions [external]. Check 1000-turn cap [external]. |

### 3.4 End-of-turn cleanup (combat-relevant)

For each unit owned by the player who just ended their turn:

1. **Stamina reset** is deferred to `turn_start` of the *next* time
   this unit's owner is active — i.e. between turns the stamina
   counters retain their final state. This matters because the
   counter-attack rule (§5.9 bonus die trigger) inspects the
   attacker's stamina at the moment of attack, which can occur
   on the **defender's** turn if a counter-attack provoked retaliation.
   *(Note: combat.md does not describe a counter-counter-attack;
   counters are non-recursive. This stamina-state preservation matters
   only for cross-turn lookups in edge cases.)*

2. **`hasMovedThisTurn` reset.** At the start of each player's turn,
   reset `hasMovedThisTurn = false` for all of that player's units.
   At the end of the turn, units whose `hasMovedThisTurn === false`
   have their `turnsSinceLastMove` incremented. Units whose
   `hasMovedThisTurn === true` had it reset to 0 already at move time.

3. **Trench timer tick.** Already covered by step 2 — trench timer is
   driven by `turnsSinceLastMove` per §2.5.

4. **Blitzkrieg still-penalty.** Cumulative −1 def per `turnsSinceLastMove`,
   applied at damage-resolution time as a defender modifier (§2.7),
   not stored separately. The counter is the same `turnsSinceLastMove`.

---

## 4. Invariants and edge cases

These are properties the engine must preserve. They double as
property-test seeds for `COMBAT_TEST_CASES.md`.

### 4.1 Damage-floor invariant
For all attacks:
```
damage ≥ 1
  ∨ wasBounceRule === true ∧ damage ≥ −3
```

### 4.2 Artillery exemption invariant
For all `attacker.unitClass === 'artillery'`:
```
attackerBonuses contains NO entries with source ∈ {
  'frontal', 'side', 'rear', 'double_attack', 'encirclement',
  'mountain_attack_penalty', 'forest_attack_bonus'
}
```
Doctrine effects (range falloff, level-2 close-range) and base strength
are still present.

### 4.3 Diagonal-never-counts invariant
For any positional bonus computation:
```
isOrthogonal(attackerPos, defenderPos) === false
  ⟹ encirclement, double-attack, rear, side bonuses all 0
```
The only exception is tank reach, which counts orthogonally only.

### 4.4 Trench is tile-state invariant
A trench's lifetime is **never** tied to a unit's lifetime once it
reaches `standing` or `permanent`. A unit dying or moving never
destroys a `permanent` trench.

### 4.5 Permanent trench is irreversible
Once `tier === 'permanent'`, no transition out of permanent exists.
Permanent's bonuses are locked at +1/+1 forever, regardless of who
re-occupies.

### 4.6 Swamp blocks trenching
For all trench transitions into `active`:
```
tile.terrain ≠ 'swamp'
```
This is a precondition; the timer can run on swamp but never produces
a trench.

### 4.7 Heavy classes never trench
For all trench transitions into `active`:
```
occupant.unitClass ∈ { 'infantry', 'cavalry' }
```
This is enforced *in addition to* the swamp gate.

### 4.8 Encirclement-bonus orthogonality
The encirclement bonus (+3 str / −2 def) only ever applies when the
**attacking unit** is contributing orthogonally to the defender. A
diagonally-positioned attacker, even one that is part of the
encirclement geometry, gets no encirclement bonus.

### 4.9 Counter-attack symmetry
A counter-attack is itself an attack and runs through `resolveAttack`'s
counter-step? **No** — combat.md §5.9 describes counter-attack as a
single defender-side roll, not a recursive attack. A counter-attack
does **not** trigger a counter-counter-attack. Implementation must
prevent recursion explicitly (see Q3 for the deeper question of
positional bonuses on counter-attacks).

### 4.10 Bounce-rule preconditions are conjunctive
All five conditions must be true simultaneously for the bounce rule
to fire. A Blitzkrieg Captain-rank tank, or a Blitzkrieg Corporal
tank with 2 attack-stamina, or a non-tank unit, etc. — none of these
qualify.

---

## 5. Open questions / scope-deferred

These are items that combat.md alone cannot resolve. They block neither
the core resolver implementation nor the test suite, but they should
be triaged before the full engine is finalized.

**Q1 — `standing` trench disappear timing.**
Combat.md §5.6 says: "If at any point the trench is left empty without
a new occupant, it disappears." It's unclear whether "left empty"
means *immediately on the original unit leaving with no replacement*
or *after a grace period*. The current spec assumes one full turn
cycle of emptiness ⇒ disappear. **Resolution needs design call.**

**Q2 — Forest/mountain defense bonus discrepancy.**
- combat.md §5.3 example uses `+1` for forest defense.
- units_and_entities.md §2.5.3 specifies `+1.5`.
- combat.md §5.10 (the v0.18 update) implies the §2.5 values are
  canonical (e.g. "forest +1.5" appears in the artillery defense
  applicability discussion).
The spec defaults to combat.md §5.3's `+1` until reconciled with
the units module. **Cross-module reconciliation needed.**

**Q3 — Positional bonuses on counter-attacks.**
Combat.md §5.9 describes the counter-attack as a flat D6 (+ optional
bonus die). It is silent on whether the counter-attack applies
positional bonuses to the defender (now functioning as attacker)
relative to the original attacker's facing. The current spec opts to
**not** apply positional bonuses to counter-attacks — the counter is
described as a reflexive D6, not a full attack. **Confirm with
design.**

**Q4 — Bounce-rule negative-damage routing.**
Combat.md flavor: "the tank can hit itself in effect." It does not
formalize whether negative damage in fact damages the attacker (or
something else). The spec returns negative damage in the
`DamageResult` and lets the caller decide. **Needs explicit rule.**

**Q5 — Move stamina tracking source.**
Combat.md references attack-stamina but never names a "move stamina"
counter. The spec splits stamina into attack/move pools because
progression bonuses (§3.2a [external]) describe them separately. If
the engine treats action budget as a single shared counter, the
combat module is unaffected — only the bounce-rule predicate's
"unable to move" check needs an alternate formulation. **Pending
unit-progression module spec.**

**Q6 — `cannotMoveThisTurn` predicate.**
The bounce rule's "unable to move" condition is not defined in
combat.md. Plausible formulations:
- `moveStaminaRemaining === 0` (used all moves), OR
- All adjacent tiles are illegal (no legal destination), OR
- Both of the above.
The spec uses "all of the above" placeholder. **Needs movement-module
spec to finalize.**

---

## Appendix A — Cross-reference index

| Concept | Source in combat.md | This spec |
|---|---|---|
| Combat sequence | §5.1 | §2.8 |
| Damage formula | §5.1 | §2.8 step 5 |
| Min damage floor (= 1, with bounce exception) | §5.1, §5.9, §5.10 | §2.8, §4.1 |
| Attacker strength modifiers | §5.2 | §2.7 (computeAttackerBonuses) |
| Defender defense modifiers | §5.3 | §2.7 (computeDefenderBonuses) |
| Net swing table | §5.4 | reproducible from §2.7 outputs |
| Encirclement (default + tank reach-hug) | §5.5, §5.10 | §2.4 |
| Trench rules + escalation | §5.6 | §2.5, §1.3 |
| Range falloff | §5.7 | §2.6 |
| Counter-attack | §5.9 | §2.9 |
| Bounce rule | §5.9 | §2.8 (isBlitzkriegBounceCase) |
| Diagonals never count | §5.9, §5.5 | §4.3 |
| Heavy-unit applicability | §5.10 | §2.3, §4.2 |
| Tank reach-as-adjacency | §5.10 | §2.1 (computeAttackDirection), §2.4, §2.7 |
| Quick reference | §7 | reproducible from this spec |

---

*Living document — translated from combat.md (rules v0.18). Update
when combat.md changes or when reconciliation with sibling specs
resolves the open questions in §5.*
