(function () {
  'use strict';

  function attachSelection(mapRootEl) {
    mapRootEl.addEventListener('click', function(e) {
      let state;
      try { state = window.GameState.getState(); } catch (_) { return; }

      const cellEl = e.target.closest('.cell');
      if (!cellEl) return;

      const row = parseInt(cellEl.dataset.row);
      const col = parseInt(cellEl.dataset.col);

      // Legal-move destination → move the selected unit
      if (state.selectedUnitId) {
        const isLegal = state.legalMoves.some(function(m) { return m.row === row && m.col === col; });
        if (isLegal) {
          window.GameState.moveUnit(state.selectedUnitId, row, col);
          return;
        }
      }

      // Unit element → select or deselect
      const unitEl = e.target.closest('[data-unit-id]');
      if (unitEl) {
        const unitId = unitEl.dataset.unitId;
        if (state.selectedUnitId === unitId) {
          window.GameState.selectUnit(null);
        } else {
          window.GameState.selectUnit(unitId);
          const moves = window.EngineBridge.getLegalMoves(unitId, window.GameState.getState());
          window.GameState.setLegalMoves(moves);
        }
        return;
      }

      // Empty cell → deselect
      if (state.selectedUnitId) window.GameState.selectUnit(null);
    });
  }

  window.Selection = { attachSelection: attachSelection };
})();
