// chromaBridge.js — sprite loader for unit tokens on the core map.
//
// • Tanks & Cavalry use real animated GIFs, decoded once via ImageDecoder, then
//   re-drawn to per-token canvases on every frame with a corner-sampled
//   chroma-key. All tokens of a given type share one frame index so the
//   animation is perfectly synchronised on the board — same pattern as the
//   Map Builder's GIF tokens.
// • Other unit types (Infantry, Motorized, Artillery) use their light PNG
//   icons (transparent already).
// • Per-type "no frames yet" fallback is the light PNG, so the board never
//   shows a blank where a unit should be.
//
// Public API:
//   ChromaBridge.getSprite(unitType) → HTMLElement  (live, animated)

(function () {
  'use strict';

  // Light, always-works icons (transparent PNGs, no chroma needed).
  const LIGHT_SPRITES = {
    Tanks:     '../assets/game-icons/tank.png',
    Cavalry:   '../assets/game-icons/cavalry.png',
    Infantry:  '../assets/game-icons/infantry.png',
    Motorized: '../assets/game-icons/motorized.png',
    Artillery: '../assets/game-icons/artillery.png',
  };

  // Animated GIFs — only the unit types we actually have animations for.
  const ANIMATED_GIFS = {
    Tanks:   '../assets/units/animations/tank/tank-move.gif',
    Cavalry: '../assets/units/animations/cavalry/cavalry-move.gif',
  };

  // Per-type animation registry: { frames: [{image, duration, w, h}], keyColor, frameIdx, tokens:Set<{canvas,size}> }
  const registry = {};
  // Per-type loading promise (so concurrent gets coalesce)
  const loading = {};

  // ── Pure helpers ─────────────────────────────────────────────────────

  function lightImg(src, alt) {
    const img = document.createElement('img');
    img.className = 'unit-img';
    img.alt = alt;
    img.draggable = false;
    img.src = src;
    return img;
  }

  function drawFrameToToken(token, reg) {
    const frame = reg.frames[reg.frameIdx];
    if (!frame || !frame.image) return;
    const ctx = token.ctx;
    const s = token.size;
    ctx.clearRect(0, 0, s, s);
    // Preserve aspect ratio: fit inside the square.
    const fw = frame.w, fh = frame.h;
    const scale = Math.min(s / fw, s / fh);
    const dw = fw * scale, dh = fh * scale;
    const dx = (s - dw) / 2, dy = (s - dh) / 2;
    try { ctx.drawImage(frame.image, dx, dy, dw, dh); } catch (_) { return; }
    // Chroma-key against the sampled corner colour.
    if (reg.keyColor) {
      let id;
      try { id = ctx.getImageData(0, 0, s, s); } catch (_) { return; }
      const d = id.data, { r: kr, g: kg, b: kb } = reg.keyColor;
      const tol = 50;
      for (let i = 0; i < d.length; i += 4) {
        if (Math.abs(d[i] - kr) < tol &&
            Math.abs(d[i + 1] - kg) < tol &&
            Math.abs(d[i + 2] - kb) < tol) d[i + 3] = 0;
      }
      ctx.putImageData(id, 0, 0);
    }
  }

  function tick(unitType) {
    const reg = registry[unitType];
    if (!reg || !reg.frames || !reg.frames.length) return;
    reg.frameIdx = (reg.frameIdx + 1) % reg.frames.length;
    // Cull tokens whose canvases have left the DOM (units were rebuilt).
    const dead = [];
    reg.tokens.forEach(function (t) {
      if (!t.canvas.isConnected) { dead.push(t); return; }
      drawFrameToToken(t, reg);
    });
    dead.forEach(function (t) { reg.tokens.delete(t); });
    const dur = reg.frames[reg.frameIdx].duration;
    reg.timer = setTimeout(function () { tick(unitType); }, dur);
  }

  async function loadAnimation(unitType) {
    if (registry[unitType]) return registry[unitType];
    if (loading[unitType])  return loading[unitType];

    const src = ANIMATED_GIFS[unitType];
    if (!src || typeof window.ImageDecoder === 'undefined') return null;

    loading[unitType] = (async function () {
      const resp = await fetch(src);
      if (!resp.ok) throw new Error('chromaBridge: HTTP ' + resp.status + ' loading ' + src);
      const buf = await resp.arrayBuffer();
      const dec = new window.ImageDecoder({ data: buf, type: 'image/gif' });
      await dec.tracks.ready;
      const track = dec.tracks.selectedTrack;
      const count = track.frameCount || 1;
      const frames = [];
      for (let i = 0; i < count; i++) {
        const res = await dec.decode({ frameIndex: i, completeFramesOnly: true });
        const vf = res.image;
        frames.push({
          image: vf,
          duration: Math.max(40, (vf.duration || 100000) / 1000),
          w: vf.displayWidth,
          h: vf.displayHeight,
        });
      }
      if (!frames.length) throw new Error('chromaBridge: no frames decoded from ' + src);

      // Sample corner pixel of first frame to derive chroma-key.
      const probeC = document.createElement('canvas');
      probeC.width = frames[0].w; probeC.height = frames[0].h;
      const pctx = probeC.getContext('2d', { willReadFrequently: true });
      pctx.drawImage(frames[0].image, 0, 0);
      const corner = pctx.getImageData(0, 0, 1, 1).data;
      const keyColor = { r: corner[0], g: corner[1], b: corner[2] };

      const reg = {
        frames: frames,
        keyColor: keyColor,
        frameIdx: 0,
        tokens: new Set(),
        timer: null,
      };
      registry[unitType] = reg;
      // Schedule the synchronized loop.
      reg.timer = setTimeout(function () { tick(unitType); }, frames[0].duration);
      return reg;
    })();

    try { return await loading[unitType]; }
    catch (err) { console.warn('chromaBridge:', err); return null; }
    finally { loading[unitType] = null; }
  }

  // ── Public: return a live DOM element for a unit ────────────────────

  function getSprite(unitType) {
    // No GIF for this type → light static icon.
    if (!ANIMATED_GIFS[unitType]) {
      const src = LIGHT_SPRITES[unitType] || LIGHT_SPRITES.Infantry;
      return lightImg(src, unitType);
    }

    // Animated: render into a canvas that hooks into the shared registry.
    const wrapper = document.createElement('div');
    wrapper.style.cssText = 'width:100%;height:100%;position:relative;display:flex;align-items:center;justify-content:center;';

    // Until frames arrive, show the light PNG so the cell is never empty.
    const fallback = lightImg(LIGHT_SPRITES[unitType], unitType);
    fallback.style.cssText = 'width:100%;height:100%;object-fit:contain;';
    wrapper.appendChild(fallback);

    // The canvas is created once frames are loaded — sized by the cell.
    function mountCanvas(reg) {
      // Use the larger of cell dimensions (canvas is square).
      const rect = wrapper.getBoundingClientRect();
      const size = Math.max(24, Math.floor(Math.min(rect.width, rect.height) || 56));
      const canvas = document.createElement('canvas');
      canvas.width  = size;
      canvas.height = size;
      canvas.style.cssText =
        'width:100%;height:100%;display:block;image-rendering:pixelated;' +
        'filter:drop-shadow(0 1px 0 rgba(0,0,0,0.55));';
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      const token = { canvas: canvas, ctx: ctx, size: size };
      reg.tokens.add(token);
      // Draw the current frame immediately so we don't wait for the next tick.
      drawFrameToToken(token, reg);
      // Swap fallback for canvas. (Disconnected tokens are culled in tick().)
      if (fallback.parentNode === wrapper) wrapper.removeChild(fallback);
      wrapper.appendChild(canvas);
    }

    loadAnimation(unitType).then(function (reg) {
      if (!reg) return; // fallback already in place
      // Wait one frame so the wrapper has been measured in the DOM.
      requestAnimationFrame(function () { mountCanvas(reg); });
    });

    return wrapper;
  }

  window.ChromaBridge = { getSprite: getSprite };
})();
