// dossier.js — fills the side panel (doctrine, war points, inventory, selection).

(function () {
  'use strict';

  const UNIT_ICONS = {
    Infantry:  '../assets/game-icons/infantry.png',
    Cavalry:   '../assets/game-icons/cavalry.png',
    Tanks:     '../assets/game-icons/tank.png',
    Motorized: '../assets/game-icons/motorized.png',
    Artillery: '../assets/game-icons/artillery.png',
  };
  const DOCTRINE_ICONS = {
    Plain:              '../assets/game-icons/plain.png',
    Blitzkrieg:         '../assets/game-icons/blitzkrieg.png',
    'Superior Firepower': '../assets/game-icons/superior_firepower.png',
  };

  function render(state) {
    if (!state) return;

    // Doctrine block
    const dName  = document.getElementById('d-doctrine-name');
    const dAlias = document.getElementById('d-doctrine-alias');
    const dImg   = document.getElementById('d-doctrine-img');
    if (dName)  dName.textContent  = state.doctrine.name;
    if (dAlias) dAlias.textContent = state.doctrine.alias ? '(' + state.doctrine.alias + ')' : '';
    if (dImg) {
      const src = DOCTRINE_ICONS[state.doctrine.name] || UNIT_ICONS.Infantry;
      dImg.src = src;
    }

    // Sticker on the map header
    const sticker = document.getElementById('mc-doctrine-sticker');
    if (sticker) {
      const src = DOCTRINE_ICONS[state.doctrine.name] || '';
      sticker.innerHTML =
        '<span class="doctrine-sticker">' +
        (src ? '<img src="' + src + '" alt="">' : '') +
        state.doctrine.name +
        '</span>';
    }

    // War points
    const wp = state.warPoints;
    const elB = document.getElementById('d-wp-budget');
    const elS = document.getElementById('d-wp-spent');
    const elL = document.getElementById('d-wp-left');
    if (elB) elB.textContent = wp.budget;
    if (elS) elS.textContent = wp.spent.total;
    if (elL) elL.textContent = wp.remaining;

    // Inventory list
    const inv = document.getElementById('d-inventory');
    if (inv) {
      inv.innerHTML = '';
      const entries = Object.entries(state.inventory || {});
      if (!entries.length) {
        inv.innerHTML = '<div class="inv-row"><span class="nm" style="font-style:italic;color:var(--olive)">No units in field.</span></div>';
      } else {
        entries.forEach(function ([name, count]) {
          const row = document.createElement('div');
          row.className = 'inv-row';
          const ico = UNIT_ICONS[name] || UNIT_ICONS.Infantry;
          row.innerHTML =
            '<img class="ico" src="' + ico + '" alt="">' +
            '<span class="nm">' + name + '</span>' +
            '<span class="ct">×' + count + '</span>';
          inv.appendChild(row);
        });
      }
    }

    // Map title with HCRAFT label
    const mcCoord = document.getElementById('mc-coords');
    if (mcCoord) mcCoord.textContent = state.grid.rows + '×' + state.grid.cols + ' · HCRAFT';

    // Selection card
    renderSelection(state);
  }

  function renderSelection(state) {
    const card = document.getElementById('d-selection');
    if (!card) return;
    const id = state.selectedUnitId;
    if (!id) {
      card.innerHTML = '<div class="sel-empty">No unit selected. Click a token on the map.</div>';
      return;
    }
    const u = state.units.find(function(x) { return x.id === id; });
    if (!u) {
      card.innerHTML = '<div class="sel-empty">Unit lost from roster.</div>';
      return;
    }
    const ico = UNIT_ICONS[u.type] || UNIT_ICONS.Infantry;
    const lvl = u.level > 1 ? ' L' + u.level : '';
    const rank = u.rank ? ' &middot; ' + u.rank : '';
    card.innerHTML =
      '<div class="sel-title" style="display:flex;align-items:center;gap:6px;">' +
        '<img src="' + ico + '" style="width:16px;height:16px;image-rendering:pixelated;">' +
        u.type + lvl +
      '</div>' +
      '<div style="font-family:\'VT323\',monospace;font-size:14px;color:var(--olive);letter-spacing:1px;">' +
        '@ ROW ' + u.row + ' · COL ' + u.col + rank +
      '</div>' +
      '<div style="margin-top:4px;font-size:11px;">Legal destinations highlighted in cyan.</div>';
  }

  // Hook into game state
  window.Dossier = { render: render };
})();
