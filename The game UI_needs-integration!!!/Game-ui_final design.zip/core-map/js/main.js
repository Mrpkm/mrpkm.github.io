// main.js — loaded as a plain <script> (no ES modules).
// All dependencies are window.* globals set by the scripts above.

(function () {
  'use strict';

  const mapRootEl     = document.getElementById('map-root');
  const minimapRootEl = document.getElementById('minimap-root');

  let _builtVersion = -1;
  let _unsubMap     = null;
  let _unsubUnits   = null;
  let _unsubMinimap = null;

  window.GameState.subscribe(function(state) {
    if (state.version !== _builtVersion) {
      if (_unsubMap)     _unsubMap();
      if (_unsubUnits)   _unsubUnits();
      if (_unsubMinimap) _unsubMinimap();
      mapRootEl.innerHTML     = '';
      minimapRootEl.innerHTML = '';
      _unsubMap     = window.MapRenderer.mountMap(mapRootEl);
      _unsubUnits   = window.UnitRenderer.mountUnits(mapRootEl);
      _unsubMinimap = window.MinimapRenderer.mount(minimapRootEl);
      _builtVersion = state.version;
      var ov = document.getElementById('ov-coords');
      if (ov) ov.textContent = state.grid.rows + '×' + state.grid.cols + ' GRID';
    }
    if (window.Dossier) window.Dossier.render(state);
  });

  window.Selection.attachSelection(mapRootEl);
  window.Input.attachInput();
})();
