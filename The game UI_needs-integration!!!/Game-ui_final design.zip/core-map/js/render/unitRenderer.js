(function () {
  'use strict';

  let _units = {};   // unitId → HTMLElement
  let _unsubscribe = null;

  function mountUnits(mapRootEl) {
    _units = {};
    if (_unsubscribe) { _unsubscribe(); _unsubscribe = null; }

    const state = window.GameState.getState();
    state.units.forEach(function(unit) {
      const el = _buildUnitEl(unit);
      _units[unit.id] = el;
      const cellEl = window.MapRenderer.getCellEl(unit.row, unit.col);
      if (!cellEl) throw new Error('unitRenderer: no cell at ' + unit.row + ',' + unit.col);
      cellEl.appendChild(el);
    });

    _unsubscribe = window.GameState.subscribe(_onStateChange);
    return _unsubscribe;
  }

  function _buildUnitEl(unit) {
    const el = document.createElement('div');
    el.className = 'unit';
    el.dataset.unitId   = unit.id;
    el.dataset.unitType = unit.type;

    el.appendChild(window.ChromaBridge.getSprite(unit.type));

    if (unit.rank) {
      const chip = document.createElement('span');
      chip.className   = 'rank-chip';
      chip.textContent = unit.rank;
      el.appendChild(chip);
    }
    return el;
  }

  function _onStateChange(state) {
    state.units.forEach(function(unit) {
      const el = _units[unit.id];
      if (!el) return;

      const parent = el.parentElement;
      if (!parent ||
          parseInt(parent.dataset.row) !== unit.row ||
          parseInt(parent.dataset.col) !== unit.col) {
        const cellEl = window.MapRenderer.getCellEl(unit.row, unit.col);
        if (cellEl) cellEl.appendChild(el);
      }

      el.classList.toggle('unit--selected', unit.id === state.selectedUnitId);
    });
  }

  window.UnitRenderer = { mountUnits: mountUnits };
})();
