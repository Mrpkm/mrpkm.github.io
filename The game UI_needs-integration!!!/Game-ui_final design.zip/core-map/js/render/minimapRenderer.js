// minimapRenderer.js — compact overview of the field map.
//
// Renders the same grid as MapRenderer but at a fraction of the size, with
// units shown as colour-coded dots (no chroma, no animation — that's the
// whole point of an overview).
//
// Public API:
//   MinimapRenderer.mount(rootEl) — builds the minimap into rootEl, subscribes
//   to GameState. Returns an unsubscribe function.

(function () {
  'use strict';

  const UNIT_DOT_COLOR = {
    Infantry:  '#3b82f6',
    Cavalry:   '#8b5cf6',
    Tanks:     '#ef4444',
    Motorized: '#f59e0b',
    Artillery: '#10b981',
  };

  function mount(rootEl) {
    rootEl.innerHTML = '';
    const state = window.GameState.getState();

    const cellEls = {};
    const unitDots = {};   // unitId → dot element

    // Lay out the grid via CSS variables so styles.css can do all the sizing.
    rootEl.style.setProperty('--mm-rows', state.grid.rows);
    rootEl.style.setProperty('--mm-cols', state.grid.cols);

    const frag = document.createDocumentFragment();
    state.grid.cells.forEach(function (cell) {
      const el = document.createElement('div');
      el.className = 'mm-cell';
      el.dataset.row   = cell.row;
      el.dataset.col   = cell.col;
      el.dataset.biome = cell.biome;
      cellEls[cell.row + ',' + cell.col] = el;
      frag.appendChild(el);
    });
    rootEl.appendChild(frag);

    function placeUnitDot(unit) {
      const cellEl = cellEls[unit.row + ',' + unit.col];
      if (!cellEl) return null;
      const dot = document.createElement('span');
      dot.className = 'mm-unit';
      dot.style.background = UNIT_DOT_COLOR[unit.type] || '#888';
      dot.dataset.unitId = unit.id;
      cellEl.appendChild(dot);
      return dot;
    }

    state.units.forEach(function (unit) {
      const d = placeUnitDot(unit);
      if (d) unitDots[unit.id] = d;
    });

    function onState(s) {
      // Legal-move highlight on minimap
      const legalSet = {};
      s.legalMoves.forEach(function (m) { legalSet[m.row + ',' + m.col] = true; });
      Object.keys(cellEls).forEach(function (k) {
        cellEls[k].classList.toggle('mm-legal', !!legalSet[k]);
      });

      // Re-parent units that have moved + selection highlight
      s.units.forEach(function (unit) {
        let dot = unitDots[unit.id];
        if (!dot) { dot = placeUnitDot(unit); if (dot) unitDots[unit.id] = dot; }
        if (!dot) return;
        const parent = dot.parentElement;
        if (!parent ||
            parseInt(parent.dataset.row) !== unit.row ||
            parseInt(parent.dataset.col) !== unit.col) {
          const cellEl = cellEls[unit.row + ',' + unit.col];
          if (cellEl) cellEl.appendChild(dot);
        }
        dot.classList.toggle('mm-selected', unit.id === s.selectedUnitId);
      });
    }

    const unsub = window.GameState.subscribe(onState);
    return unsub;
  }

  window.MinimapRenderer = { mount: mount };
})();
