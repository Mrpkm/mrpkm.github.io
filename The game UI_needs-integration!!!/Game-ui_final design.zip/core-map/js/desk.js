// desk.js — wires the desk-view command buttons, view-switching, demo briefing.

(function () {
  'use strict';

  const DEMO_BRIEFING = [
    '# Pre-Game Briefing',
    '',
    '**Doctrine:** Plain *(vanilla)*',
    '**War-point budget:** 30',
    '**Spent:** 0 (units 0 · xp 0 · bonuses 0)',
    '**Remaining:** 30',
    '',
    '## Starting Army (free)',
    '- Infantry: ×4',
    '- Cavalry: ×3',
    '- Tanks: ×2',
    '- Motorized: ×2',
    '- Artillery: ×2',
    '',
    '## Bought Units',
    '- *(none)*',
    '',
    '## Experience Upgrades',
    '- *(none)*',
    '',
    '## Spawn-State Bonuses',
    '- *(none)*',
    '',
    '## Map Coordinates',
    buildMapCoords(),
    '',
    '## Deployed Positions',
    '- Infantry: 11,2 · 11,4 · 12,3 · 12,5',
    '- Cavalry: 10,2 · 10,6 · 11,7',
    '- Tanks: 12,1 · 12,7',
    '- Motorized: 11,6 · 12,6',
    '- Artillery: 12,2 · 12,8',
    '',
  ].join('\n');

  function buildMapCoords() {
    // Hand-authored 12×11 board with mixed terrain.
    // P=plain, F=forest, M=mountain, S=swamp.
    const layout = [
      'MMFFPPPPFFM',
      'MFFPPPPPPFM',
      'FFPPPPPPPPP',
      'FPPPSPPPFFF',
      'PPPSSPPPPFF',
      'PPPSSPPPPPP',
      'PPPPPPPSSPP',
      'PPPFFPSSSPP',
      'PPFFFPPSPPP',
      'PFFFPPPPPPP',
      'MFFPPPPPFFM',
      'MMFPPPPPFFM',
    ];
    const lines = [];
    layout.forEach(function (row, rIdx) {
      const r = rIdx + 1;
      const cells = [];
      row.split('').forEach(function (ch, cIdx) {
        const c = cIdx + 1;
        cells.push(r + ',' + c + '=' + ch);
      });
      lines.push('- ' + cells.join('; '));
    });
    return lines.join('\n');
  }

  function loadCode(code) {
    try { localStorage.setItem('pregame_briefing_last', code); } catch (_) {}
    const ta  = document.getElementById('paste-textarea');
    const btn = document.getElementById('btn-load');
    if (ta && btn) { ta.value = code; btn.click(); }
  }

  // Switch from desk → map view (or back)
  function showMap() {
    document.getElementById('desk-view').style.display = 'none';
    document.getElementById('map-view').classList.add('active');
    setHint('▸ Click a token to view legal moves. ESC deselects.');
  }
  function showDesk() {
    document.getElementById('desk-view').style.display = '';
    document.getElementById('map-view').classList.remove('active');
    setHint('▸ Drop a briefing on the desk, or pick a routine');
  }

  function setHint(text) {
    const h = document.getElementById('hint');
    if (!h) return;
    h.textContent = text;
    h.classList.remove('fade');
  }

  // ── Command buttons ───────────────────────────────────────
  document.addEventListener('click', function (e) {
    const card = e.target.closest('.cmd-card');
    if (card) {
      const action = card.dataset.action;
      handleAction(action);
    }
    if (e.target.id === 'btn-clear') {
      // Wipe state and return to desk
      window.location.href = window.location.pathname;
    }
    if (e.target.id === 'btn-rules') {
      window.open('../src/menu/Strategy%20Game%20Menu.html', '_blank');
    }
    if (e.target.id === 'btn-setup') {
      window.location.href = '../src/tools/pregame-setup.html';
    }
  });

  function handleAction(action) {
    switch (action) {
      case 'paste':
        document.getElementById('paste-textarea').focus();
        setHint('▸ Paste your briefing into the slot at the top, then press LOAD');
        break;
      case 'demo':
        loadCode(DEMO_BRIEFING);
        break;
      case 'setup':
        window.location.href = '../src/tools/pregame-setup.html';
        break;
      case 'rules':
        window.location.href = '../src/menu/Strategy%20Game%20Menu.html?panel=rules';
        break;
      case 'last': {
        let last = null;
        try { last = localStorage.getItem('pregame_briefing_last'); } catch (_) {}
        if (!last) {
          setHint('▸ The field safe is empty. Load a briefing first.');
          return;
        }
        loadCode(last);
        break;
      }
      case 'builder':
        window.location.href = '../src/menu/map-builder.html';
        break;
    }
  }

  // Refresh "Restore Last" label
  try {
    const last = localStorage.getItem('pregame_briefing_last');
    const el = document.getElementById('last-status');
    if (el && last) el.textContent = 'ON FILE';
  } catch (_) {}

  // Keyboard shortcuts
  document.addEventListener('keydown', function (e) {
    if (e.target.tagName === 'TEXTAREA' || e.target.tagName === 'INPUT') return;
    const map = { F1: 'paste', F2: 'demo', F3: 'setup', F4: 'rules', F5: 'last', F6: 'builder' };
    if (map[e.key]) { e.preventDefault(); handleAction(map[e.key]); }
  });

  // When the map gets built for the first time, swap views
  if (window.GameState && typeof window.GameState.subscribe === 'function') {
    let hasFlipped = false;
    window.GameState.subscribe(function () {
      if (hasFlipped) return;
      hasFlipped = true;
      showMap();
    });
  }

  // Fade the hint after a few seconds
  setTimeout(function () {
    const h = document.getElementById('hint');
    if (h && !document.getElementById('map-view').classList.contains('active')) {
      h.classList.add('fade');
    }
  }, 4500);

  // Expose for debug
  window.Desk = { showMap: showMap, showDesk: showDesk, loadDemo: function() { loadCode(DEMO_BRIEFING); } };
})();
